# SignalPrime — Android App

Native Android client for the **SignalPrime — Master Signal** platform: a crypto
market-intelligence terminal that consumes the SignalPrime backend (`/health`,
`/signal/{symbol}`, `/scanner`, …) and renders LONG / SHORT / NO_TRADE master
signals with full reasoning, risk plan, and multi-timeframe context.

> **Disclaimer:** this app displays analytical estimates from a scoring model.
> It is not financial advice. Nothing here guarantees profit or accuracy.

## Tech stack

- Kotlin 2.0.21, AGP 8.5.2, Java 17, `minSdk 26`, `targetSdk 34`
- Jetpack Compose + Material 3 (dark trading theme), Navigation Compose
- MVVM-ish: `ui/screens/<feature>/` (Screen + ViewModel), `data/repository`
- Coroutines + Flow, Retrofit 2 + OkHttp, kotlinx.serialization
  (`Json { ignoreUnknownKeys = true, explicitNulls = false }` — tolerant parsing)
- DataStore (Preferences) for settings / watchlist / seen signals
- WorkManager (15-min periodic) → Android notifications for new high-quality signals
- Custom Compose-Canvas candlestick chart (no heavy chart library)

## Project structure

```
android/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── gradle/libs.versions.toml
├── README.md
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/signalprime/pro/
        │   ├── SignalPrimeApplication.kt / MainActivity.kt
        │   ├── data/
        │   │   ├── model/Models.kt          # domain models, Outcome, AppError, UiState
        │   │   ├── remote/dto/Dtos.kt       # tolerant @Serializable DTOs
        │   │   ├── remote/ApiService.kt     # Retrofit endpoints
        │   │   ├── remote/NetworkModule.kt  # Json + OkHttp/Retrofit factory
        │   │   ├── local/SettingsStore.kt   # DataStore settings
        │   │   ├── Mappers.kt               # DTO → domain
        │   │   └── repository/CryptoRepository.kt
        │   ├── ui/
        │   │   ├── theme/                   # dark trading palette
        │   │   ├── navigation/NavGraph.kt   # routes + bottom nav
        │   │   ├── viewmodel/ViewModelFactory.kt
        │   │   ├── components/              # SignalCard, MtfTable, States, Chips,
        │   │   │                            # DirectionBadge, StatRow, SectionCard, TopBar
        │   │   ├── components/chart/        # CandleChart (Canvas) + ChartMath
        │   │   └── screens/                 # splash, dashboard, scanner, more,
        │   │                                # signaldetail, coindetail, history,
        │   │                                # riskcalc, backtest, settings,
        │   │                                # notifications, about
        │   ├── worker/SignalCheckWorker.kt
        │   ├── notifications/NotificationHelper.kt
        │   └── util/                        # Formatters, RiskMath, DisplayUtils,
        │                                    # NetworkMonitor, Constants
        └── res/values/ (strings, themes)
    └── src/test/java/com/signalprime/pro/      # 59 unit tests (JUnit4)
```

## Setup

1. Install Android Studio (Ladybug or newer) with Android SDK 34 and JDK 17.
2. Start the backend first (default `http://10.0.2.2:3000` from the emulator).
3. Open `android/` in Android Studio and let Gradle sync.
4. Run on an emulator or device (API 26+).

## API base URL

- Build default: `BuildConfig.API_BASE_URL` = `"http://10.0.2.2:3000"`
  (set in `app/build.gradle.kts` via `buildConfigField`).
- **User-overridable** at runtime: More → Settings → *API Base URL* → Save,
  then *Test connection*. Stored in DataStore; Retrofit is rebuilt when it changes.
- The manifest sets `usesCleartextTraffic="true"` so `http://` dev URLs work.
  For production HTTPS, no change is needed in code.

## Build

```bash
cd android
./gradlew assembleDebug        # APK → app/build/outputs/apk/debug/
./gradlew testDebugUnitTest    # run the 59 unit tests
./gradlew assembleRelease      # release APK (minify disabled)
```

> Note: there is no Android SDK in some CI/dev containers — the project was
> authored without running a local Gradle build there. Run the commands above on
> a machine with the SDK to verify.

## Screens

| Route | Screen |
|---|---|
| Splash | Branding → Dashboard |
| Dashboard (bottom nav) | BTC/ETH cards, market overview, best signal, best RR, top signals |
| Scanner (bottom nav) | Ranked signals, ALL/LONG/SHORT/WATCHLIST filters, watchlist stars |
| History (bottom nav) | Filter chips, client-side performance stats, result badges |
| More (bottom nav) | Links to the screens below |
| `signal/{symbol}` | Master Signal: score/confidence/probability, entry/SL/TP1-3, RR, position, MTF table, WHY LONG/SHORT/NO_TRADE, warnings, invalidation |
| `coin/{symbol}` | Price header, timeframe selector, candlestick chart (EMA20/50/200, VWAP, S/R, entry/SL/TP overlays, fullscreen toggle), on-device indicators |
| Risk Calculator | Balance/risk/entry/SL → risk amount, quantity, leverage, RR |
| Backtest | Form → POST /backtest → summary + trades table |
| Settings | API URL, defaults, clear cache, test connection |
| Notifications | Toggles, min score/confidence, direction filter, coin multi-select |
| About | Version, backend version, disclaimer |

## Notifications

More → Notifications: enable alerts, set minimum score/confidence, direction
(LONG only / SHORT only / All), and coins (or all). A WorkManager periodic task
(every ~15 min, requires network) polls `GET /signals`, notifies once per new
qualifying signal, and marks it seen. Two channels: **Signal Alerts** (high
importance) and **Signal Updates**. Android 13+ asks for `POST_NOTIFICATIONS`.

## Offline & error states

The app never fabricates data. Distinct full-screen states:

- No internet → **OFFLINE** (with retry)
- Backend unreachable → **SERVER CONNECTION ERROR**
- Backend `MARKET_DATA_UNAVAILABLE` → **MARKET DATA UNAVAILABLE**
- Other API errors show the backend's code/message; every list screen has
  loading / error / empty states and pull-to-refresh.

## Security

No secrets, API keys, or private credentials anywhere in the app — only the
user-configurable base URL. Trading keys (if ever added) must live in the
backend, never in the APK.

## Troubleshooting

- **Emulator can't reach backend:** use `http://10.0.2.2:3000` (not `localhost`).
  On a physical device, use your machine's LAN IP and the same port.
- **SERVER CONNECTION ERROR:** backend isn't running or the URL is wrong —
  check Settings → Test connection.
- **Gradle sync issues:** ensure JDK 17 and AGP 8.5.2; delete `.gradle/` and
  re-sync.
