package com.signalprime.app.ui.screens.coindetail

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import com.signalprime.app.data.model.Candle
import com.signalprime.app.data.model.RegimeInfo
import com.signalprime.app.data.model.Signal
import com.signalprime.app.data.model.Ticker
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.ui.components.DirectionBadge
import com.signalprime.app.ui.components.EmptyState
import com.signalprime.app.ui.components.ErrorState
import com.signalprime.app.ui.components.FilterChips
import com.signalprime.app.ui.components.LoadingState
import com.signalprime.app.ui.components.MtfTable
import com.signalprime.app.ui.components.SectionCard
import com.signalprime.app.ui.components.StatRow
import com.signalprime.app.ui.components.chart.CandleChart
import com.signalprime.app.ui.components.chart.computeEma
import com.signalprime.app.ui.components.chart.computeVwap
import com.signalprime.app.ui.components.chart.findSwingLevels
import com.signalprime.app.ui.components.chart.rsi
import com.signalprime.app.ui.theme.Accent
import com.signalprime.app.ui.theme.Background
import com.signalprime.app.ui.theme.LongGreen
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.OnBackground
import com.signalprime.app.ui.theme.ShortRed
import com.signalprime.app.ui.theme.SurfaceVariant
import com.signalprime.app.ui.theme.Surface as ThemeSurface
import com.signalprime.app.ui.viewmodel.viewModelFactory
import com.signalprime.app.util.Constants
import com.signalprime.app.util.formatCompact
import com.signalprime.app.util.formatPct
import com.signalprime.app.util.formatPrice
import com.signalprime.app.util.regimeDisplayName

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoinDetailScreen(
    repository: CryptoRepository,
    symbol: String,
    onBack: () -> Unit,
    onSignalClick: (symbol: String) -> Unit,
) {
    val vm: CoinDetailViewModel = viewModel(factory = viewModelFactory { CoinDetailViewModel(repository, symbol) })
    val uiState by vm.uiState.collectAsState()
    val refreshing by vm.isRefreshing.collectAsState()
    val timeframe by vm.timeframe.collectAsState()
    var showFullscreen by remember { mutableStateOf(false) }
    val successData = (uiState as? UiState.Success<CoinDetailData>)?.data

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(symbol, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ThemeSurface,
                    titleContentColor = OnBackground,
                    navigationIconContentColor = OnBackground,
                ),
            )
        },
        containerColor = Background,
    ) { padding ->
        PullToRefreshBox(
            isRefreshing = refreshing,
            onRefresh = { vm.refresh() },
            modifier = Modifier.padding(padding).fillMaxSize(),
        ) {
            when (val s = uiState) {
                is UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(s.error, onRetry = { vm.refresh() })
                is UiState.Success -> CoinDetailContent(
                    data = s.data,
                    symbol = symbol,
                    timeframe = timeframe,
                    onTimeframe = { vm.setTimeframe(it) },
                    onSignalClick = onSignalClick,
                    onExpandChart = { showFullscreen = true },
                )
                is UiState.Empty -> EmptyState("No data for $symbol")
            }
        }
    }

    if (showFullscreen && successData != null) {
        Dialog(
            onDismissRequest = { showFullscreen = false },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Surface(modifier = Modifier.fillMaxSize(), color = Background) {
                Box(modifier = Modifier.fillMaxSize()) {
                    CandleChart(
                        candles = successData.candles,
                        entry = successData.signal?.entry,
                        stopLoss = successData.signal?.stopLoss,
                        takeProfit = successData.signal?.takeProfit,
                        modifier = Modifier.fillMaxSize().padding(8.dp),
                    )
                    IconButton(
                        onClick = { showFullscreen = false },
                        modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "Close fullscreen", tint = OnBackground)
                    }
                }
            }
        }
    }
}

@Composable
private fun CoinDetailContent(
    data: CoinDetailData,
    symbol: String,
    timeframe: String,
    onTimeframe: (String) -> Unit,
    onSignalClick: (String) -> Unit,
    onExpandChart: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { PriceHeader(data.ticker) }
        item { TickerStats(data.ticker) }
        item {
            FilterChips(
                options = Constants.TIMEFRAMES,
                selected = timeframe,
                onSelected = onTimeframe,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            SectionCard(title = "Chart") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Timeframe: $timeframe", color = Muted, fontSize = 12.sp)
                    IconButton(onClick = onExpandChart) {
                        Icon(Icons.Filled.OpenInFull, contentDescription = "Fullscreen chart", tint = OnBackground)
                    }
                }
                CandleChart(
                    candles = data.candles,
                    entry = data.signal?.entry,
                    stopLoss = data.signal?.stopLoss,
                    takeProfit = data.signal?.takeProfit,
                    modifier = Modifier.fillMaxWidth().height(280.dp),
                )
            }
        }
        item { MasterSignalCard(signal = data.signal, symbol = symbol, onSignalClick = onSignalClick) }
        data.signal?.let { sig ->
            item {
                SectionCard(title = "Multi-Timeframe") {
                    MtfTable(sig.mtf)
                }
            }
        }
        item { OnDeviceIndicators(candles = data.candles) }
        item { SupportResistance(candles = data.candles) }
        data.regime?.let { r ->
            item { RegimeChip(regime = r) }
        }
    }
}

@Composable
private fun PriceHeader(t: Ticker) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(formatPrice(t.price), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = OnBackground)
        val chg = t.priceChangePercent24h ?: 0.0
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                formatPct(t.priceChangePercent24h),
                color = if (chg >= 0) LongGreen else ShortRed,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
            )
            Spacer(Modifier.width(6.dp))
            Text("24h change", color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun TickerStats(t: Ticker) {
    SectionCard(title = "24h Stats") {
        StatRow("Volume", formatCompact(t.volume24h))
        StatRow("Quote volume", formatCompact(t.quoteVolume24h))
        StatRow("24h high", formatPrice(t.high24h), LongGreen)
        StatRow("24h low", formatPrice(t.low24h), ShortRed)
    }
}

@Composable
private fun MasterSignalCard(signal: Signal?, symbol: String, onSignalClick: (String) -> Unit) {
    SectionCard(title = "Master Signal") {
        if (signal == null) {
            Text("No signal available right now.", color = Muted, fontSize = 14.sp)
        } else {
            val score = listOfNotNull(signal.longScore, signal.shortScore).maxOrNull()
            Row(verticalAlignment = Alignment.CenterVertically) {
                DirectionBadge(signal.direction)
                Spacer(Modifier.width(8.dp))
                Text(
                    "Score ${score?.toInt()?.toString() ?: "—"}",
                    color = OnBackground,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                )
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { onSignalClick(symbol) }) {
                Text("Full Analysis")
            }
        }
    }
}

private data class OnDeviceValues(
    val ema20: Double?,
    val ema50: Double?,
    val ema200: Double?,
    val vwap: Double?,
    val rsi14: Double?,
    val supports: List<Double>,
    val resistances: List<Double>,
)

@Composable
private fun OnDeviceIndicators(candles: List<Candle>) {
    val ind = remember(candles) {
        val closes = candles.map { it.close }
        val (supports, resistances) = findSwingLevels(candles, 5)
        OnDeviceValues(
            ema20 = computeEma(closes, 20).lastOrNull { it != null },
            ema50 = computeEma(closes, 50).lastOrNull { it != null },
            ema200 = computeEma(closes, 200).lastOrNull { it != null },
            vwap = computeVwap(candles).lastOrNull { it != null },
            rsi14 = rsi(closes, 14),
            supports = supports,
            resistances = resistances,
        )
    }
    SectionCard(title = "On-Device Indicators") {
        StatRow("EMA 20", formatPrice(ind.ema20), Accent)
        StatRow("EMA 50", formatPrice(ind.ema50))
        StatRow("EMA 200", formatPrice(ind.ema200))
        StatRow("VWAP", formatPrice(ind.vwap))
        StatRow("RSI 14", ind.rsi14?.let { "%.1f".format(it) } ?: "—")
        Text("Computed on-device from chart data", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SupportResistance(candles: List<Candle>) {
    val (supports, resistances) = remember(candles) { findSwingLevels(candles, 5) }
    SectionCard(title = "Support / Resistance") {
        if (supports.isEmpty() && resistances.isEmpty()) {
            Text("Not enough chart data to detect levels.", color = Muted, fontSize = 14.sp)
        } else {
            supports.forEachIndexed { i, s ->
                StatRow("Support S${i + 1}", formatPrice(s), LongGreen)
            }
            resistances.forEachIndexed { i, r ->
                StatRow("Resistance R${i + 1}", formatPrice(r), ShortRed)
            }
        }
    }
}

@Composable
private fun RegimeChip(regime: RegimeInfo) {
    Surface(shape = RoundedCornerShape(12.dp), color = SurfaceVariant) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Regime: ", color = Muted, fontSize = 14.sp)
            Text(
                regimeDisplayName(regime.regime),
                color = OnBackground,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
            )
            regime.biasScore?.let { b ->
                Text(
                    " (${if (b >= 0) "+" else ""}${b.toInt()})",
                    color = Muted,
                    fontSize = 13.sp,
                )
            }
        }
    }
}
