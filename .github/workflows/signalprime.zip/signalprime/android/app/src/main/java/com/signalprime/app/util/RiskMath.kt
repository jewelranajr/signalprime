package com.signalprime.app.util

import kotlin.math.abs
import kotlin.math.round

// Pure position-sizing math. No Android imports — safe for unit tests.

data class RiskCalcResult(
    val riskAmount: Double,
    val stopDistance: Double,
    val stopDistancePct: Double,
    val quantity: Double,
    val positionValue: Double,
    val suggestedLeverage: Double
)

/**
 * Position size from account risk. Returns null when any input is invalid
 * (non-positive balance / risk% / entry / stop, or entry == stop).
 */
fun calculateRisk(
    balance: Double,
    riskPercent: Double,
    entry: Double,
    stopLoss: Double
): RiskCalcResult? {
    if (balance <= 0 || riskPercent <= 0 || entry <= 0 || stopLoss <= 0 || entry == stopLoss) {
        return null
    }
    val riskAmount = balance * riskPercent / 100.0
    val stopDistance = abs(entry - stopLoss)
    val stopDistancePct = stopDistance / entry * 100.0
    val quantity = riskAmount / stopDistance
    val positionValue = quantity * entry
    val suggestedLeverage = round((positionValue / balance).coerceIn(1.0, 20.0) * 10.0) / 10.0
    return RiskCalcResult(
        riskAmount = riskAmount,
        stopDistance = stopDistance,
        stopDistancePct = stopDistancePct,
        quantity = quantity,
        positionValue = positionValue,
        suggestedLeverage = suggestedLeverage
    )
}

/** Reward:risk ratio rounded to 2 decimals; null when inputs are invalid. */
fun riskReward(
    entry: Double,
    stopLoss: Double,
    takeProfit: Double,
    isLong: Boolean
): Double? {
    if (entry <= 0 || stopLoss <= 0 || takeProfit <= 0) return null
    val risk = abs(entry - stopLoss)
    if (risk <= 0) return null
    val reward = abs(takeProfit - entry)
    return round(reward / risk * 100.0) / 100.0
}
