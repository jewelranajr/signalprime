package com.signalprime.app.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.signalprime.app.data.model.Signal
import com.signalprime.app.util.displayName
import com.signalprime.app.util.formatPrice

/**
 * Posts signal alerts and signal status updates. All entry points are safe to
 * call from a background worker: channels are created on demand and posting
 * is skipped when the POST_NOTIFICATIONS permission is not granted.
 */
object NotificationHelper {

    const val CHANNEL_ALERTS = "signal_alerts"
    const val CHANNEL_UPDATES = "signal_updates"

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ALERTS,
                "Signal Alerts",
                NotificationManager.IMPORTANCE_HIGH,
            ).apply { description = "New trading signal alerts" },
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_UPDATES,
                "Signal Updates",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply { description = "Signal status updates" },
        )
    }

    private fun canPost(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS,
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun manager(context: Context): NotificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun notifyNewSignal(context: Context, signal: Signal) {
        if (!canPost(context)) return
        val score = maxOf(signal.longScore ?: 0.0, signal.shortScore ?: 0.0)
        val text = "Score ${score.toInt()} • " +
            "Conf ${(signal.confidence ?: 0.0).toInt()}% • " +
            "Entry ${signal.entry?.preferred?.let { formatPrice(it) } ?: "—"}"
        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("🔔 ${signal.direction.displayName()} ${signal.symbol}")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        manager(context).notify(signal.signalId.hashCode(), notification)
    }

    fun notifySignalUpdate(context: Context, signal: Signal, event: String) {
        if (!canPost(context)) return
        val notification = NotificationCompat.Builder(context, CHANNEL_UPDATES)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("${signal.direction.displayName()} ${signal.symbol}")
            .setContentText(event)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        manager(context).notify((signal.signalId + event).hashCode(), notification)
    }
}
