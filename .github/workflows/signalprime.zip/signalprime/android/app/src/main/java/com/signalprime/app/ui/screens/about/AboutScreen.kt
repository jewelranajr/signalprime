package com.signalprime.app.ui.screens.about

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprime.app.data.model.HealthInfo
import com.signalprime.app.data.model.Outcome
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.ui.components.SectionCard
import com.signalprime.app.ui.theme.Background
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.NoTradeAmber
import com.signalprime.app.ui.theme.OnBackground
import com.signalprime.app.ui.theme.Surface

private val FEATURES = listOf(
    "AI-powered master signals with LONG / SHORT / NO_TRADE direction",
    "Multi-timeframe confluence analysis",
    "Automatic entry zones, stop-loss and take-profit levels",
    "Position sizing and risk management tools",
    "Strategy backtesting on historical data",
    "Background signal alerts every ~15 minutes",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(repository: CryptoRepository, onBack: () -> Unit) {
    var health by remember { mutableStateOf<HealthInfo?>(null) }
    LaunchedEffect(Unit) {
        health = (repository.getHealth() as? Outcome.Ok<HealthInfo>)?.value
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Surface,
                    titleContentColor = OnBackground,
                    navigationIconContentColor = OnBackground,
                ),
            )
        },
        containerColor = Background,
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text("SignalPrime", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = OnBackground)
                    Text("Version 1.0.0", color = Muted, fontSize = 14.sp)
                    health?.let { h ->
                        Text("Backend version ${h.version ?: "—"}", color = Muted, fontSize = 13.sp)
                        Text("Data source: ${h.dataSource ?: "—"}", color = Muted, fontSize = 13.sp)
                    }
                }
            }
            item {
                SectionCard(title = "Features") {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        FEATURES.forEach { f ->
                            Text("• $f", color = OnBackground, fontSize = 14.sp)
                        }
                    }
                }
            }
            item {
                SectionCard(title = "Disclaimer") {
                    Text(
                        "Not financial advice. Crypto trading involves substantial risk of loss. " +
                            "Signals are estimates from a scoring model — no guaranteed profit or accuracy. " +
                            "Never risk capital you cannot afford to lose.",
                        color = NoTradeAmber,
                        fontSize = 14.sp,
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
