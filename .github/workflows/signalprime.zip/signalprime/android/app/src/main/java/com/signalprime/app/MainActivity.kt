package com.signalprime.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import com.signalprime.app.data.local.SettingsStore
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.data.repository.CryptoRepositoryImpl
import com.signalprime.app.ui.navigation.SignalPrimeApp
import com.signalprime.app.ui.theme.SignalPrimeTheme
import com.signalprime.app.worker.SignalCheckWorker
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val settings: SettingsStore by lazy { SettingsStore(applicationContext) }
    private val repository: CryptoRepository by lazy {
        CryptoRepositoryImpl(applicationContext, settings)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep the periodic signal-check worker in sync with the user's
        // notification preference.
        lifecycleScope.launch {
            settings.notificationsEnabled.collect { enabled ->
                if (enabled) {
                    SignalCheckWorker.schedule(applicationContext)
                } else {
                    SignalCheckWorker.cancel(applicationContext)
                }
            }
        }

        setContent {
            SignalPrimeTheme {
                SignalPrimeApp(repository)
            }
        }
    }
}
