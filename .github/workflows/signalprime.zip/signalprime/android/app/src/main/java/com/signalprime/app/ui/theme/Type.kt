package com.signalprime.app.ui.theme

import androidx.compose.material3.Typography

// App typography — defaults are fine for now; customized styles live with
// the screens that need them.
val AppTypography = Typography()
