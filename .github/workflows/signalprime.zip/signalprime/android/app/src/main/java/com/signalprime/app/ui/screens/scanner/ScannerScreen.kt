package com.signalprime.app.ui.screens.scanner

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.signalprime.app.data.model.Direction
import com.signalprime.app.data.model.ScannerResult
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.ui.components.DirectionBadge
import com.signalprime.app.ui.components.EmptyState
import com.signalprime.app.ui.components.ErrorState
import com.signalprime.app.ui.components.FilterChips
import com.signalprime.app.ui.components.LoadingState
import com.signalprime.app.ui.theme.Accent
import com.signalprime.app.ui.theme.Background
import com.signalprime.app.ui.theme.LongGreen
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.OnBackground
import com.signalprime.app.ui.theme.ShortRed
import com.signalprime.app.ui.theme.Surface as ThemeSurface
import com.signalprime.app.ui.viewmodel.viewModelFactory
import com.signalprime.app.util.formatPct
import com.signalprime.app.util.formatPrice

private val FILTER_OPTIONS = listOf("ALL", "LONG", "SHORT", "WATCHLIST")

@Composable
fun ScannerScreen(repository: CryptoRepository, onCoinClick: (symbol: String) -> Unit) {
    val vm: ScannerViewModel = viewModel(factory = viewModelFactory { ScannerViewModel(repository) })
    val uiState by vm.uiState.collectAsStateWithLifecycle()
    val filter by vm.filter.collectAsStateWithLifecycle()
    val watchCoins by repository.settings.watchCoins.collectAsStateWithLifecycle(initialValue = emptySet())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .padding(16.dp),
    ) {
        Text(
            text = "Scanner",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = OnBackground,
        )
        Spacer(Modifier.height(12.dp))
        FilterChips(
            options = FILTER_OPTIONS,
            selected = filter,
            onSelected = { vm.filter.value = it },
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))
        PullToRefreshBox(
            isRefreshing = uiState is UiState.Loading,
            onRefresh = { vm.refresh() },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
        ) {
            when (val state = uiState) {
                is UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(error = state.error, onRetry = { vm.refresh() })
                is UiState.Empty -> EmptyState("No scanner results right now")
                is UiState.Success -> {
                    val results = state.data.results.filter { result ->
                        when (filter) {
                            "LONG" -> result.direction == Direction.LONG
                            "SHORT" -> result.direction == Direction.SHORT
                            "WATCHLIST" -> result.symbol in watchCoins
                            else -> true
                        }
                    }
                    if (results.isEmpty()) {
                        EmptyState(message = emptyMessage(filter))
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            items(results, key = { it.symbol }) { result ->
                                ScannerRow(
                                    result = result,
                                    watched = result.symbol in watchCoins,
                                    onWatchToggle = { vm.toggleWatch(result.symbol) },
                                    onClick = { onCoinClick(result.symbol) },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun emptyMessage(filter: String): String = when (filter) {
    "LONG" -> "No LONG signals right now"
    "SHORT" -> "No SHORT signals right now"
    "WATCHLIST" -> "No watched coins yet — tap the star on any coin to watch it"
    else -> "No scanner results right now"
}

@Composable
private fun ScannerRow(
    result: ScannerResult,
    watched: Boolean,
    onWatchToggle: () -> Unit,
    onClick: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = ThemeSurface,
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = result.symbol,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = OnBackground,
                    )
                    Spacer(Modifier.width(8.dp))
                    DirectionBadge(direction = result.direction)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Score ${leadingScore(result.direction, result.longScore, result.shortScore)?.toString() ?: "—"}" +
                        " · Conf ${result.confidence?.let { "${it.toInt()}%" } ?: "—"}",
                    fontSize = 12.sp,
                    color = Muted,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = formatPrice(result.price),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = OnBackground,
                )
                Spacer(Modifier.height(2.dp))
                val change = result.change24hPct
                if (change != null) {
                    Text(
                        text = formatPct(change),
                        fontSize = 12.sp,
                        color = if (change >= 0) LongGreen else ShortRed,
                    )
                } else {
                    Text(
                        text = "—",
                        fontSize = 12.sp,
                        color = Muted,
                    )
                }
            }
            IconButton(onClick = onWatchToggle) {
                Icon(
                    imageVector = if (watched) Icons.Filled.Star else Icons.Filled.StarBorder,
                    contentDescription = if (watched) {
                        "Remove ${result.symbol} from watchlist"
                    } else {
                        "Add ${result.symbol} to watchlist"
                    },
                    tint = if (watched) Accent else Muted,
                )
            }
        }
    }
}

/** Score of the result's leading direction (LONG -> longScore, SHORT -> shortScore). Null when unknown. */
private fun leadingScore(direction: Direction, longScore: Double?, shortScore: Double?): Int? =
    when (direction) {
        Direction.LONG -> longScore?.toInt()
        Direction.SHORT -> shortScore?.toInt()
        else -> when {
            longScore != null && shortScore != null -> maxOf(longScore, shortScore).toInt()
            longScore != null -> longScore.toInt()
            shortScore != null -> shortScore.toInt()
            else -> null
        }
    }
