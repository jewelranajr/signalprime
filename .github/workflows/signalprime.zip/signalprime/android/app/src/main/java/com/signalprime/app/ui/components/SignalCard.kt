package com.signalprime.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprime.app.data.model.Direction
import com.signalprime.app.data.model.Signal
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.NoTradeAmber
import com.signalprime.app.ui.theme.OnBackground
import com.signalprime.app.ui.theme.Surface as ThemeSurface
import com.signalprime.app.util.displayName
import com.signalprime.app.util.formatPrice
import com.signalprime.app.util.regimeDisplayName

/**
 * Compact card summarizing a signal. Tapping opens the signal detail.
 * NO_TRADE signals render a dedicated variant (amber badge + reason).
 */
@Composable
fun SignalCard(signal: Signal, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = ThemeSurface,
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                DirectionBadge(direction = signal.direction)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = signal.symbol,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = OnBackground,
                )
                Spacer(Modifier.weight(1f))
                Text(
                    text = signal.status.displayName(),
                    fontSize = 12.sp,
                    color = Muted,
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Open ${signal.symbol} signal",
                    tint = Muted,
                )
            }
            Spacer(Modifier.height(8.dp))
            if (signal.direction == Direction.NO_TRADE) {
                NoTradeBody(signal)
            } else {
                TradeBody(signal)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Regime: ${regimeDisplayName(signal.marketRegime)}",
                fontSize = 12.sp,
                color = Muted,
            )
        }
    }
}

@Composable
private fun TradeBody(signal: Signal) {
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        MiniStat(label = "Score", value = leadingScore(signal)?.toString() ?: "—")
        MiniStat(label = "Conf", value = signal.confidence?.let { "${it.toInt()}%" } ?: "—")
        signal.riskReward?.tp1?.let { rr ->
            MiniStat(label = "RR", value = formatRr(rr))
        }
    }
    val entryPrice = signal.entry?.preferred
    val slPrice = signal.stopLoss?.price
    if (entryPrice != null && slPrice != null) {
        Spacer(Modifier.height(6.dp))
        Text(
            text = "Entry ${formatPrice(entryPrice)} → SL ${formatPrice(slPrice)}",
            fontSize = 13.sp,
            color = OnBackground,
        )
    }
}

@Composable
private fun NoTradeBody(signal: Signal) {
    Text(
        text = "NO TRADE",
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        color = NoTradeAmber,
    )
    Spacer(Modifier.height(4.dp))
    Text(
        text = signal.reasons.firstOrNull()?.take(140) ?: "No reason provided",
        fontSize = 13.sp,
        color = Muted,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
private fun MiniStat(label: String, value: String) {
    Column {
        Text(text = label, fontSize = 11.sp, color = Muted)
        Text(
            text = value,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = OnBackground,
        )
    }
}

/** Score of the signal's leading direction (LONG -> longScore, SHORT -> shortScore). Null when unknown. */
private fun leadingScore(signal: Signal): Int? = when (signal.direction) {
    Direction.LONG -> signal.longScore?.toInt()
    Direction.SHORT -> signal.shortScore?.toInt()
    else -> {
        val long = signal.longScore
        val short = signal.shortScore
        when {
            long != null && short != null -> maxOf(long, short).toInt()
            long != null -> long.toInt()
            short != null -> short.toInt()
            else -> null
        }
    }
}

/** Locale-safe one-decimal RR formatting, e.g. 3.2. */
private fun formatRr(rr: Double): String {
    val rounded = kotlin.math.round(rr * 10) / 10.0
    return if (rounded == kotlin.math.floor(rounded)) {
        rounded.toInt().toString()
    } else {
        rounded.toString()
    }
}
