package com.signalprime.app.ui.screens.notifications

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.ui.components.FilterChips
import com.signalprime.app.ui.components.ScreenTopBar
import com.signalprime.app.ui.components.SectionCard
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.OnBackground
import com.signalprime.app.ui.theme.ShortRed
import com.signalprime.app.ui.viewmodel.viewModelFactory
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(repository: CryptoRepository, onBack: () -> Unit) {
    val vm: NotificationsViewModel = viewModel(factory = viewModelFactory { NotificationsViewModel(repository) })
    val context = LocalContext.current

    val enabled by vm.notificationsEnabled.collectAsState(initial = false)
    val minScore by vm.minScore.collectAsState(initial = 85)
    val minConfidence by vm.minConfidence.collectAsState(initial = 75)
    val directionFilter by vm.directionFilter.collectAsState(initial = "ALL")
    val watchCoins by vm.watchCoins.collectAsState(initial = emptySet())
    val symbolsState by vm.symbolsState.collectAsState()

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { /* result handled by the OS; worker checks permission before posting */ }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            ScreenTopBar(title = "Notifications", onBack = onBack)
        }
        item {
            SectionCard(title = "Signal Alerts") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Enable notifications", color = OnBackground, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Signal checks run about every 15 minutes via WorkManager while enabled.",
                            color = Muted,
                            fontSize = 13.sp,
                        )
                    }
                    Switch(checked = enabled, onCheckedChange = { vm.setEnabled(context, it) })
                }
            }
        }

        item {
            SectionCard(title = "Alert Filters") {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Minimum score: $minScore", color = OnBackground, fontSize = 14.sp)
                    Slider(
                        value = minScore.toFloat(),
                        onValueChange = { vm.setMinScore(it.roundToInt()) },
                        valueRange = 50f..100f,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text("Minimum confidence: $minConfidence%", color = OnBackground, fontSize = 14.sp)
                    Slider(
                        value = minConfidence.toFloat(),
                        onValueChange = { vm.setMinConfidence(it.roundToInt()) },
                        valueRange = 50f..100f,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text("Direction", color = OnBackground, fontSize = 14.sp)
                    FilterChips(
                        options = listOf("ALL", "LONG", "SHORT"),
                        selected = directionFilter,
                        onSelected = { vm.setDirectionFilter(it) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }

        item {
            SectionCard(title = "Watched Coins") {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().clickable { vm.watchAllCoins() },
                    ) {
                        Checkbox(
                            checked = watchCoins.isEmpty(),
                            onCheckedChange = { if (it) vm.watchAllCoins() },
                        )
                        Text("All coins", color = OnBackground, fontSize = 14.sp)
                    }
                    when (val s = symbolsState) {
                        is UiState.Loading -> Text("Loading symbols…", color = Muted, fontSize = 13.sp)
                        is UiState.Error -> Text(
                            "Could not load symbols: ${s.error.message()}",
                            color = ShortRed,
                            fontSize = 13.sp,
                        )
                        is UiState.Success -> {
                            s.data.forEach { sym ->
                                val checked = watchCoins.isEmpty() || sym in watchCoins
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth().clickable { vm.toggleCoin(sym) },
                                ) {
                                    Checkbox(checked = checked, onCheckedChange = { vm.toggleCoin(sym) })
                                    Text(sym, color = OnBackground, fontSize = 14.sp)
                                }
                            }
                        }
                        is UiState.Empty -> Text("No symbols available.", color = Muted, fontSize = 13.sp)
                    }
                    Text(
                        "An empty selection means all coins are watched.",
                        color = Muted,
                        fontSize = 12.sp,
                    )
                }
            }
        }

        item {
            SectionCard(title = "Permission") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "SignalPrime needs notification permission to deliver signal alerts.",
                        color = OnBackground,
                        fontSize = 14.sp,
                    )
                    Button(onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }) {
                        Text("Request Permission")
                    }
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                        Text(
                            "Notifications are granted by default on this Android version.",
                            color = Muted,
                            fontSize = 12.sp,
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
