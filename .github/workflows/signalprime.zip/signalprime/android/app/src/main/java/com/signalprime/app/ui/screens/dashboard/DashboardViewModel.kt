package com.signalprime.app.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signalprime.app.data.model.AppError
import com.signalprime.app.data.model.MarketOverview
import com.signalprime.app.data.model.Outcome
import com.signalprime.app.data.model.Signal
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class DashboardUiData(
    val market: MarketOverview,
    val signals: List<Signal>,
)

class DashboardViewModel(private val repo: CryptoRepository) : ViewModel() {

    private val _uiState = MutableStateFlow<UiState<DashboardUiData>>(UiState.Loading)
    val uiState: StateFlow<UiState<DashboardUiData>> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = UiState.Loading
            _uiState.value = try {
                coroutineScope {
                    val marketDeferred = async { repo.getMarket() }
                    val signalsDeferred = async { repo.getSignals(8) }
                    val marketOutcome = marketDeferred.await()
                    val signalsOutcome = signalsDeferred.await()
                    when {
                        marketOutcome is Outcome.Err -> UiState.Error(marketOutcome.error)
                        signalsOutcome is Outcome.Err -> UiState.Error(signalsOutcome.error)
                        marketOutcome is Outcome.Ok && signalsOutcome is Outcome.Ok ->
                            UiState.Success(DashboardUiData(marketOutcome.value, signalsOutcome.value))
                        else -> UiState.Error(AppError.Unknown("Unexpected response"))
                    }
                }
            } catch (e: Exception) {
                UiState.Error(AppError.Unknown(e.message ?: "Unexpected error"))
            }
        }
    }
}
