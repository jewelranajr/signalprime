package com.signalprime.app.ui.theme

import androidx.compose.ui.graphics.Color

// Dark trading palette.
val Background = Color(0xFF0B0E14)
val Surface = Color(0xFF131722)
val SurfaceVariant = Color(0xFF1C2230)
val OnBackground = Color(0xFFE8ECF3)
val Muted = Color(0xFF8A93A6)

// Primary / accent.
val Accent = Color(0xFF4C8DFF)

// Signal semantics.
val LongGreen = Color(0xFF22C55E)
val ShortRed = Color(0xFFEF4444)
val NoTradeAmber = Color(0xFFF5A524)

// Market bias.
val Bullish = Color(0xFF22C55E)
val Bearish = Color(0xFFEF4444)
