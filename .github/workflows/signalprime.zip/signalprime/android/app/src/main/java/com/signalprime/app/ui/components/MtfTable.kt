package com.signalprime.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprime.app.data.model.MtfEntry
import com.signalprime.app.ui.theme.OnBackground
import com.signalprime.app.ui.theme.SurfaceVariant
import com.signalprime.app.util.mtfBiasColor

/**
 * Multi-timeframe bias table: one row per timeframe with a colored bias label
 * and a score bar (score is -100..+100, normalized to 0..1).
 */
@Composable
fun MtfTable(entries: List<MtfEntry>, modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "Multi-Timeframe",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = OnBackground,
        )
        Spacer(Modifier.height(8.dp))
        entries.forEach { entry ->
            val biasColor = mtfBiasColor(entry.bias)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = entry.timeframe,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = OnBackground,
                    modifier = Modifier.width(52.dp),
                )
                Text(
                    text = entry.bias,
                    color = biasColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.width(88.dp),
                )
                LinearProgressIndicator(
                    progress = { (((entry.score ?: 0.0).toFloat() + 100f) / 200f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .weight(1f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = biasColor,
                    trackColor = SurfaceVariant,
                )
            }
        }
    }
}
