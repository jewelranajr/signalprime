package com.signalprime.app.util

import java.time.Duration
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Locale
import kotlin.math.abs

// Pure formatting helpers. No Android imports — safe for unit tests.

private val DATE_TIME_FORMATTER: DateTimeFormatter =
    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

private fun trimTrailingZeros(formatted: String): String {
    if (!formatted.contains('.')) return formatted
    return formatted.trimEnd('0').trimEnd('.')
}

private fun parseIsoToInstant(iso: String): Instant? {
    try {
        return OffsetDateTime.parse(iso, DateTimeFormatter.ISO_OFFSET_DATE_TIME).toInstant()
    } catch (_: DateTimeParseException) {
        // Fall back to Instant.parse below.
    }
    return try {
        Instant.parse(iso)
    } catch (_: DateTimeParseException) {
        null
    }
}

/** 1234.5 -> "1,234.50"; 45.6789 -> "45.68"; 0.123456 -> "0.123456"; null -> "—". */
fun formatPrice(value: Double?): String {
    if (value == null) return "—"
    val magnitude = abs(value)
    return when {
        magnitude >= 1000 -> String.format(Locale.US, "%,.2f", value)
        magnitude >= 100 -> String.format(Locale.US, "%.2f", value)
        magnitude >= 1 -> trimTrailingZeros(String.format(Locale.US, "%.4f", value))
        else -> trimTrailingZeros(String.format(Locale.US, "%.6f", value))
    }
}

/** 2.34 -> "+2.34%"; -1.2 -> "-1.20%"; null -> "—". */
fun formatPct(value: Double?): String {
    if (value == null) return "—"
    val sign = if (value < 0) "-" else "+"
    return sign + String.format(Locale.US, "%.2f%%", abs(value))
}

/** 1_200_000 -> "1.20M"; 34_000 -> "34.0K"; null -> "—". */
fun formatCompact(value: Double?): String {
    if (value == null) return "—"
    val magnitude = abs(value)
    return when {
        magnitude >= 1_000_000_000 -> String.format(Locale.US, "%.2fB", value / 1_000_000_000)
        magnitude >= 1_000_000 -> String.format(Locale.US, "%.2fM", value / 1_000_000)
        magnitude >= 1_000 -> String.format(Locale.US, "%.1fK", value / 1_000)
        else -> String.format(Locale.US, "%.2f", value)
    }
}

/** 1234.5 -> "$1,234.50"; null -> "—". */
fun formatUsd(value: Double?): String {
    if (value == null) return "—"
    return "$" + String.format(Locale.US, "%,.2f", value)
}

/** ISO timestamp -> "yyyy-MM-dd HH:mm" in the system zone; unparseable -> original string. */
fun formatDateTime(iso: String?): String {
    if (iso == null) return "—"
    val instant = parseIsoToInstant(iso) ?: return iso
    return DATE_TIME_FORMATTER.format(instant.atZone(ZoneId.systemDefault()))
}

/** ISO timestamp -> "5m ago", "2h ago", "3d ago", "just now". */
fun formatTimeAgo(iso: String?): String {
    if (iso == null) return "—"
    val instant = parseIsoToInstant(iso) ?: return iso
    val seconds = Duration.between(instant, Instant.now()).seconds.coerceAtLeast(0)
    return when {
        seconds < 60 -> "just now"
        seconds < 3600 -> "${seconds / 60}m ago"
        seconds < 86400 -> "${seconds / 3600}h ago"
        else -> "${seconds / 86400}d ago"
    }
}
