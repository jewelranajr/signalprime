package com.signalprime.app.ui.screens.riskcalc

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signalprime.app.data.model.EngineConfig
import com.signalprime.app.data.model.Outcome
import com.signalprime.app.data.repository.CryptoRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RiskCalculatorViewModel(
    private val repo: CryptoRepository,
) : ViewModel() {

    /** Engine config when reachable; null until loaded. Callers use EngineConfig() defaults as fallback. */
    private val _config = MutableStateFlow<EngineConfig?>(null)
    val config: StateFlow<EngineConfig?> = _config.asStateFlow()

    val defaultBalance: Flow<Double> = repo.settings.defaultBalance
    val defaultRiskPercent: Flow<Double> = repo.settings.defaultRiskPercent

    init {
        viewModelScope.launch {
            _config.value = (repo.getConfig() as? Outcome.Ok)?.value
        }
    }
}
