package com.signalprime.app.ui.screens.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signalprime.app.data.model.HistorySignal
import com.signalprime.app.data.model.Outcome
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PerfStats(
    val total: Int,
    val wins: Int,
    val losses: Int,
    val winRate: Double,
    val avgRr: Double?,
    val profitFactor: Double?,
)

/**
 * Client-side performance stats over the loaded history page.
 * avgRr is the mean of each signal's TP1 risk/reward; profitFactor is
 * gross winning pnl% / gross losing pnl% (null when there are no losses).
 */
fun computePerfStats(history: List<HistorySignal>): PerfStats {
    val total = history.size
    val wins = history.count { it.result == "WIN" }
    val losses = history.count { it.result == "LOSS" }
    val winRate = if (total > 0) wins * 100.0 / total else 0.0
    val rrs = history.mapNotNull { it.signal.riskReward?.tp1 }
    val avgRr = rrs.takeIf { it.isNotEmpty() }?.average()
    val pnls = history.mapNotNull { it.pnlPct }
    val grossWin = pnls.filter { it > 0 }.sum()
    val grossLoss = -pnls.filter { it < 0 }.sum()
    val profitFactor = if (grossLoss > 0) grossWin / grossLoss else null
    return PerfStats(total, wins, losses, winRate, avgRr, profitFactor)
}

class HistoryViewModel(
    private val repo: CryptoRepository,
) : ViewModel() {

    private val _direction = MutableStateFlow("ALL")
    val direction: StateFlow<String> = _direction.asStateFlow()

    private val _result = MutableStateFlow("ALL")
    val result: StateFlow<String> = _result.asStateFlow()

    private val _uiState = MutableStateFlow<UiState<List<HistorySignal>>>(UiState.Loading)
    val uiState: StateFlow<UiState<List<HistorySignal>>> = _uiState.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    init {
        refresh()
    }

    fun setDirection(d: String) {
        if (_direction.value == d) return
        _direction.value = d
        refresh()
    }

    fun setResult(r: String) {
        if (_result.value == r) return
        _result.value = r
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _isRefreshing.value = true
            val res = repo.getHistory(
                direction = _direction.value.takeIf { it != "ALL" },
                result = _result.value.takeIf { it != "ALL" },
                limit = 100,
            )
            _isRefreshing.value = false
            _uiState.value = when (res) {
                is Outcome.Ok -> UiState.Success(res.value)
                is Outcome.Err -> UiState.Error(res.error)
            }
        }
    }
}
