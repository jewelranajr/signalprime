package com.signalprime.app.ui.screens.riskcalc

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.signalprime.app.data.model.EngineConfig
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.ui.components.FilterChips
import com.signalprime.app.ui.components.ScreenTopBar
import com.signalprime.app.ui.components.SectionCard
import com.signalprime.app.ui.components.StatRow
import com.signalprime.app.ui.theme.LongGreen
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.NoTradeAmber
import com.signalprime.app.ui.theme.ShortRed
import com.signalprime.app.ui.viewmodel.viewModelFactory
import com.signalprime.app.util.RiskCalcResult
import com.signalprime.app.util.calculateRisk
import com.signalprime.app.util.formatCompact
import com.signalprime.app.util.formatPrice
import com.signalprime.app.util.formatUsd
import com.signalprime.app.util.riskReward

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RiskCalculatorScreen(repository: CryptoRepository, onBack: () -> Unit) {
    val vm: RiskCalculatorViewModel = viewModel(factory = viewModelFactory { RiskCalculatorViewModel(repository) })
    val config by vm.config.collectAsState()
    val defBalance by vm.defaultBalance.collectAsState(initial = 10000.0)
    val defRisk by vm.defaultRiskPercent.collectAsState(initial = 1.0)

    var balanceText by remember { mutableStateOf("") }
    var riskText by remember { mutableStateOf("") }
    var entryText by remember { mutableStateOf("") }
    var slText by remember { mutableStateOf("") }
    var tpText by remember { mutableStateOf("") }
    var direction by remember { mutableStateOf("LONG") }
    var calcResult by remember { mutableStateOf<RiskCalcResult?>(null) }
    var rrResult by remember { mutableStateOf<Double?>(null) }
    var riskPctUsed by remember { mutableStateOf<Double?>(null) }
    var errorText by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(defBalance) { if (balanceText.isEmpty()) balanceText = trimNum(defBalance) }
    LaunchedEffect(defRisk) { if (riskText.isEmpty()) riskText = trimNum(defRisk) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            ScreenTopBar(title = "Risk Calculator", onBack = onBack)
        }
        item {
            SectionCard(title = "Position Size Calculator") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DecimalField("Account balance (USD)", balanceText, { balanceText = it })
                    DecimalField("Risk %", riskText, { riskText = it })
                    Text("Direction", color = Muted, fontSize = 12.sp)
                    FilterChips(
                        options = listOf("LONG", "SHORT"),
                        selected = direction,
                        onSelected = { direction = it },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    DecimalField("Entry price", entryText, { entryText = it })
                    DecimalField("Stop-loss price", slText, { slText = it })
                    DecimalField("Take-profit price (optional)", tpText, { tpText = it })
                    errorText?.let { Text(it, color = ShortRed, fontSize = 13.sp) }
                    Button(
                        onClick = {
                            val balance = balanceText.toDoubleOrNull()
                            val riskPct = riskText.toDoubleOrNull()
                            val entryP = entryText.toDoubleOrNull()
                            val slP = slText.toDoubleOrNull()
                            if (balance == null || balance <= 0 || riskPct == null || riskPct <= 0 ||
                                entryP == null || entryP <= 0 || slP == null || slP <= 0 || entryP == slP
                            ) {
                                errorText = "Enter a valid balance, risk %, entry and stop-loss (entry ≠ stop-loss)."
                                calcResult = null
                                rrResult = null
                                riskPctUsed = null
                                return@Button
                            }
                            errorText = null
                            riskPctUsed = riskPct
                            calcResult = calculateRisk(balance, riskPct, entryP, slP)
                            if (calcResult == null) {
                                errorText = "Could not compute the position — check entry and stop-loss."
                            }
                            rrResult = tpText.toDoubleOrNull()?.let { tp ->
                                riskReward(entryP, slP, tp, direction == "LONG")
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("Calculate")
                    }
                }
            }
        }

        calcResult?.let { r ->
            item {
                ResultsCard(
                    result = r,
                    rr = rrResult,
                    riskPct = riskPctUsed,
                    config = config,
                )
            }
        }

        item {
            Text(
                "Position size respects stop-loss distance; never risk more than you can afford to lose.",
                color = Muted,
                fontSize = 12.sp,
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun ResultsCard(
    result: RiskCalcResult,
    rr: Double?,
    riskPct: Double?,
    config: EngineConfig?,
) {
    SectionCard(title = "Results") {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            StatRow("Risk amount", formatUsd(result.riskAmount), ShortRed)
            StatRow(
                "Stop distance",
                "${formatPrice(result.stopDistance)} (${"%.2f%%".format(result.stopDistancePct)})",
            )
            StatRow("Quantity", formatCompact(result.quantity))
            StatRow("Position value", formatUsd(result.positionValue))
            StatRow("Suggested leverage", "${trimNum(result.suggestedLeverage)}x")
            rr?.let {
                StatRow(
                    "Risk / Reward",
                    "%.2fR".format(it),
                    if (it >= 1.5) LongGreen else NoTradeAmber,
                )
            }
            val maxRisk = config?.maxRiskPercent ?: EngineConfig().maxRiskPercent
            if (riskPct != null && riskPct > maxRisk) {
                Text(
                    "Warning: ${"%.2f%%".format(riskPct)} exceeds the max recommended risk of ${trimNum(maxRisk)}%.",
                    color = ShortRed,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

@Composable
private fun DecimalField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth(),
    )
}

private fun trimNum(v: Double): String =
    if (v % 1.0 == 0.0) v.toInt().toString() else "%.2f".format(v)
