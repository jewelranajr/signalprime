package com.signalprime.app.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signalprime.app.data.model.HealthInfo
import com.signalprime.app.data.model.Outcome
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val repo: CryptoRepository,
) : ViewModel() {

    private val settings = repo.settings

    val baseUrl = MutableStateFlow("")
    val baseUrlError = MutableStateFlow<String?>(null)

    val balanceText = MutableStateFlow("")
    val balanceError = MutableStateFlow<String?>(null)

    val riskText = MutableStateFlow("")
    val riskError = MutableStateFlow<String?>(null)

    val message = MutableStateFlow<String?>(null)

    private val _testState = MutableStateFlow<UiState<HealthInfo>?>(null)
    val testState: StateFlow<UiState<HealthInfo>?> = _testState.asStateFlow()

    init {
        viewModelScope.launch {
            baseUrl.value = settings.baseUrl.first()
            balanceText.value = trimNum(settings.defaultBalance.first())
            riskText.value = trimNum(settings.defaultRiskPercent.first())
        }
    }

    fun saveBaseUrl() {
        val normalized = baseUrl.value.trim()
        if (!(normalized.startsWith("http://") || normalized.startsWith("https://"))) {
            baseUrlError.value = "URL must start with http:// or https://"
            return
        }
        baseUrlError.value = null
        viewModelScope.launch {
            settings.setBaseUrl(normalized)
            baseUrl.value = normalized
            message.value = "Base URL saved"
        }
    }

    fun testConnection() {
        viewModelScope.launch {
            _testState.value = UiState.Loading
            _testState.value = when (val res = repo.getHealth()) {
                is Outcome.Ok -> UiState.Success(res.value)
                is Outcome.Err -> UiState.Error(res.error)
            }
        }
    }

    fun saveBalance() {
        val v = balanceText.value.toDoubleOrNull()
        if (v == null || v <= 0) {
            balanceError.value = "Enter a balance greater than 0"
            return
        }
        balanceError.value = null
        viewModelScope.launch {
            settings.setDefaultBalance(v)
            message.value = "Default balance saved"
        }
    }

    fun saveRiskPercent() {
        val v = riskText.value.toDoubleOrNull()
        if (v == null || v <= 0 || v > 100) {
            riskError.value = "Enter a risk % between 0 and 100"
            return
        }
        riskError.value = null
        viewModelScope.launch {
            settings.setDefaultRiskPercent(v)
            message.value = "Default risk % saved"
        }
    }

    fun clearCache() {
        viewModelScope.launch {
            settings.clearCache()
            message.value = "Cache cleared"
        }
    }

    fun clearMessage() {
        message.value = null
    }

    private fun trimNum(v: Double): String =
        if (v % 1.0 == 0.0) v.toInt().toString() else v.toString()
}
