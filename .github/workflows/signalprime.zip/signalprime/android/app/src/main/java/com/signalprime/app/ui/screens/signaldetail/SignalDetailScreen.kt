package com.signalprime.app.ui.screens.signaldetail

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.signalprime.app.data.model.Direction
import com.signalprime.app.data.model.Signal
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.ui.components.DirectionBadge
import com.signalprime.app.ui.components.EmptyState
import com.signalprime.app.ui.components.ErrorState
import com.signalprime.app.ui.components.LoadingState
import com.signalprime.app.ui.components.MtfTable
import com.signalprime.app.ui.components.SectionCard
import com.signalprime.app.ui.components.StatRow
import com.signalprime.app.ui.components.StatusBadge
import com.signalprime.app.ui.theme.Accent
import com.signalprime.app.ui.theme.Background
import com.signalprime.app.ui.theme.LongGreen
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.NoTradeAmber
import com.signalprime.app.ui.theme.OnBackground
import com.signalprime.app.ui.theme.ShortRed
import com.signalprime.app.ui.theme.Surface
import com.signalprime.app.ui.viewmodel.viewModelFactory
import com.signalprime.app.util.formatCompact
import com.signalprime.app.util.formatDateTime
import com.signalprime.app.util.formatPrice
import com.signalprime.app.util.formatUsd
import com.signalprime.app.util.gapVerdict
import com.signalprime.app.util.regimeDisplayName

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignalDetailScreen(
    repository: CryptoRepository,
    symbol: String,
    onBack: () -> Unit,
    onCoinClick: (symbol: String) -> Unit,
) {
    val vm: SignalDetailViewModel = viewModel(factory = viewModelFactory { SignalDetailViewModel(repository, symbol) })
    val uiState by vm.uiState.collectAsState()
    val refreshing by vm.isRefreshing.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(symbol, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Surface,
                    titleContentColor = OnBackground,
                    navigationIconContentColor = OnBackground,
                ),
            )
        },
        containerColor = Background,
    ) { padding ->
        PullToRefreshBox(
            isRefreshing = refreshing,
            onRefresh = { vm.refresh() },
            modifier = Modifier.padding(padding).fillMaxSize(),
        ) {
            when (val s = uiState) {
                is UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(s.error, onRetry = { vm.refresh() })
                is UiState.Success -> SignalDetailContent(signal = s.data, onCoinClick = onCoinClick)
                is UiState.Empty -> EmptyState("No signal available for $symbol")
            }
        }
    }
}

@Composable
private fun SignalDetailContent(signal: Signal, onCoinClick: (String) -> Unit) {
    val score: Double? = when (signal.direction) {
        Direction.LONG -> signal.longScore
        Direction.SHORT -> signal.shortScore
        Direction.NO_TRADE -> listOfNotNull(signal.longScore, signal.shortScore).maxOrNull()
        Direction.UNKNOWN -> null
    }
    val hasTradePlan = signal.direction != Direction.NO_TRADE &&
        signal.entry != null && signal.stopLoss != null && signal.takeProfit != null

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { SignalHeader(signal = signal, score = score) }

        item {
            SectionCard(title = "Scores") {
                StatRow("Long score", signal.longScore?.let { "${it.toInt()}" } ?: "—", LongGreen)
                StatRow("Short score", signal.shortScore?.let { "${it.toInt()}" } ?: "—", ShortRed)
                StatRow(
                    "Direction gap",
                    signal.directionGap?.let { "%.1f".format(it) } ?: "—",
                )
                Text(gapVerdict(signal.directionGap, 10), color = Muted, fontSize = 13.sp)
            }
        }

        item {
            SectionCard(title = "Market Regime") {
                Text(
                    regimeDisplayName(signal.marketRegime),
                    color = OnBackground,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }

        if (hasTradePlan) {
            val e = signal.entry!!
            val sl = signal.stopLoss!!
            val tp = signal.takeProfit!!
            item {
                SectionCard(title = "Entry Zone") {
                    StatRow("Zone low", formatPrice(e.low))
                    StatRow("Zone high", formatPrice(e.high))
                    StatRow("Preferred entry", formatPrice(e.preferred), Accent)
                    StatRow("Entry type", e.type?.replace("_", " ") ?: "—")
                }
            }
            item {
                SectionCard(title = "Stop Loss") {
                    StatRow("Price", formatPrice(sl.price), ShortRed)
                    StatRow(
                        "Distance",
                        sl.distancePercent?.let { "%.2f%%".format(it) } ?: "—",
                    )
                    StatRow("Reason", sl.reason ?: "—")
                }
            }
            item {
                SectionCard(title = "Take Profit") {
                    StatRow("TP1", formatPrice(tp.tp1), LongGreen)
                    StatRow("TP2", formatPrice(tp.tp2), LongGreen)
                    StatRow("TP3", formatPrice(tp.tp3), LongGreen)
                }
            }
            signal.riskReward?.let { rr ->
                item {
                    SectionCard(title = "Risk/Reward") {
                        StatRow("RR to TP1", rr.tp1?.let { "%.2fR".format(it) } ?: "—")
                        StatRow("RR to TP2", rr.tp2?.let { "%.2fR".format(it) } ?: "—")
                        StatRow("RR to TP3", rr.tp3?.let { "%.2fR".format(it) } ?: "—")
                    }
                }
            }
            signal.position?.let { p ->
                item {
                    SectionCard(title = "Position") {
                        StatRow(
                            "Risk",
                            p.riskPercent?.let { "%.2f%%".format(it) } ?: "—",
                        )
                        StatRow("Risk amount", formatUsd(p.riskAmount))
                        StatRow("Quantity", formatCompact(p.quantity))
                        StatRow(
                            "Leverage",
                            p.leverage?.let { "${trimNum(it)}x" } ?: "—",
                        )
                        StatRow("Account balance", formatUsd(p.accountBalance))
                    }
                }
            }
        } else {
            item {
                Text(
                    "No trade setup — entry, stop-loss and take-profit levels are hidden while this signal is NO_TRADE.",
                    color = Muted,
                    fontSize = 13.sp,
                )
            }
        }

        item { WhyCard(signal = signal) }

        if (signal.warnings.isNotEmpty()) {
            item {
                SectionCard(title = "Warnings") {
                    signal.warnings.forEach { w ->
                        Text("⚠ $w", color = NoTradeAmber, fontSize = 14.sp)
                    }
                }
            }
        }

        if (signal.invalidation.isNotEmpty()) {
            item {
                SectionCard(title = "Invalidation") {
                    signal.invalidation.forEach { inv ->
                        Text("• $inv", color = OnBackground, fontSize = 14.sp)
                    }
                }
            }
        }

        item {
            SectionCard(title = "Signal Lifecycle") {
                StatRow("Created", formatDateTime(signal.createdAt))
                StatRow("Expires", formatDateTime(signal.expiresAt))
            }
        }

        item {
            SectionCard(title = "Multi-Timeframe") {
                MtfTable(signal.mtf)
            }
        }

        item {
            Button(onClick = { onCoinClick(signal.symbol) }, modifier = Modifier.fillMaxWidth()) {
                Text("Open Chart")
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SignalHeader(signal: Signal, score: Double?) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            DirectionBadge(signal.direction)
            Spacer(Modifier.width(8.dp))
            StatusBadge(signal.status)
        }
        Text(signal.symbol, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = OnBackground)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ScoreStat("Score", score?.let { "${it.toInt()} / 100" } ?: "—", Accent)
            ScoreStat("Confidence", signal.confidence?.let { "${it.toInt()}%" } ?: "—", OnBackground)
            ScoreStat(
                "Probability",
                signal.probabilityEstimate?.let { "${it.toInt()}%" } ?: "—",
                OnBackground,
            )
        }
    }
}

@Composable
private fun ScoreStat(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 12.sp, color = Muted)
        Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
private fun WhyCard(signal: Signal) {
    val title = when (signal.direction) {
        Direction.LONG -> "WHY LONG"
        Direction.SHORT -> "WHY SHORT"
        else -> "WHY NO TRADE"
    }
    if (signal.direction == Direction.NO_TRADE) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = NoTradeAmber.copy(alpha = 0.12f)),
            border = BorderStroke(1.dp, NoTradeAmber),
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NoTradeAmber)
                if (signal.reasons.isEmpty()) {
                    Text("No reasons provided.", color = Muted, fontSize = 14.sp)
                } else {
                    signal.reasons.forEach { r ->
                        Text("✓ $r", color = OnBackground, fontSize = 14.sp)
                    }
                }
            }
        }
    } else {
        SectionCard(title = title) {
            if (signal.reasons.isEmpty()) {
                Text("No reasons provided.", color = Muted, fontSize = 14.sp)
            } else {
                signal.reasons.forEach { r ->
                    Text("✓ $r", color = OnBackground, fontSize = 14.sp)
                }
            }
        }
    }
}

private fun trimNum(v: Double): String =
    if (v % 1.0 == 0.0) v.toInt().toString() else "%.2f".format(v)
