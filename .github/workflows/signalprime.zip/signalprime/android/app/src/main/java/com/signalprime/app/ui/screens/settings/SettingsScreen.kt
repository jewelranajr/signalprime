package com.signalprime.app.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.ui.components.ScreenTopBar
import com.signalprime.app.ui.components.SectionCard
import com.signalprime.app.ui.theme.LongGreen
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.OnBackground
import com.signalprime.app.ui.theme.ShortRed
import com.signalprime.app.ui.viewmodel.viewModelFactory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(repository: CryptoRepository, onBack: () -> Unit) {
    val vm: SettingsViewModel = viewModel(factory = viewModelFactory { SettingsViewModel(repository) })
    val baseUrl by vm.baseUrl.collectAsState()
    val baseUrlError by vm.baseUrlError.collectAsState()
    val balanceText by vm.balanceText.collectAsState()
    val balanceError by vm.balanceError.collectAsState()
    val riskText by vm.riskText.collectAsState()
    val riskError by vm.riskError.collectAsState()
    val message by vm.message.collectAsState()
    val testState by vm.testState.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            ScreenTopBar(title = "Settings", onBack = onBack)
        }
        message?.let {
            item {
                Text(it, color = LongGreen, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        item {
            SectionCard(title = "API Base URL") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = baseUrl,
                        onValueChange = { vm.baseUrl.value = it; vm.clearMessage() },
                        label = { Text("Base URL") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    baseUrlError?.let { Text(it, color = ShortRed, fontSize = 13.sp) }
                    Row {
                        Button(onClick = { vm.saveBaseUrl() }) { Text("Save") }
                        Spacer(Modifier.width(8.dp))
                        OutlinedButton(onClick = { vm.testConnection() }) { Text("Test Connection") }
                    }
                    when (val t = testState) {
                        null -> Unit
                        is UiState.Loading -> Text("Testing connection…", color = Muted, fontSize = 13.sp)
                        is UiState.Error -> Text(
                            "Connection failed: ${t.error.message()}",
                            color = ShortRed,
                            fontSize = 13.sp,
                        )
                        is UiState.Success -> Column {
                            Text("Connected", color = LongGreen, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                "Backend version ${t.data.version ?: "—"} • Data source: ${t.data.dataSource ?: "—"}",
                                color = Muted,
                                fontSize = 13.sp,
                            )
                        }
                        is UiState.Empty -> Unit
                    }
                }
            }
        }

        item {
            SectionCard(title = "Defaults") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Used when requesting new signals.", color = Muted, fontSize = 13.sp)
                    OutlinedTextField(
                        value = balanceText,
                        onValueChange = { vm.balanceText.value = it; vm.clearMessage() },
                        label = { Text("Default balance (USD)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    balanceError?.let { Text(it, color = ShortRed, fontSize = 13.sp) }
                    OutlinedTextField(
                        value = riskText,
                        onValueChange = { vm.riskText.value = it; vm.clearMessage() },
                        label = { Text("Default risk %") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    riskError?.let { Text(it, color = ShortRed, fontSize = 13.sp) }
                    Row {
                        Button(onClick = { vm.saveBalance() }) { Text("Save Balance") }
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { vm.saveRiskPercent() }) { Text("Save Risk %") }
                    }
                }
            }
        }

        item {
            SectionCard(title = "Cache") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Clears locally seen signal IDs so alerts can fire again.",
                        color = Muted,
                        fontSize = 13.sp,
                    )
                    Button(onClick = { vm.clearCache() }) { Text("Clear Cache") }
                }
            }
        }

        item {
            SectionCard(title = "Appearance") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Dark trading theme (always on)", color = OnBackground, fontSize = 14.sp)
                }
            }
        }

        item { Spacer(Modifier.height(8.dp)) }
    }
}
