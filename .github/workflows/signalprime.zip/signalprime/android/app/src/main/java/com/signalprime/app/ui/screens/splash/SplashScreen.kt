package com.signalprime.app.ui.screens.splash

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprime.app.ui.theme.Accent
import com.signalprime.app.ui.theme.Background
import com.signalprime.app.ui.theme.OnBackground
import kotlinx.coroutines.delay

/**
 * Branding splash. Holds for ~1.4s, then calls [onDone] so the host can
 * navigate to the main graph.
 */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1400)
        onDone()
    }

    val pulse = rememberInfiniteTransition(label = "splash_pulse")
    val dotAlpha by pulse.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "dot_alpha",
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = "SignalPrime",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = OnBackground,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "Master Signal AI",
            fontSize = 16.sp,
            color = Accent,
        )
        Spacer(Modifier.height(28.dp))
        Box(
            modifier = Modifier
                .size(12.dp)
                .alpha(dotAlpha)
                .background(Accent, CircleShape),
        )
    }
}
