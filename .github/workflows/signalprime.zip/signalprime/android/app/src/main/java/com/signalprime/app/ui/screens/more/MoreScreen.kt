package com.signalprime.app.ui.screens.more

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprime.app.ui.theme.Accent
import com.signalprime.app.ui.theme.Background
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.OnBackground
import com.signalprime.app.ui.theme.Surface as ThemeSurface

private data class MoreItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val route: String,
)

private val MORE_ITEMS = listOf(
    MoreItem(
        title = "Risk Calculator",
        subtitle = "Position sizing & leverage",
        icon = Icons.Filled.Calculate,
        route = "risk_calculator",
    ),
    MoreItem(
        title = "Backtest",
        subtitle = "Strategy performance tester",
        icon = Icons.Filled.QueryStats,
        route = "backtest",
    ),
    MoreItem(
        title = "Notifications",
        subtitle = "Signal alerts",
        icon = Icons.Filled.Notifications,
        route = "notifications",
    ),
    MoreItem(
        title = "Settings",
        subtitle = "API URL & preferences",
        icon = Icons.Filled.Settings,
        route = "settings",
    ),
    MoreItem(
        title = "About",
        subtitle = "Version & disclaimer",
        icon = Icons.Filled.Info,
        route = "about",
    ),
)

/**
 * Overflow menu: rows navigate to feature screens owned by other agents.
 * Route strings are literal and must match the navigation graph's Routes.
 */
@Composable
fun MoreScreen(onNavigate: (route: String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background),
    ) {
        Text(
            text = "More",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = OnBackground,
            modifier = Modifier.padding(16.dp),
        )
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(MORE_ITEMS) { item ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clickable { onNavigate(item.route) },
                    shape = RoundedCornerShape(12.dp),
                    color = ThemeSurface,
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = null,
                            tint = Accent,
                            modifier = Modifier.size(24.dp),
                        )
                        Spacer(Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                color = OnBackground,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = item.subtitle,
                                fontSize = 13.sp,
                                color = Muted,
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Open ${item.title}",
                            tint = Muted,
                        )
                    }
                }
            }
        }
    }
}
