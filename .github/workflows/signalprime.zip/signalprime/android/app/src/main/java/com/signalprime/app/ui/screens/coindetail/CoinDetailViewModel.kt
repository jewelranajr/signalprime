package com.signalprime.app.ui.screens.coindetail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signalprime.app.data.model.Candle
import com.signalprime.app.data.model.Outcome
import com.signalprime.app.data.model.RegimeInfo
import com.signalprime.app.data.model.Signal
import com.signalprime.app.data.model.Ticker
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class CoinDetailData(
    val ticker: Ticker,
    val candles: List<Candle>,
    val signal: Signal?,
    val regime: RegimeInfo?,
)

class CoinDetailViewModel(
    private val repo: CryptoRepository,
    private val symbol: String,
) : ViewModel() {

    private val _timeframe = MutableStateFlow("1h")
    val timeframe: StateFlow<String> = _timeframe.asStateFlow()

    private val _uiState = MutableStateFlow<UiState<CoinDetailData>>(UiState.Loading)
    val uiState: StateFlow<UiState<CoinDetailData>> = _uiState.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    init {
        refresh()
    }

    fun setTimeframe(tf: String) {
        if (_timeframe.value == tf) return
        _timeframe.value = tf
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _isRefreshing.value = true
            val tf = _timeframe.value
            val tickerRes = repo.getTicker(symbol)
            val candlesRes = repo.getCandles(symbol, tf, 200)
            val regimeRes = repo.getRegime(symbol)
            // Signal is optional: a failure here must not fail the whole screen.
            val signalRes = try {
                val balance = repo.settings.defaultBalance.first()
                val risk = repo.settings.defaultRiskPercent.first()
                repo.getSignal(symbol, tf, balance, risk)
            } catch (_: Exception) {
                null
            }
            _isRefreshing.value = false
            _uiState.value = when {
                tickerRes is Outcome.Err -> UiState.Error(tickerRes.error)
                candlesRes is Outcome.Err -> UiState.Error(candlesRes.error)
                else -> UiState.Success(
                    CoinDetailData(
                        ticker = (tickerRes as Outcome.Ok).value,
                        candles = (candlesRes as Outcome.Ok).value,
                        signal = (signalRes as? Outcome.Ok)?.value,
                        regime = (regimeRes as? Outcome.Ok)?.value,
                    ),
                )
            }
        }
    }
}
