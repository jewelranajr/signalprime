package com.signalprime.app.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprime.app.data.model.Direction
import com.signalprime.app.data.model.SignalStatus
import com.signalprime.app.util.directionColor
import com.signalprime.app.util.displayName
import com.signalprime.app.util.statusColor

/**
 * Small pill badge showing a signal direction. Always carries a text label —
 * color is never the only indicator.
 */
@Composable
fun DirectionBadge(direction: Direction, modifier: Modifier = Modifier) {
    val color = directionColor(direction)
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.15f),
    ) {
        Text(
            text = direction.displayName(),
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
        )
    }
}

/** Small pill badge showing a signal lifecycle status, with text label. */
@Composable
fun StatusBadge(status: SignalStatus, modifier: Modifier = Modifier) {
    val color = statusColor(status)
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.15f),
    ) {
        Text(
            text = status.displayName(),
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
        )
    }
}
