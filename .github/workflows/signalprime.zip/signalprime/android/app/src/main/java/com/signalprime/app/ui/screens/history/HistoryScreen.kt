package com.signalprime.app.ui.screens.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.signalprime.app.data.model.HistorySignal
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.ui.components.EmptyState
import com.signalprime.app.ui.components.ErrorState
import com.signalprime.app.ui.components.FilterChips
import com.signalprime.app.ui.components.LoadingState
import com.signalprime.app.ui.components.SectionCard
import com.signalprime.app.ui.components.StatRow
import com.signalprime.app.ui.theme.LongGreen
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.NoTradeAmber
import com.signalprime.app.ui.theme.OnBackground
import com.signalprime.app.ui.theme.ShortRed
import com.signalprime.app.ui.theme.Surface
import com.signalprime.app.ui.viewmodel.viewModelFactory
import com.signalprime.app.util.formatPct

private val DIRECTION_OPTIONS = listOf("ALL", "LONG", "SHORT")
private val RESULT_OPTIONS = listOf("ALL", "WIN", "LOSS", "ACTIVE", "EXPIRED")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    repository: CryptoRepository,
    onSignalClick: (symbol: String) -> Unit,
) {
    val vm: HistoryViewModel = viewModel(factory = viewModelFactory { HistoryViewModel(repository) })
    val uiState by vm.uiState.collectAsState()
    val refreshing by vm.isRefreshing.collectAsState()
    val direction by vm.direction.collectAsState()
    val result by vm.result.collectAsState()

    PullToRefreshBox(
        isRefreshing = refreshing,
        onRefresh = { vm.refresh() },
        modifier = Modifier.fillMaxSize(),
    ) {
        when (val s = uiState) {
            is UiState.Loading -> LoadingState()
            is UiState.Error -> ErrorState(s.error, onRetry = { vm.refresh() })
            is UiState.Success -> HistoryContent(
                history = s.data,
                direction = direction,
                result = result,
                onDirection = { vm.setDirection(it) },
                onResult = { vm.setResult(it) },
                onSignalClick = onSignalClick,
            )
            is UiState.Empty -> EmptyState("No history found")
        }
    }
}

@Composable
private fun HistoryContent(
    history: List<HistorySignal>,
    direction: String,
    result: String,
    onDirection: (String) -> Unit,
    onResult: (String) -> Unit,
    onSignalClick: (String) -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Direction", color = Muted, fontSize = 12.sp)
                FilterChips(
                    options = DIRECTION_OPTIONS,
                    selected = direction,
                    onSelected = onDirection,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Result", color = Muted, fontSize = 12.sp)
                FilterChips(
                    options = RESULT_OPTIONS,
                    selected = result,
                    onSelected = onResult,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        item { PerfCard(computePerfStats(history)) }
        if (history.isEmpty()) {
            item { EmptyState("No history matches these filters") }
        } else {
            items(history, key = { it.signal.signalId }) { h ->
                HistoryRow(historySignal = h, onSignalClick = onSignalClick)
            }
        }
    }
}

@Composable
private fun PerfCard(stats: PerfStats) {
    SectionCard(title = "Performance") {
        StatRow("Total signals", "${stats.total}")
        StatRow("Wins / Losses", "${stats.wins} / ${stats.losses}")
        StatRow(
            "Win rate",
            "%.1f%%".format(stats.winRate),
            if (stats.winRate >= 50) LongGreen else ShortRed,
        )
        StatRow("Avg RR", stats.avgRr?.let { "%.2fR".format(it) } ?: "—")
        StatRow("Profit factor", stats.profitFactor?.let { "%.2f".format(it) } ?: "—")
        Text(
            "Based on recorded history only — past performance does not guarantee future results.",
            color = Muted,
            fontSize = 12.sp,
        )
    }
}

@Composable
private fun HistoryRow(historySignal: HistorySignal, onSignalClick: (String) -> Unit) {
    val signal = historySignal.signal
    Card(
        onClick = { onSignalClick(signal.symbol) },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Surface),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(signal.symbol, fontWeight = FontWeight.Bold, color = OnBackground, fontSize = 15.sp)
                Text(
                    historySignal.result ?: "UNKNOWN",
                    color = resultColor(historySignal.result),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            val pnl = historySignal.pnlPct
            Text(
                formatPct(pnl),
                color = pnlColor(pnl),
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
            )
        }
    }
}

private fun resultColor(result: String?): Color = when (result) {
    "WIN" -> LongGreen
    "LOSS" -> ShortRed
    "EXPIRED" -> NoTradeAmber
    else -> Muted
}

private fun pnlColor(pnlPct: Double?): Color = when {
    pnlPct == null -> Muted
    pnlPct >= 0 -> LongGreen
    else -> ShortRed
}
