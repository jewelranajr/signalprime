package com.signalprime.app.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/** True when the device currently has a usable internet-capable network. */
fun isOnline(context: Context): Boolean {
    val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        ?: return false
    val network = manager.activeNetwork ?: return false
    val capabilities = manager.getNetworkCapabilities(network) ?: return false
    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}
