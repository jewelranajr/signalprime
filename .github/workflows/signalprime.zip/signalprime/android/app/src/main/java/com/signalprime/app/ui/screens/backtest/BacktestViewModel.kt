package com.signalprime.app.ui.screens.backtest

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signalprime.app.data.model.BacktestRequest
import com.signalprime.app.data.model.BacktestResult
import com.signalprime.app.data.model.Outcome
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class BacktestViewModel(
    private val repo: CryptoRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow<UiState<BacktestResult>?>(null)
    val uiState: StateFlow<UiState<BacktestResult>?> = _uiState.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    fun runBacktest(request: BacktestRequest) {
        viewModelScope.launch {
            _isRunning.value = true
            _uiState.value = when (val res = repo.runBacktest(request)) {
                is Outcome.Ok -> UiState.Success(res.value)
                is Outcome.Err -> UiState.Error(res.error)
            }
            _isRunning.value = false
        }
    }
}
