package com.signalprime.app.ui.screens.signaldetail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signalprime.app.data.model.Outcome
import com.signalprime.app.data.model.Signal
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class SignalDetailViewModel(
    private val repo: CryptoRepository,
    private val symbol: String,
) : ViewModel() {

    private val _uiState = MutableStateFlow<UiState<Signal>>(UiState.Loading)
    val uiState: StateFlow<UiState<Signal>> = _uiState.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _isRefreshing.value = true
            val balance = repo.settings.defaultBalance.first()
            val riskPercent = repo.settings.defaultRiskPercent.first()
            _uiState.value = when (val res = repo.getSignal(symbol, "1h", balance, riskPercent)) {
                is Outcome.Ok -> UiState.Success(res.value)
                is Outcome.Err -> UiState.Error(res.error)
            }
            _isRefreshing.value = false
        }
    }
}
