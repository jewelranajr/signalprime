package com.signalprime.app.ui.screens.scanner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signalprime.app.data.model.AppError
import com.signalprime.app.data.model.Outcome
import com.signalprime.app.data.model.ScannerData
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ScannerViewModel(private val repo: CryptoRepository) : ViewModel() {

    private val _uiState = MutableStateFlow<UiState<ScannerData>>(UiState.Loading)
    val uiState: StateFlow<UiState<ScannerData>> = _uiState.asStateFlow()

    val filter = MutableStateFlow("ALL")

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = UiState.Loading
            _uiState.value = try {
                when (val outcome = repo.getScanner(50)) {
                    is Outcome.Ok -> UiState.Success(outcome.value)
                    is Outcome.Err -> UiState.Error(outcome.error)
                }
            } catch (e: Exception) {
                UiState.Error(AppError.Unknown(e.message ?: "Unexpected error"))
            }
        }
    }

    fun toggleWatch(symbol: String) {
        viewModelScope.launch {
            repo.settings.toggleWatchCoin(symbol)
        }
    }
}
