package com.signalprime.app.ui.screens.backtest

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.signalprime.app.data.model.BacktestRequest
import com.signalprime.app.data.model.BacktestResult
import com.signalprime.app.data.model.BacktestTrade
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.ui.components.EmptyState
import com.signalprime.app.ui.components.ErrorState
import com.signalprime.app.ui.components.ScreenTopBar
import com.signalprime.app.ui.components.SectionCard
import com.signalprime.app.ui.theme.LongGreen
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.OnBackground
import com.signalprime.app.ui.theme.ShortRed
import com.signalprime.app.ui.theme.Surface
import com.signalprime.app.ui.viewmodel.viewModelFactory
import com.signalprime.app.util.Constants
import com.signalprime.app.util.formatDateTime
import com.signalprime.app.util.formatPct
import com.signalprime.app.util.formatPrice
import com.signalprime.app.util.formatUsd
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BacktestScreen(repository: CryptoRepository, onBack: () -> Unit) {
    val vm: BacktestViewModel = viewModel(factory = viewModelFactory { BacktestViewModel(repository) })
    val resultState by vm.uiState.collectAsState()
    val running by vm.isRunning.collectAsState()

    var symbol by remember { mutableStateOf("BTCUSDT") }
    var timeframe by remember { mutableStateOf(Constants.BACKTEST_TIMEFRAMES.firstOrNull() ?: "1h") }
    var start by remember { mutableStateOf("2024-01-01") }
    var end by remember { mutableStateOf(LocalDate.now().toString()) }
    var balanceText by remember { mutableStateOf("10000") }
    var riskText by remember { mutableStateOf("1") }
    var formError by remember { mutableStateOf<String?>(null) }

    fun run() {
        val balance = balanceText.toDoubleOrNull()
        val riskPct = riskText.toDoubleOrNull()
        formError = when {
            symbol.isBlank() -> "Enter a symbol (e.g. BTCUSDT)."
            start.isBlank() || end.isBlank() -> "Enter start and end dates as YYYY-MM-DD."
            start >= end -> "Start date must be before end date."
            balance == null || balance <= 0 -> "Initial balance must be greater than 0."
            riskPct == null || riskPct <= 0 || riskPct > 100 -> "Risk % must be between 0 and 100."
            else -> null
        }
        if (formError != null) return
        vm.runBacktest(
            BacktestRequest(
                symbol = symbol.trim().uppercase(),
                timeframe = timeframe,
                start = start.trim(),
                end = end.trim(),
                initialBalance = balance!!,
                riskPercent = riskPct!!,
            ),
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            ScreenTopBar(title = "Backtest", onBack = onBack)
        }
        item {
            SectionCard(title = "Backtest Setup") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = symbol,
                        onValueChange = { symbol = it },
                        label = { Text("Symbol") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    TimeframeDropdown(timeframe = timeframe, onSelected = { timeframe = it })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = start,
                            onValueChange = { start = it },
                            label = { Text("Start (YYYY-MM-DD)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = end,
                            onValueChange = { end = it },
                            label = { Text("End (YYYY-MM-DD)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = balanceText,
                            onValueChange = { balanceText = it },
                            label = { Text("Initial balance") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = riskText,
                            onValueChange = { riskText = it },
                            label = { Text("Risk %") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                        )
                    }
                    formError?.let { Text(it, color = ShortRed, fontSize = 13.sp) }
                    Button(onClick = { run() }, enabled = !running, modifier = Modifier.fillMaxWidth()) {
                        if (running) {
                            CircularProgressIndicator(
                                modifier = Modifier.height(20.dp),
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Text("Run Backtest")
                        }
                    }
                }
            }
        }

        when (val s = resultState) {
            null -> {
                item { EmptyState("Configure the backtest above and press Run Backtest.") }
            }
            is UiState.Loading -> {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }
            is UiState.Error -> item { ErrorState(s.error, onRetry = { run() }) }
            is UiState.Success -> {
                item { SummaryCard(s.data) }
                item {
                    Text(
                        "Trades (showing ${minOf(30, s.data.trades.size)} of ${s.data.trades.size})",
                        color = OnBackground,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                    )
                }
                if (s.data.trades.isEmpty()) {
                    item { EmptyState("No trades in this backtest window.") }
                } else {
                    items(s.data.trades.take(30)) { trade -> TradeRow(trade) }
                }
                item {
                    Text(
                        "Backtests use historical data; not a guarantee of future performance.",
                        color = Muted,
                        fontSize = 12.sp,
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }
            is UiState.Empty -> item { EmptyState("No backtest result.") }
        }
    }
}

@Composable
private fun TimeframeDropdown(timeframe: String, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = timeframe,
            onValueChange = {},
            readOnly = true,
            label = { Text("Timeframe") },
            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = "Select timeframe") },
            modifier = Modifier.fillMaxWidth().clickable { expanded = true },
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            Constants.BACKTEST_TIMEFRAMES.forEach { tf ->
                DropdownMenuItem(
                    text = { Text(tf) },
                    onClick = { onSelected(tf); expanded = false },
                )
            }
        }
    }
}

@Composable
private fun SummaryCard(r: BacktestResult) {
    SectionCard(title = "Summary — ${r.symbol} ${r.timeframe}") {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(
                listOf(
                    Triple("Total trades", "${r.totalTrades}", OnBackground),
                    Triple("Win rate", r.winRate?.let { "%.1f%%".format(it) } ?: "—", OnBackground),
                ),
                listOf(
                    Triple("Wins", "${r.wins}", LongGreen),
                    Triple("Losses", "${r.losses}", ShortRed),
                ),
                listOf(
                    Triple("Net PnL", formatUsd(r.netPnl), pnlColor(r.netPnl)),
                    Triple("Net PnL %", formatPct(r.netPnlPct), pnlColor(r.netPnlPct)),
                ),
                listOf(
                    Triple("Max drawdown", formatPct(r.maxDrawdownPct), ShortRed),
                    Triple("Profit factor", r.profitFactor?.let { "%.2f".format(it) } ?: "—", OnBackground),
                ),
                listOf(
                    Triple("Avg RR", r.avgRr?.let { "%.2fR".format(it) } ?: "—", OnBackground),
                ),
            ).forEach { row ->
                Row(modifier = Modifier.fillMaxWidth()) {
                    row.forEach { (label, value, color) ->
                        StatBox(label = label, value = value, color = color, modifier = Modifier.weight(1f))
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun StatBox(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 11.sp, color = Muted)
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = color)
    }
}

@Composable
private fun TradeRow(t: BacktestTrade) {
    val win = (t.pnlPct ?: 0.0) >= 0
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Surface),
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    formatDateTime(t.entryTime),
                    color = Muted,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    t.direction ?: "—",
                    color = directionTextColor(t.direction),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${formatPrice(t.entryPrice)} → ${formatPrice(t.exitPrice)}",
                    color = OnBackground,
                    fontSize = 13.sp,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    formatPct(t.pnlPct),
                    color = if (win) LongGreen else ShortRed,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Exit: ${t.result ?: "—"}",
                    color = Muted,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    if (win) "WIN" else "LOSS",
                    color = if (win) LongGreen else ShortRed,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

private fun directionTextColor(direction: String?): Color = when (direction?.uppercase()) {
    "LONG" -> LongGreen
    "SHORT" -> ShortRed
    else -> Muted
}

private fun pnlColor(pnl: Double?): Color = when {
    pnl == null -> Muted
    pnl >= 0 -> LongGreen
    else -> ShortRed
}
