package com.signalprime.app.ui.components.chart

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprime.app.data.model.Candle
import com.signalprime.app.data.model.Entry
import com.signalprime.app.data.model.StopLoss
import com.signalprime.app.data.model.TakeProfit
import com.signalprime.app.ui.components.EmptyState
import com.signalprime.app.ui.theme.Accent
import com.signalprime.app.ui.theme.LongGreen
import com.signalprime.app.ui.theme.ShortRed
import com.signalprime.app.util.formatPrice

private const val MAX_CANDLES = 120
private val EMA50_ORANGE = Color(0xFFFF9800)
private val EMA200_PURPLE = Color(0xFFB388FF)
private val ZONE_BLUE = Color(0xFF448AFF)
private val AXIS_GRAY = Color(0xFF8A93A6)

private data class ComputedSeries(
    val data: List<Candle>,
    val ema20: List<Double?>,
    val ema50: List<Double?>,
    val ema200: List<Double?>,
    val vwap: List<Double?>,
    val supports: List<Double>,
    val resistances: List<Double>,
)

/**
 * Candlestick chart with on-device indicator overlays (EMA 20/50/200, VWAP),
 * swing support/resistance zones, and the active signal's entry zone,
 * stop-loss and take-profit levels. Renders the last [MAX_CANDLES] candles.
 */
@Composable
fun CandleChart(
    candles: List<Candle>,
    entry: Entry? = null,
    stopLoss: StopLoss? = null,
    takeProfit: TakeProfit? = null,
    modifier: Modifier = Modifier,
) {
    if (candles.isEmpty()) {
        Box(modifier = modifier) {
            EmptyState("No chart data available")
        }
        return
    }
    val density = LocalDensity.current
    val computed = remember(candles) {
        val data = candles.takeLast(MAX_CANDLES)
        val closes = data.map { it.close }
        val (supports, resistances) = findSwingLevels(data, 5)
        ComputedSeries(
            data = data,
            ema20 = computeEma(closes, 20),
            ema50 = computeEma(closes, 50),
            ema200 = computeEma(closes, 200),
            vwap = computeVwap(data),
            supports = supports,
            resistances = resistances,
        )
    }
    val labelPaint = remember(density) {
        android.graphics.Paint().apply {
            isAntiAlias = true
            textSize = with(density) { 10.sp.toPx() }
        }
    }

    Canvas(modifier = modifier.fillMaxWidth()) {
        val data = computed.data
        val n = data.size
        if (n == 0) return@Canvas
        val axisW = with(density) { 56.dp.toPx() }
        val chartW = size.width - axisW
        if (chartW <= 0f) return@Canvas

        // Price range across candles + signal overlays.
        var minP = Double.MAX_VALUE
        var maxP = -Double.MAX_VALUE
        fun include(p: Double?) {
            if (p == null) return
            if (p < minP) minP = p
            if (p > maxP) maxP = p
        }
        data.forEach { include(it.high); include(it.low) }
        entry?.let { include(it.low); include(it.high); include(it.preferred) }
        stopLoss?.let { include(it.price) }
        takeProfit?.let { include(it.tp1); include(it.tp2); include(it.tp3) }
        if (minP >= maxP) {
            minP -= 1.0
            maxP += 1.0
        }
        val pad = (maxP - minP) * 0.06
        val lo = minP - pad
        val hi = maxP + pad
        fun y(price: Double): Float = ((hi - price) / (hi - lo) * size.height).toFloat()
        val slot = chartW / n

        fun dashedHLine(price: Double?, color: Color, label: String?, labelColor: Color) {
            if (price == null) return
            val yy = y(price)
            drawLine(
                color = color,
                start = Offset(0f, yy),
                end = Offset(chartW, yy),
                strokeWidth = 2f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f),
            )
            label?.let {
                labelPaint.color = labelColor.toArgb()
                drawContext.canvas.nativeCanvas.drawText(it, 6f, yy - 6f, labelPaint)
            }
        }

        fun drawSeries(values: List<Double?>, color: Color, dashed: Boolean = false) {
            val pts = values.mapIndexedNotNull { i, v ->
                v?.let { Offset(i * slot + slot / 2f, y(it)) }
            }
            if (pts.size < 2) return
            val path = Path().apply {
                moveTo(pts[0].x, pts[0].y)
                for (k in 1 until pts.size) lineTo(pts[k].x, pts[k].y)
            }
            drawPath(
                path = path,
                color = color,
                style = Stroke(
                    width = 2f,
                    pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f) else null,
                ),
            )
        }

        // Grid + price axis labels (right).
        labelPaint.color = AXIS_GRAY.toArgb()
        for (k in 0..4) {
            val price = lo + (hi - lo) * k / 4.0
            val yy = y(price)
            drawLine(Color.Gray.copy(alpha = 0.25f), Offset(0f, yy), Offset(chartW, yy), strokeWidth = 1f)
            drawContext.canvas.nativeCanvas.drawText(formatPrice(price), chartW + 6f, yy + 4f, labelPaint)
        }

        // Support (green) / resistance (red) translucent zones.
        val band = (hi - lo) * 0.008
        computed.supports.forEach { s ->
            drawRect(
                color = LongGreen.copy(alpha = 0.10f),
                topLeft = Offset(0f, y(s + band)),
                size = Size(chartW, y(s - band) - y(s + band)),
            )
        }
        computed.resistances.forEach { r ->
            drawRect(
                color = ShortRed.copy(alpha = 0.10f),
                topLeft = Offset(0f, y(r + band)),
                size = Size(chartW, y(r - band) - y(r + band)),
            )
        }

        // Entry zone (direction-neutral blue band) + preferred entry dashed line.
        entry?.let { e ->
            if (e.low != null && e.high != null) {
                drawRect(
                    color = ZONE_BLUE.copy(alpha = 0.12f),
                    topLeft = Offset(0f, y(e.high)),
                    size = Size(chartW, y(e.low) - y(e.high)),
                )
            }
            dashedHLine(e.preferred, ZONE_BLUE, "Entry", ZONE_BLUE)
        }

        // Stop-loss (red dashed) and take-profits (green dashed, labeled).
        dashedHLine(stopLoss?.price, ShortRed, "SL", ShortRed)
        takeProfit?.let { tp ->
            dashedHLine(tp.tp1, LongGreen, "TP1", LongGreen)
            dashedHLine(tp.tp2, LongGreen, "TP2", LongGreen)
            dashedHLine(tp.tp3, LongGreen, "TP3", LongGreen)
        }

        // Indicator overlays.
        drawSeries(computed.ema20, Accent)
        drawSeries(computed.ema50, EMA50_ORANGE)
        drawSeries(computed.ema200, EMA200_PURPLE)
        drawSeries(computed.vwap, Color.Gray, dashed = true)

        // Candles on top: wicks + bodies (green up, red down).
        val bodyW = (slot * 0.7f).coerceAtLeast(2f)
        data.forEachIndexed { i, c ->
            val cx = i * slot + slot / 2f
            val color = if (c.close >= c.open) LongGreen else ShortRed
            drawLine(color, Offset(cx, y(c.high)), Offset(cx, y(c.low)), strokeWidth = 2f)
            val top = y(maxOf(c.open, c.close))
            val bottom = y(minOf(c.open, c.close))
            drawRect(color, Offset(cx - bodyW / 2f, top), Size(bodyW, (bottom - top).coerceAtLeast(2f)))
        }
    }
}
