package com.signalprime.app.util

/** Shared app-wide constants. */
object Constants {
    val TIMEFRAMES = listOf("5m", "15m", "1h", "4h", "1D")

    const val DEFAULT_CANDLE_LIMIT = 200
    const val DEFAULT_SIGNAL_LIMIT = 20
    const val SCANNER_LIMIT = 50

    val BACKTEST_TIMEFRAMES = listOf("15m", "1h", "4h", "1D")
}
