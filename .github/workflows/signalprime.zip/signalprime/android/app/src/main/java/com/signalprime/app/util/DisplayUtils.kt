package com.signalprime.app.util

import androidx.compose.ui.graphics.Color
import com.signalprime.app.data.model.Direction
import com.signalprime.app.data.model.SignalStatus
import com.signalprime.app.ui.theme.Accent
import com.signalprime.app.ui.theme.LongGreen
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.NoTradeAmber
import com.signalprime.app.ui.theme.ShortRed

// Display mappings for backend enums. Direction/SignalStatus come from
// com.signalprime.app.data.model (built by the data-layer agent).

fun Direction.displayName(): String = when (this) {
    Direction.LONG -> "LONG"
    Direction.SHORT -> "SHORT"
    Direction.NO_TRADE -> "NO TRADE"
    Direction.UNKNOWN -> "—"
}

fun directionColor(direction: Direction): Color = when (direction) {
    Direction.LONG -> LongGreen
    Direction.SHORT -> ShortRed
    Direction.NO_TRADE -> NoTradeAmber
    Direction.UNKNOWN -> Muted
}

fun SignalStatus.displayName(): String = when (this) {
    SignalStatus.WAITING -> "WAITING"
    SignalStatus.ACTIVE -> "ACTIVE"
    SignalStatus.TP1_HIT -> "TP1 HIT"
    SignalStatus.TP2_HIT -> "TP2 HIT"
    SignalStatus.TP3_HIT -> "TP3 HIT"
    SignalStatus.STOPPED -> "STOPPED"
    SignalStatus.INVALIDATED -> "INVALIDATED"
    SignalStatus.EXPIRED -> "EXPIRED"
    SignalStatus.CLOSED -> "CLOSED"
    SignalStatus.UNKNOWN -> "—"
}

fun statusColor(status: SignalStatus): Color = when (status) {
    SignalStatus.ACTIVE -> Accent
    SignalStatus.TP1_HIT, SignalStatus.TP2_HIT, SignalStatus.TP3_HIT -> LongGreen
    SignalStatus.STOPPED, SignalStatus.INVALIDATED -> ShortRed
    SignalStatus.EXPIRED, SignalStatus.CLOSED -> Muted
    SignalStatus.WAITING -> NoTradeAmber
    SignalStatus.UNKNOWN -> Muted
}

/** "STRONG_BULL" -> "Strong Bullish"; "HIGH_VOLATILITY" -> "High Volatility"; null -> "—". */
fun regimeDisplayName(regime: String?): String {
    if (regime.isNullOrBlank()) return "—"
    return regime.split("_").joinToString(" ") { word ->
        when (word.uppercase()) {
            "BULL" -> "Bullish"
            "BEAR" -> "Bearish"
            else -> word.lowercase().replaceFirstChar { it.uppercase() }
        }
    }
}

fun mtfBiasColor(bias: String): Color = when (bias.uppercase()) {
    "BULLISH" -> LongGreen
    "BEARISH" -> ShortRed
    else -> Muted
}

fun gapVerdict(gap: Double?, minGap: Int): String {
    if (gap == null) return "—"
    return if (gap >= minGap) "Strong directional confirmation" else "Weak — NO_TRADE likely"
}
