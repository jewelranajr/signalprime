package com.signalprime.app.worker

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.signalprime.app.data.local.SettingsStore
import com.signalprime.app.data.model.Direction
import com.signalprime.app.data.model.Outcome
import com.signalprime.app.data.repository.CryptoRepositoryImpl
import com.signalprime.app.notifications.NotificationHelper
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

/**
 * Periodic background check for new trading signals. Reads the user's
 * notification preferences, fetches the latest signals, and posts a
 * notification for each unseen signal that passes the score / confidence /
 * direction / watchlist filters. Already-fetched signals are marked seen so
 * they are never notified twice.
 */
class SignalCheckWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val settings = SettingsStore(applicationContext)
        if (!settings.notificationsEnabled.first()) return Result.success()
        NotificationHelper.createChannels(applicationContext)
        val repo = CryptoRepositoryImpl(applicationContext, settings)
        val minScore = settings.minScore.first()
        val minConf = settings.minConfidence.first()
        val dirFilter = settings.directionFilter.first()
        val coins = settings.watchCoins.first()
        val seen = settings.seenSignalIds.first()
        return when (val res = repo.getSignals(20)) {
            is Outcome.Ok -> {
                res.value.filter { s ->
                    s.signalId !in seen &&
                        (s.confidence ?: 0.0) >= minConf &&
                        (s.longScore?.let { maxOf(it, s.shortScore ?: 0.0) } ?: 0.0) >= minScore &&
                        (dirFilter == "ALL" || s.direction.name == dirFilter) &&
                        (coins.isEmpty() || s.symbol in coins) &&
                        s.direction != Direction.NO_TRADE
                }.forEach { s ->
                    NotificationHelper.notifyNewSignal(applicationContext, s)
                    settings.markSignalSeen(s.signalId)
                }
                // Mark all fetched as seen to avoid repeats.
                res.value.forEach { settings.markSignalSeen(it.signalId) }
                Result.success()
            }
            is Outcome.Err -> if (runAttemptCount < 3) Result.retry() else Result.success()
        }
    }

    companion object {
        const val WORK_NAME = "signal_check"

        fun schedule(context: Context) {
            val req = PeriodicWorkRequestBuilder<SignalCheckWorker>(15, TimeUnit.MINUTES)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build(),
                )
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
