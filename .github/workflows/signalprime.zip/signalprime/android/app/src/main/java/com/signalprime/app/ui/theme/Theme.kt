package com.signalprime.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SignalPrimeColorScheme = darkColorScheme(
    background = Background,
    surface = Surface,
    surfaceVariant = SurfaceVariant,
    primary = Accent,
    onBackground = OnBackground,
    onSurface = OnBackground,
    error = ShortRed,
    tertiary = NoTradeAmber
)

@Composable
fun SignalPrimeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SignalPrimeColorScheme,
        typography = AppTypography,
        content = content
    )
}
