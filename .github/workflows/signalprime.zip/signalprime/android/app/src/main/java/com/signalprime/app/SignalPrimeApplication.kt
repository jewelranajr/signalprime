package com.signalprime.app

import android.app.Application
import com.signalprime.app.notifications.NotificationHelper

class SignalPrimeApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannels(this)
    }
}
