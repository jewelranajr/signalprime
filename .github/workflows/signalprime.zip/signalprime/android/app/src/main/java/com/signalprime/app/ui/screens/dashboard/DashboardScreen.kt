package com.signalprime.app.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.signalprime.app.data.model.Ticker
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.ui.components.EmptyState
import com.signalprime.app.ui.components.ErrorState
import com.signalprime.app.ui.components.LoadingState
import com.signalprime.app.ui.components.SectionCard
import com.signalprime.app.ui.components.SignalCard
import com.signalprime.app.ui.components.StatRow
import com.signalprime.app.ui.theme.Accent
import com.signalprime.app.ui.theme.Background
import com.signalprime.app.ui.theme.Bearish
import com.signalprime.app.ui.theme.Bullish
import com.signalprime.app.ui.theme.LongGreen
import com.signalprime.app.ui.theme.Muted
import com.signalprime.app.ui.theme.OnBackground
import com.signalprime.app.ui.theme.ShortRed
import com.signalprime.app.ui.theme.SurfaceVariant
import com.signalprime.app.ui.theme.Surface as ThemeSurface
import com.signalprime.app.ui.viewmodel.viewModelFactory
import com.signalprime.app.util.formatPct
import com.signalprime.app.util.formatPrice
import com.signalprime.app.util.regimeDisplayName

@Composable
fun DashboardScreen(
    repository: CryptoRepository,
    onSignalClick: (symbol: String) -> Unit,
    onCoinClick: (symbol: String) -> Unit,
    onViewAllSignals: () -> Unit,
) {
    val vm: DashboardViewModel = viewModel(factory = viewModelFactory { DashboardViewModel(repository) })
    val uiState by vm.uiState.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        Text(
            text = "Dashboard",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = OnBackground,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
        )
        PullToRefreshBox(
            isRefreshing = uiState is UiState.Loading,
            onRefresh = { vm.refresh() },
            modifier = Modifier.fillMaxSize(),
        ) {
            when (val state = uiState) {
                is UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(error = state.error, onRetry = { vm.refresh() })
                is UiState.Empty -> EmptyState("No market data available")
                is UiState.Success -> DashboardContent(
                    data = state.data,
                    onSignalClick = onSignalClick,
                    onCoinClick = onCoinClick,
                    onViewAllSignals = onViewAllSignals,
                )
            }
        }
    }
}

@Composable
private fun DashboardContent(
    data: DashboardUiData,
    onSignalClick: (symbol: String) -> Unit,
    onCoinClick: (symbol: String) -> Unit,
    onViewAllSignals: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                data.market.btc?.let { ticker ->
                    TickerCard(ticker = ticker, onCoinClick = onCoinClick, modifier = Modifier.weight(1f))
                }
                data.market.eth?.let { ticker ->
                    TickerCard(ticker = ticker, onCoinClick = onCoinClick, modifier = Modifier.weight(1f))
                }
            }
        }

        item {
            SectionCard(title = "Market Overview") {
                MarketSentiment(bullishPct = data.market.bullishPct, bearishPct = data.market.bearishPct)
                Spacer(Modifier.height(8.dp))
                StatRow(label = "Total scanned", value = data.market.totalScanned?.toString() ?: "—")
                Spacer(Modifier.height(4.dp))
                StatRow(label = "Active signals", value = data.market.activeSignals?.toString() ?: "—")
                Spacer(Modifier.height(4.dp))
                StatRow(label = "Regime", value = regimeDisplayName(data.market.marketRegime))
            }
        }

        data.market.bestSignal?.let { best ->
            item {
                SectionCard(title = "Highest Confidence") {
                    SignalCard(signal = best, onClick = { onSignalClick(best.symbol) })
                }
            }
        }

        data.market.bestRrSignal?.let { bestRr ->
            if (bestRr.symbol != data.market.bestSignal?.symbol) {
                item {
                    SectionCard(title = "Best Risk/Reward") {
                        SignalCard(signal = bestRr, onClick = { onSignalClick(bestRr.symbol) })
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "Top Signals",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = OnBackground,
                )
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onViewAllSignals) {
                    Text(text = "View all", color = Accent)
                }
            }
        }

        if (data.signals.isEmpty()) {
            item {
                Text(
                    text = "No signals right now",
                    fontSize = 14.sp,
                    color = Muted,
                    modifier = Modifier.padding(vertical = 8.dp),
                )
            }
        } else {
            items(data.signals, key = { it.signalId }) { signal ->
                SignalCard(signal = signal, onClick = { onSignalClick(signal.symbol) })
            }
        }
    }
}

@Composable
private fun TickerCard(ticker: Ticker, onCoinClick: (symbol: String) -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.clickable { onCoinClick(ticker.symbol) },
        shape = RoundedCornerShape(12.dp),
        color = ThemeSurface,
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = ticker.symbol,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = OnBackground,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = formatPrice(ticker.price),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = OnBackground,
            )
            Spacer(Modifier.height(2.dp))
            val change = ticker.priceChangePercent24h
            if (change != null) {
                Text(
                    text = "24h ${formatPct(change)}",
                    fontSize = 13.sp,
                    color = if (change >= 0) LongGreen else ShortRed,
                )
            } else {
                Text(
                    text = "24h —",
                    fontSize = 13.sp,
                    color = Muted,
                )
            }
        }
    }
}

@Composable
private fun MarketSentiment(bullishPct: Double?, bearishPct: Double?) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            text = bullishPct?.let { "Bullish ${it.toInt()}%" } ?: "Bullish —",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = Bullish,
        )
        Text(
            text = bearishPct?.let { "Bearish ${it.toInt()}%" } ?: "Bearish —",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = Bearish,
        )
    }
    Spacer(Modifier.height(6.dp))
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp)),
    ) {
        val bullish = (bullishPct ?: 0.0).toFloat()
        val bearish = (bearishPct ?: 0.0).toFloat()
        if (bullish + bearish > 0f) {
            Box(
                modifier = Modifier
                    .weight(bullish)
                    .fillMaxHeight()
                    .background(Bullish),
            )
            Box(
                modifier = Modifier
                    .weight(bearish)
                    .fillMaxHeight()
                    .background(Bearish),
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SurfaceVariant),
            )
        }
    }
}
