package com.signalprime.app.ui.screens.notifications

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signalprime.app.data.model.Outcome
import com.signalprime.app.data.model.UiState
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.worker.SignalCheckWorker
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class NotificationsViewModel(
    private val repo: CryptoRepository,
) : ViewModel() {

    private val settings = repo.settings

    val notificationsEnabled: Flow<Boolean> = settings.notificationsEnabled
    val minScore: Flow<Int> = settings.minScore
    val minConfidence: Flow<Int> = settings.minConfidence
    val directionFilter: Flow<String> = settings.directionFilter
    val watchCoins: Flow<Set<String>> = settings.watchCoins

    private val _symbolsState = MutableStateFlow<UiState<List<String>>>(UiState.Loading)
    val symbolsState: StateFlow<UiState<List<String>>> = _symbolsState.asStateFlow()

    init {
        refreshSymbols()
    }

    fun refreshSymbols() {
        viewModelScope.launch {
            _symbolsState.value = UiState.Loading
            _symbolsState.value = when (val res = repo.getSymbols()) {
                is Outcome.Ok -> UiState.Success(res.value)
                is Outcome.Err -> UiState.Error(res.error)
            }
        }
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        viewModelScope.launch {
            settings.setNotificationsEnabled(enabled)
            if (enabled) {
                SignalCheckWorker.schedule(context)
            } else {
                SignalCheckWorker.cancel(context)
            }
        }
    }

    fun setMinScore(v: Int) {
        viewModelScope.launch { settings.setMinScore(v.coerceIn(50, 100)) }
    }

    fun setMinConfidence(v: Int) {
        viewModelScope.launch { settings.setMinConfidence(v.coerceIn(50, 100)) }
    }

    fun setDirectionFilter(v: String) {
        viewModelScope.launch { settings.setDirectionFilter(v) }
    }

    fun toggleCoin(symbol: String) {
        viewModelScope.launch { settings.toggleWatchCoin(symbol) }
    }

    fun watchAllCoins() {
        viewModelScope.launch { settings.setWatchCoins(emptySet()) }
    }
}
