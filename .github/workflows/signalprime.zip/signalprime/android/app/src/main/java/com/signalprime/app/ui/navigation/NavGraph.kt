package com.signalprime.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.signalprime.app.data.repository.CryptoRepository
import com.signalprime.app.ui.screens.about.AboutScreen
import com.signalprime.app.ui.screens.backtest.BacktestScreen
import com.signalprime.app.ui.screens.coindetail.CoinDetailScreen
import com.signalprime.app.ui.screens.dashboard.DashboardScreen
import com.signalprime.app.ui.screens.history.HistoryScreen
import com.signalprime.app.ui.screens.more.MoreScreen
import com.signalprime.app.ui.screens.notifications.NotificationsScreen
import com.signalprime.app.ui.screens.riskcalc.RiskCalculatorScreen
import com.signalprime.app.ui.screens.scanner.ScannerScreen
import com.signalprime.app.ui.screens.settings.SettingsScreen
import com.signalprime.app.ui.screens.signaldetail.SignalDetailScreen
import com.signalprime.app.ui.screens.splash.SplashScreen

object Routes {
    const val SPLASH = "splash"
    const val DASHBOARD = "dashboard"
    const val SCANNER = "scanner"
    const val HISTORY = "history"
    const val MORE = "more"
    const val SIGNAL = "signal/{symbol}"
    const val COIN = "coin/{symbol}"
    const val RISK_CALC = "risk_calculator"
    const val BACKTEST = "backtest"
    const val SETTINGS = "settings"
    const val NOTIFICATIONS = "notifications"
    const val ABOUT = "about"

    fun signal(symbol: String): String = "signal/$symbol"
    fun coin(symbol: String): String = "coin/$symbol"
}

private data class BottomNavItem(
    val route: String,
    val label: String,
    val icon: ImageVector
)

private val bottomNavItems = listOf(
    BottomNavItem(Routes.DASHBOARD, "Dashboard", Icons.Filled.Home),
    BottomNavItem(Routes.SCANNER, "Scanner", Icons.Filled.Search),
    BottomNavItem(Routes.HISTORY, "History", Icons.Filled.History),
    BottomNavItem(Routes.MORE, "More", Icons.Filled.MoreHoriz)
)

private val bottomBarRoutes = setOf(
    Routes.DASHBOARD, Routes.SCANNER, Routes.HISTORY, Routes.MORE
)

@Composable
fun SignalPrimeApp(repository: CryptoRepository) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showBottomBar = currentRoute in bottomBarRoutes

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomNavItems.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.SPLASH,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.SPLASH) {
                SplashScreen(
                    onDone = {
                        navController.navigate(Routes.DASHBOARD) {
                            popUpTo(Routes.SPLASH) { inclusive = true }
                        }
                    }
                )
            }
            composable(Routes.DASHBOARD) {
                DashboardScreen(
                    repository = repository,
                    onSignalClick = { symbol -> navController.navigate(Routes.signal(symbol)) },
                    onCoinClick = { symbol -> navController.navigate(Routes.coin(symbol)) },
                    onViewAllSignals = { navController.navigate(Routes.SCANNER) }
                )
            }
            composable(Routes.SCANNER) {
                ScannerScreen(
                    repository = repository,
                    onCoinClick = { symbol -> navController.navigate(Routes.coin(symbol)) }
                )
            }
            composable(Routes.HISTORY) {
                HistoryScreen(
                    repository = repository,
                    onSignalClick = { symbol -> navController.navigate(Routes.signal(symbol)) }
                )
            }
            composable(Routes.MORE) {
                MoreScreen(
                    onNavigate = { route -> navController.navigate(route) }
                )
            }
            composable(
                route = Routes.SIGNAL,
                arguments = listOf(navArgument("symbol") { type = NavType.StringType })
            ) { backStackEntry ->
                val symbol = backStackEntry.arguments?.getString("symbol").orEmpty()
                SignalDetailScreen(
                    repository = repository,
                    symbol = symbol,
                    onBack = { navController.popBackStack() },
                    onCoinClick = { coinSymbol -> navController.navigate(Routes.coin(coinSymbol)) }
                )
            }
            composable(
                route = Routes.COIN,
                arguments = listOf(navArgument("symbol") { type = NavType.StringType })
            ) { backStackEntry ->
                val symbol = backStackEntry.arguments?.getString("symbol").orEmpty()
                CoinDetailScreen(
                    repository = repository,
                    symbol = symbol,
                    onBack = { navController.popBackStack() },
                    onSignalClick = { signalSymbol -> navController.navigate(Routes.signal(signalSymbol)) }
                )
            }
            composable(Routes.RISK_CALC) {
                RiskCalculatorScreen(
                    repository = repository,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Routes.BACKTEST) {
                BacktestScreen(
                    repository = repository,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    repository = repository,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Routes.NOTIFICATIONS) {
                NotificationsScreen(
                    repository = repository,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Routes.ABOUT) {
                AboutScreen(
                    repository = repository,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
