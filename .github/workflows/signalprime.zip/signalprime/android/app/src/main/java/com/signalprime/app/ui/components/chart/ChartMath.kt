package com.signalprime.app.ui.components.chart

import com.signalprime.app.data.model.Candle

// Pure-Kotlin chart math. No Android imports — safe for unit tests.
// All series are index-aligned with the input list; values that cannot be
// computed yet are null.

/**
 * Standard EMA. Seeded with the SMA of the first [period] closes;
 * entries before index period-1 are null. Returns nulls everywhere when
 * there are fewer than [period] closes.
 */
fun computeEma(closes: List<Double>, period: Int): List<Double?> {
    val result = MutableList<Double?>(closes.size) { null }
    if (closes.size < period || period <= 0) return result
    val k = 2.0 / (period + 1)
    var ema = closes.take(period).average()
    result[period - 1] = ema
    for (i in period until closes.size) {
        ema = closes[i] * k + ema * (1 - k)
        result[i] = ema
    }
    return result
}

/**
 * Session VWAP: cumulative (typical price * volume) / cumulative volume,
 * where typical price = (high + low + close) / 3.
 */
fun computeVwap(candles: List<Candle>): List<Double?> {
    val result = MutableList<Double?>(candles.size) { null }
    var cumPv = 0.0
    var cumV = 0.0
    candles.forEachIndexed { i, c ->
        val typical = (c.high + c.low + c.close) / 3.0
        cumPv += typical * c.volume
        cumV += c.volume
        result[i] = if (cumV > 0) cumPv / cumV else null
    }
    return result
}

/** Wilder's RSI evaluated at the last close. Null when data is insufficient. */
fun rsi(closes: List<Double>, period: Int = 14): Double? {
    if (period <= 0 || closes.size < period + 1) return null
    var gain = 0.0
    var loss = 0.0
    for (i in 1..period) {
        val change = closes[i] - closes[i - 1]
        if (change > 0) gain += change else loss -= change
    }
    var avgGain = gain / period
    var avgLoss = loss / period
    for (i in period + 1 until closes.size) {
        val change = closes[i] - closes[i - 1]
        val g = if (change > 0) change else 0.0
        val l = if (change < 0) -change else 0.0
        avgGain = (avgGain * (period - 1) + g) / period
        avgLoss = (avgLoss * (period - 1) + l) / period
    }
    if (avgLoss == 0.0) return 100.0
    val rs = avgGain / avgLoss
    return 100.0 - (100.0 / (1 + rs))
}

/**
 * Fractal swing highs/lows: a candle is a swing high (low) when its high
 * (low) is the extreme of the [lookback] candles on each side.
 *
 * Returns (supports, resistances) where supports are swing lows sorted
 * descending (nearest below price first, up to 3) and resistances are swing
 * highs sorted ascending (nearest above price first, up to 3).
 */
fun findSwingLevels(candles: List<Candle>, lookback: Int = 5): Pair<List<Double>, List<Double>> {
    if (lookback <= 0 || candles.size < lookback * 2 + 1) return emptyList<Double>() to emptyList<Double>()
    val swingHighs = mutableListOf<Double>()
    val swingLows = mutableListOf<Double>()
    for (i in lookback until candles.size - lookback) {
        val c = candles[i]
        val left = i - lookback until i
        val right = i + 1..i + lookback
        val isSwingHigh =
            left.all { candles[it].high <= c.high } && right.all { candles[it].high <= c.high }
        val isSwingLow =
            left.all { candles[it].low >= c.low } && right.all { candles[it].low >= c.low }
        if (isSwingHigh) swingHighs.add(c.high)
        if (isSwingLow) swingLows.add(c.low)
    }
    val supports = swingLows.distinct().sortedDescending().take(3)
    val resistances = swingHighs.distinct().sorted().take(3)
    return supports to resistances
}
