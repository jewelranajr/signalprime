package com.signalprime.app.util

import org.junit.Test
import kotlin.test.*

class RiskMathTest {

    private fun standardLong() =
        calculateRisk(
            balance = 10000.0,
            riskPercent = 1.0,
            entry = 67000.0,
            stopLoss = 66330.0
        )

    @Test
    fun calculateRisk_standardLong_computesRiskAmount() {
        val r = assertNotNull(standardLong())
        assertEquals(100.0, r.riskAmount, 1e-9)
    }

    @Test
    fun calculateRisk_standardLong_computesQuantity() {
        val r = assertNotNull(standardLong())
        // quantity = riskAmount / stopDistance = 100 / 670
        assertEquals(100.0 / 670.0, r.quantity, 1e-6)
    }

    @Test
    fun calculateRisk_standardLong_computesStopDistance() {
        val r = assertNotNull(standardLong())
        assertEquals(670.0, r.stopDistance, 1e-9)
        assertEquals(1.0, r.stopDistancePct, 1e-9)
    }

    @Test
    fun calculateRisk_positionValue_isQuantityTimesEntry() {
        val r = assertNotNull(standardLong())
        assertEquals(r.quantity * 67000.0, r.positionValue, 1e-6)
        assertEquals(10000.0, r.positionValue, 1e-6)
    }

    @Test
    fun calculateRisk_suggestedLeverage_consistentWithPositionAndBalance() {
        val r = assertNotNull(standardLong())
        assertEquals(r.positionValue / 10000.0, r.suggestedLeverage, 1e-9)
    }

    @Test
    fun calculateRisk_shortSide_usesAbsoluteDistance() {
        val r = assertNotNull(calculateRisk(10000.0, 1.0, 67000.0, 67670.0))
        assertEquals(100.0, r.riskAmount, 1e-9)
        assertEquals(670.0, r.stopDistance, 1e-9)
        assertEquals(100.0 / 670.0, r.quantity, 1e-6)
    }

    @Test
    fun calculateRisk_zeroBalance_returnsNull() {
        assertNull(calculateRisk(0.0, 1.0, 67000.0, 66330.0))
    }

    @Test
    fun calculateRisk_negativeBalance_returnsNull() {
        assertNull(calculateRisk(-500.0, 1.0, 67000.0, 66330.0))
    }

    @Test
    fun calculateRisk_entryEqualsStopLoss_returnsNull() {
        assertNull(calculateRisk(10000.0, 1.0, 67000.0, 67000.0))
    }

    @Test
    fun calculateRisk_zeroRiskPercent_returnsNull() {
        assertNull(calculateRisk(10000.0, 0.0, 67000.0, 66330.0))
    }

    @Test
    fun riskReward_long_returnsThree() {
        // reward = 69010 - 67000 = 2010, risk = 67000 - 66330 = 670 -> 3.0
        val rr = assertNotNull(riskReward(67000.0, 66330.0, 69010.0, true))
        assertEquals(3.0, rr, 0.01)
    }

    @Test
    fun riskReward_short_usesDirectionalDistances() {
        // reward = 67000 - 65000 = 2000, risk = 67670 - 67000 = 670
        val rr = assertNotNull(riskReward(67000.0, 67670.0, 65000.0, false))
        assertEquals(2000.0 / 670.0, rr, 0.01)
    }

    @Test
    fun riskReward_zeroRisk_returnsNull() {
        assertNull(riskReward(67000.0, 67000.0, 69010.0, true))
    }
}
