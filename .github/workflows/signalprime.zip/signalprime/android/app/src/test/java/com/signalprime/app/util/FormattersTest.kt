package com.signalprime.app.util

import org.junit.Test
import kotlin.test.*

class FormattersTest {

    private fun decimalsAfterDot(s: String): Int {
        val dot = s.indexOf('.')
        return if (dot < 0) 0 else s.length - dot - 1
    }

    @Test
    fun formatPrice_null_returnsPlaceholder() {
        assertEquals("—", formatPrice(null))
    }

    @Test
    fun formatPrice_largeValue_groupsThousands() {
        assertTrue(formatPrice(67432.5).contains("67,432"))
    }

    @Test
    fun formatPrice_smallValue_usesMoreDecimalsThanLargeValue() {
        val tiny = formatPrice(0.0001234)
        val big = formatPrice(67432.5)
        assertTrue(
            decimalsAfterDot(tiny) > decimalsAfterDot(big),
            "expected more decimals for '$tiny' than '$big'"
        )
    }

    @Test
    fun formatPct_positive_includesPlusSign() {
        assertEquals("+2.35%", formatPct(2.345))
    }

    @Test
    fun formatPct_negative_includesMinusSign() {
        assertEquals("-2.35%", formatPct(-2.345))
    }

    @Test
    fun formatPct_null_returnsPlaceholder() {
        assertEquals("—", formatPct(null))
    }

    @Test
    fun formatCompact_millions_usesMSuffix() {
        assertEquals("1.20M", formatCompact(1_200_000.0))
    }

    @Test
    fun formatCompact_thousands_endsWithK() {
        val result = formatCompact(34_500.0)
        assertTrue(result.endsWith("K"), "expected K suffix, got '$result'")
        assertTrue(result.contains("34.5"), "expected 34.5 magnitude, got '$result'")
    }

    @Test
    fun formatCompact_null_returnsPlaceholder() {
        assertEquals("—", formatCompact(null))
    }

    @Test
    fun formatUsd_formatsWithDollarSignAndCents() {
        assertEquals("$1,234.50", formatUsd(1234.5))
    }

    @Test
    fun formatUsd_null_returnsPlaceholder() {
        assertEquals("—", formatUsd(null))
    }

    @Test
    fun formatDateTime_isoInput_startsWithDate() {
        val result = formatDateTime("2026-10-08T10:59:23Z")
        assertTrue(result.startsWith("2026-10-08"), "got '$result'")
    }

    @Test
    fun formatDateTime_null_returnsPlaceholder() {
        assertEquals("—", formatDateTime(null))
    }

    @Test
    fun formatTimeAgo_recentTimestamp_saysJustNow() {
        val recent = java.time.Instant.now().minusSeconds(5).toString()
        val result = formatTimeAgo(recent)
        assertTrue(
            result.lowercase().contains("just now"),
            "expected 'just now', got '$result'"
        )
    }

    @Test
    fun formatTimeAgo_null_returnsPlaceholder() {
        assertEquals("—", formatTimeAgo(null))
    }
}
