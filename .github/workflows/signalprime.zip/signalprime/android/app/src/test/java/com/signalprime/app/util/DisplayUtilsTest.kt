package com.signalprime.app.util

import com.signalprime.app.data.model.AppError
import com.signalprime.app.data.model.Direction
import com.signalprime.app.data.model.message
import com.signalprime.app.data.model.title
import org.junit.Test
import kotlin.test.*

class DisplayUtilsTest {

    @Test
    fun displayName_long() {
        assertEquals("LONG", Direction.LONG.displayName())
    }

    @Test
    fun displayName_short() {
        assertEquals("SHORT", Direction.SHORT.displayName())
    }

    @Test
    fun displayName_noTrade() {
        assertEquals("NO TRADE", Direction.NO_TRADE.displayName())
    }

    @Test
    fun regimeDisplayName_strongBull() {
        assertEquals("Strong Bullish", regimeDisplayName("STRONG_BULL"))
    }

    @Test
    fun regimeDisplayName_null_returnsPlaceholder() {
        assertEquals("—", regimeDisplayName(null))
    }

    @Test
    fun gapVerdict_largeGap_strongDirectionalConfirmation() {
        assertEquals("Strong directional confirmation", gapVerdict(44.0, 10))
    }

    @Test
    fun gapVerdict_smallGap_mentionsNoTrade() {
        val verdict = gapVerdict(3.0, 10)
        assertTrue(verdict.contains("NO_TRADE"), "got '$verdict'")
    }

    @Test
    fun appError_offline_title() {
        assertEquals("OFFLINE", AppError.Offline.title())
    }

    @Test
    fun appError_serverUnreachable_title() {
        assertEquals("SERVER CONNECTION ERROR", AppError.ServerUnreachable.title())
    }

    @Test
    fun appError_marketDataUnavailable_title() {
        assertEquals("MARKET DATA UNAVAILABLE", AppError.MarketDataUnavailable.title())
    }

    @Test
    fun appError_messages_areNonBlank() {
        listOf(AppError.Offline, AppError.ServerUnreachable, AppError.MarketDataUnavailable)
            .forEach { assertTrue(it.message().isNotBlank(), "blank message for $it") }
    }
}
