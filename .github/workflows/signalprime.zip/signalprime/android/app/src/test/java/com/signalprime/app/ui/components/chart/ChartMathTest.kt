package com.signalprime.app.ui.components.chart

import com.signalprime.app.data.model.Candle
import org.junit.Test
import kotlin.math.abs
import kotlin.test.*

class ChartMathTest {

    private fun candle(
        open: Double,
        high: Double,
        low: Double,
        close: Double,
        volume: Double = 1000.0,
        timestamp: Long = 0L
    ) = Candle(openTime = timestamp, open = open, high = high, low = low, close = close, volume = volume, closeTime = timestamp)

    // ---- EMA ----

    @Test
    fun computeEma_outputSizeMatchesInput() {
        val closes = List(30) { 100.0 }
        assertEquals(closes.size, computeEma(closes, 10).size)
    }

    @Test
    fun computeEma_firstPeriodMinusOneEntriesAreNull() {
        val closes = List(30) { it.toDouble() + 1.0 }
        val ema = computeEma(closes, 10)
        ema.take(9).forEachIndexed { i, v -> assertNull(v, "index $i should be null") }
    }

    @Test
    fun computeEma_constantSeries_convergesToConstant() {
        val closes = List(30) { 123.456 }
        val ema = computeEma(closes, 10)
        val last = assertNotNull(ema.last())
        assertTrue(abs(last - 123.456) < 1e-6, "EMA did not converge to constant, got $last")
    }

    @Test
    fun computeEma_risingSeries_lagsPrice() {
        val closes = (1..50).map { it.toDouble() }
        val ema = computeEma(closes, 10)
        val last = assertNotNull(ema.last())
        assertTrue(last < 50.0, "EMA should lag a rising price, got $last")
        assertTrue(last > 40.0, "EMA unexpectedly far below price, got $last")
    }

    // ---- RSI ----

    @Test
    fun rsi_allGains_near100() {
        val closes = (1..30).map { it.toDouble() }
        val r = assertNotNull(rsi(closes))
        assertTrue(r >= 99.999, "expected RSI≈100, got $r")
    }

    @Test
    fun rsi_allLosses_near0() {
        val closes = (30 downTo 1).map { it.toDouble() }
        val r = assertNotNull(rsi(closes))
        assertTrue(r <= 0.001, "expected RSI≈0, got $r")
    }

    @Test
    fun rsi_flatSeries_neutralOrNull() {
        val closes = List(30) { 100.0 }
        val r = rsi(closes)
        assertTrue(r == null || abs(r - 50.0) < 1e-6, "expected 50.0 or null, got $r")
    }

    @Test
    fun rsi_insufficientData_returnsNull() {
        assertNull(rsi(listOf(1.0, 2.0, 3.0)))
    }

    // ---- VWAP ----

    @Test
    fun computeVwap_singleCandle_equalsTypicalPrice() {
        val c = candle(open = 95.0, high = 100.0, low = 90.0, close = 96.0, volume = 1000.0)
        val vwap = computeVwap(listOf(c))
        assertEquals(1, vwap.size)
        val v = assertNotNull(vwap[0])
        assertEquals((100.0 + 90.0 + 96.0) / 3.0, v, 1e-9)
    }

    @Test
    fun computeVwap_twoCandles_isCumulative() {
        val c1 = candle(open = 95.0, high = 100.0, low = 90.0, close = 96.0, volume = 10.0)
        val c2 = candle(open = 108.0, high = 115.0, low = 105.0, close = 112.0, volume = 10.0)
        val vwap = computeVwap(listOf(c1, c2))
        assertEquals(2, vwap.size)
        val v1 = assertNotNull(vwap[1])
        // typical1 = 286/3, typical2 = 332/3; equal volumes -> mean = 103.0
        assertEquals(103.0, v1, 1e-6)
    }

    @Test
    fun computeVwap_outputSizeMatchesInput() {
        val candles = List(20) { i ->
            candle(open = 100.0 + i, high = 102.0 + i, low = 98.0 + i, close = 101.0 + i)
        }
        assertEquals(candles.size, computeVwap(candles).size)
    }

    // ---- Swing levels ----

    @Test
    fun findSwingLevels_detectsPeakAndValley() {
        val candles = listOf(
            candle(97.0, 98.0, 92.0, 96.0),
            candle(96.0, 100.0, 91.0, 99.0),
            candle(99.0, 110.0, 90.0, 105.0), // swing high: 110
            candle(105.0, 104.0, 89.0, 100.0),
            candle(100.0, 103.0, 88.0, 99.0),
            candle(99.0, 102.0, 84.0, 95.0), // swing low: 84
            candle(95.0, 101.0, 87.0, 98.0),
            candle(98.0, 100.0, 88.0, 99.0),
            candle(99.0, 99.0, 89.0, 97.0)
        )
        val (supports, resistances) = findSwingLevels(candles, lookback = 2)
        assertTrue(
            resistances.any { abs(it - 110.0) < 1e-9 },
            "expected 110.0 among resistances, got $resistances"
        )
        assertTrue(
            supports.any { abs(it - 84.0) < 1e-9 },
            "expected 84.0 among supports, got $supports"
        )
    }
}
