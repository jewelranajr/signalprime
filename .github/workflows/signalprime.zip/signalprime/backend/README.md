# SignalPrime — Backend

Master Signal Engine: a multi-layer crypto market-intelligence and risk-management
system. Node.js + TypeScript + Fastify, SQLite persistence (via Node's built-in
`node:sqlite` — no native dependencies).

It analyzes markets and emits only high-quality `LONG` / `SHORT` / `NO_TRADE`
signals. When in doubt it outputs `NO_TRADE` with explicit reasons — quality over
quantity, always.

## Quick start

```bash
cp .env.example .env   # adjust thresholds if needed
npm install
npm run build
npm start              # http://localhost:3000
```

Run tests: `npm test` (builds, then runs `node --test` over `dist/test`).

## Architecture

```
src/
  index.ts        bootstrap: config → exchange → scanner → store → monitor → server
  server.ts       Fastify REST API, validation (zod), CORS, rate limiting, API-key auth
  config.ts       env-driven settings (all thresholds configurable)
  types.ts        public API contract (shared with the Android app)
  exchange.ts     Binance public REST client (multi-host fallback, caching, validation)
  indicators.ts   EMA/SMA/RSI/MACD/ATR/ADX/VWAP/Bollinger/StochRSI/CCI/OBV/ROC/…
  structure.ts    swings, HH/HL/LH/LL, BOS/CHoCH, liquidity sweeps, S/R zones
  regime.ts       12-regime classifier (STRONG_BULL … DISTRIBUTION, HIGH_VOLATILITY…)
  mtf.ts          multi-timeframe bias + alignment scoring (5m→1d)
  analysis.ts     per-symbol indicator snapshot (computed once, shared)
  scoring.ts      transparent 100-pt LONG/SHORT scoring (8 categories)
  contradiction.ts mandatory conflict detection (blocks trades when severe)
  risk.ts         entry zones, structural SL, TP1–3 (2.0/2.8/3.6R), position sizing
  signals.ts      master orchestrator → LONG / SHORT / NO_TRADE
  scanner.ts      1–500 symbol scanner + ranking formula
  monitor.ts      live signal lifecycle (WAITING→ACTIVE→TP/SL/EXPIRED)
  database.ts     SQLite: signals, events, backtests, kv
  backtest.ts     walk-forward backtester (no look-ahead bias)
```

## Signal pipeline

```
validate data → indicators → structure → S/R → regime → MTF
  → score LONG & SHORT → contradiction check → threshold gates
  → entry/SL/TP/position → confidence → LONG | SHORT | NO_TRADE
```

Scoring (100 pts): Trend 20 · MTF 20 · Momentum 15 · Volume 10 ·
Structure 10 · S/R 10 · Volatility 5 · Risk/Reward 10.

Default gates (env-configurable): `MIN_SCORE=85`, `MIN_DIRECTION_GAP=10`,
`MIN_RR=2`, `MIN_CONFIDENCE=75`, `MIN_DATA_CANDLES=220`.

## API

| Method | Path | Description |
|---|---|---|
| GET | `/health` | status, version, uptime |
| GET | `/config` | public thresholds |
| GET | `/symbols` | tradeable USDT spot symbols |
| GET | `/ticker/:symbol` | 24h ticker |
| GET | `/candles/:symbol?interval=1h&limit=300` | OHLCV |
| GET | `/signal/:symbol?timeframe=1h&balance=10000&risk_percent=1` | master signal |
| GET | `/signals?limit=20` | top ranked signals |
| GET | `/signals/:id` | stored signal |
| GET | `/scanner?limit=50` | ranked scan |
| GET | `/market` | dashboard overview |
| GET | `/regime/:symbol` | regime report |
| GET | `/history?direction=&result=&limit=50` | signal history |
| POST | `/backtest` | `{symbol,timeframe,start,end,initial_balance,risk_percent}` |

Errors use `{ "error": { "code", "message" } }` with codes
`MARKET_DATA_UNAVAILABLE`, `STALE_DATA`, `SYMBOL_NOT_FOUND`,
`INSUFFICIENT_DATA`, `INVALID_REQUEST`, `RATE_LIMITED`, `SERVER_ERROR`.

Set `API_KEY` to require `x-api-key` on all routes except `/health`.

## Notes & limitations

- Public Binance endpoints only — no API keys, nothing secret in the repo.
- Backtests are historical simulations, not profit guarantees.
- `probability_estimate` / `confidence` are model estimates, not calibrated probabilities.
- The live monitor polls ticker snapshots; intrabar wick extremes between polls can be missed.
- Whale/sentiment layers are provider interfaces — no data is fabricated when unavailable.
