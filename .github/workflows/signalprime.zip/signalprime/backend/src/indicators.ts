/**
 * Technical indicator library — pure functions, no I/O.
 *
 * All series functions return arrays aligned with the input length.
 * Positions that cannot be computed yet are NaN (check with Number.isFinite).
 * Wilder's smoothing is used for RSI/ATR/ADX per standard definitions.
 */
import type { Candle } from './types.js';

export const NAN = NaN;

export function closes(candles: Candle[]): number[] {
  return candles.map((c) => c.close);
}
export function highs(candles: Candle[]): number[] {
  return candles.map((c) => c.high);
}
export function lows(candles: Candle[]): number[] {
  return candles.map((c) => c.low);
}
export function volumes(candles: Candle[]): number[] {
  return candles.map((c) => c.volume);
}
export function typicalPrices(candles: Candle[]): number[] {
  return candles.map((c) => (c.high + c.low + c.close) / 3);
}

/** Last finite value of a series, or NaN. */
export function lastFinite(s: number[]): number {
  for (let i = s.length - 1; i >= 0; i--) {
    if (Number.isFinite(s[i])) return s[i];
  }
  return NaN;
}

export function sma(values: number[], period: number): number[] {
  const out = new Array<number>(values.length).fill(NAN);
  if (period <= 0 || values.length < period) return out;
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= period) sum -= values[i - period];
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

export function ema(values: number[], period: number): number[] {
  const out = new Array<number>(values.length).fill(NAN);
  if (period <= 0 || values.length < period) return out;
  const k = 2 / (period + 1);
  let sum = 0;
  for (let i = 0; i < period; i++) sum += values[i];
  let prev = sum / period;
  out[period - 1] = prev;
  for (let i = period; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

/** Wilder RSI. */
export function rsi(closesArr: number[], period = 14): number[] {
  const out = new Array<number>(closesArr.length).fill(NAN);
  if (closesArr.length < period + 1) return out;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closesArr[i] - closesArr[i - 1];
    if (d > 0) gain += d; else loss -= d;
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;
  out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  for (let i = period + 1; i < closesArr.length; i++) {
    const d = closesArr[i] - closesArr[i - 1];
    avgGain = (avgGain * (period - 1) + Math.max(d, 0)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(-d, 0)) / period;
    out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return out;
}

export interface MacdResult {
  macdLine: number[];
  signalLine: number[];
  histogram: number[];
}

export function macd(closesArr: number[], fast = 12, slow = 26, signal = 9): MacdResult {
  const n = closesArr.length;
  const macdLine = new Array<number>(n).fill(NAN);
  const signalLine = new Array<number>(n).fill(NAN);
  const histogram = new Array<number>(n).fill(NAN);
  const fastEma = ema(closesArr, fast);
  const slowEma = ema(closesArr, slow);
  const start = slow - 1;
  for (let i = start; i < n; i++) {
    if (Number.isFinite(fastEma[i]) && Number.isFinite(slowEma[i])) {
      macdLine[i] = fastEma[i] - slowEma[i];
    }
  }
  // Signal line: EMA of the macd line over its valid region.
  const validIdx: number[] = [];
  const validVals: number[] = [];
  for (let i = 0; i < n; i++) {
    if (Number.isFinite(macdLine[i])) {
      validIdx.push(i);
      validVals.push(macdLine[i]);
    }
  }
  if (validVals.length >= signal) {
    const sig = ema(validVals, signal);
    for (let j = 0; j < validVals.length; j++) {
      const i = validIdx[j];
      if (Number.isFinite(sig[j])) {
        signalLine[i] = sig[j];
        histogram[i] = macdLine[i] - sig[j];
      }
    }
  }
  return { macdLine, signalLine, histogram };
}

export function trueRange(candles: Candle[]): number[] {
  const out = new Array<number>(candles.length).fill(NAN);
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    if (i === 0) {
      out[i] = c.high - c.low;
    } else {
      const pc = candles[i - 1].close;
      out[i] = Math.max(c.high - c.low, Math.abs(c.high - pc), Math.abs(c.low - pc));
    }
  }
  return out;
}

/** Wilder ATR. */
export function atr(candles: Candle[], period = 14): number[] {
  const tr = trueRange(candles);
  return wilder(tr, period);
}

/** Generic Wilder smoothing (first value = SMA). */
export function wilder(values: number[], period: number): number[] {
  const out = new Array<number>(values.length).fill(NAN);
  if (values.length < period) return out;
  let sum = 0;
  for (let i = 0; i < period; i++) sum += values[i];
  let prev = sum / period;
  out[period - 1] = prev;
  for (let i = period; i < values.length; i++) {
    prev = (prev * (period - 1) + values[i]) / period;
    out[i] = prev;
  }
  return out;
}

export interface AdxResult {
  adx: number[];
  plusDI: number[];
  minusDI: number[];
}

export function adx(candles: Candle[], period = 14): AdxResult {
  const n = candles.length;
  const adxArr = new Array<number>(n).fill(NAN);
  const plusDI = new Array<number>(n).fill(NAN);
  const minusDI = new Array<number>(n).fill(NAN);
  if (n < period * 2 + 1) return { adx: adxArr, plusDI, minusDI };
  const tr = trueRange(candles);
  const plusDM = new Array<number>(n).fill(0);
  const minusDM = new Array<number>(n).fill(0);
  for (let i = 1; i < n; i++) {
    const up = candles[i].high - candles[i - 1].high;
    const down = candles[i - 1].low - candles[i].low;
    plusDM[i] = up > down && up > 0 ? up : 0;
    minusDM[i] = down > up && down > 0 ? down : 0;
  }
  const sTR = wilder(tr, period);
  const sPlus = wilder(plusDM, period);
  const sMinus = wilder(minusDM, period);
  const dx = new Array<number>(n).fill(NAN);
  for (let i = 0; i < n; i++) {
    if (Number.isFinite(sTR[i]) && sTR[i] > 0) {
      plusDI[i] = (100 * sPlus[i]) / sTR[i];
      minusDI[i] = (100 * sMinus[i]) / sTR[i];
      const sum = plusDI[i] + minusDI[i];
      dx[i] = sum > 0 ? (100 * Math.abs(plusDI[i] - minusDI[i])) / sum : 0;
    }
  }
  // ADX = Wilder smoothing of DX, starting at 2*period-1
  const dxStart = 2 * period - 1;
  const dxVals: number[] = [];
  const dxIdx: number[] = [];
  for (let i = period - 1; i < n; i++) {
    if (Number.isFinite(dx[i])) {
      dxIdx.push(i);
      dxVals.push(dx[i]);
    }
  }
  if (dxVals.length >= period) {
    let sum = 0;
    for (let j = 0; j < period; j++) sum += dxVals[j];
    let prev = sum / period;
    adxArr[dxIdx[period - 1]] = prev;
    for (let j = period; j < dxVals.length; j++) {
      prev = (prev * (period - 1) + dxVals[j]) / period;
      adxArr[dxIdx[j]] = prev;
    }
  }
  void dxStart;
  return { adx: adxArr, plusDI, minusDI };
}

/** Session-anchored VWAP over the provided series (crypto trades 24/7). */
export function vwap(candles: Candle[]): number[] {
  const out = new Array<number>(candles.length).fill(NAN);
  let cumPV = 0, cumV = 0;
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    const tp = (c.high + c.low + c.close) / 3;
    cumPV += tp * c.volume;
    cumV += c.volume;
    out[i] = cumV > 0 ? cumPV / cumV : NAN;
  }
  return out;
}

export interface BollingerResult {
  upper: number[];
  middle: number[];
  lower: number[];
  /** (upper-lower)/middle — relative width */
  bandwidth: number[];
  /** %B position of close within the bands */
  percentB: number[];
}

export function bollinger(closesArr: number[], period = 20, mult = 2): BollingerResult {
  const n = closesArr.length;
  const upper = new Array<number>(n).fill(NAN);
  const middle = new Array<number>(n).fill(NAN);
  const lower = new Array<number>(n).fill(NAN);
  const bandwidth = new Array<number>(n).fill(NAN);
  const percentB = new Array<number>(n).fill(NAN);
  const mid = sma(closesArr, period);
  for (let i = period - 1; i < n; i++) {
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) sum += closesArr[j];
    const mean = sum / period;
    let sq = 0;
    for (let j = i - period + 1; j <= i; j++) sq += (closesArr[j] - mean) ** 2;
    const sd = Math.sqrt(sq / period);
    middle[i] = mid[i];
    upper[i] = mean + mult * sd;
    lower[i] = mean - mult * sd;
    bandwidth[i] = mean !== 0 ? (upper[i] - lower[i]) / mean : NAN;
    const range = upper[i] - lower[i];
    percentB[i] = range > 0 ? (closesArr[i] - lower[i]) / range : 0.5;
  }
  return { upper, middle, lower, bandwidth, percentB };
}

export interface StochRsiResult {
  k: number[];
  d: number[];
}

/** Stochastic RSI: %K = SMA3 of Stoch(RSI(14), 14), %D = SMA3 of %K. */
export function stochRsi(
  closesArr: number[],
  rsiPeriod = 14,
  stochPeriod = 14,
  kPeriod = 3,
  dPeriod = 3,
): StochRsiResult {
  const n = closesArr.length;
  const k = new Array<number>(n).fill(NAN);
  const d = new Array<number>(n).fill(NAN);
  const rsiArr = rsi(closesArr, rsiPeriod);
  const stoch = new Array<number>(n).fill(NAN);
  const first = rsiPeriod + stochPeriod - 1;
  for (let i = first; i < n; i++) {
    let lo = Infinity, hi = -Infinity;
    for (let j = i - stochPeriod + 1; j <= i; j++) {
      const v = rsiArr[j];
      if (!Number.isFinite(v)) { lo = Infinity; break; }
      if (v < lo) lo = v;
      if (v > hi) hi = v;
    }
    if (lo === Infinity) continue;
    const range = hi - lo;
    stoch[i] = range > 1e-12 ? ((rsiArr[i] - lo) / range) * 100 : 50;
  }
  // %K and %D computed over the valid stoch region, mapped back to indices.
  const idx: number[] = [];
  const vals: number[] = [];
  for (let i = 0; i < n; i++) {
    if (Number.isFinite(stoch[i])) { idx.push(i); vals.push(stoch[i]); }
  }
  if (vals.length >= kPeriod) {
    const kS = sma(vals, kPeriod);
    for (let j = 0; j < vals.length; j++) {
      if (Number.isFinite(kS[j])) k[idx[j]] = clamp01(kS[j]);
    }
    const kIdx: number[] = [];
    const kVals: number[] = [];
    for (let j = 0; j < vals.length; j++) {
      if (Number.isFinite(kS[j])) { kIdx.push(idx[j]); kVals.push(kS[j]); }
    }
    if (kVals.length >= dPeriod) {
      const dS = sma(kVals, dPeriod);
      for (let j = 0; j < kVals.length; j++) {
        if (Number.isFinite(dS[j])) d[kIdx[j]] = clamp01(dS[j]);
      }
    }
  }
  return { k, d };
}

function clamp01(v: number): number {
  return Math.min(100, Math.max(0, v));
}

/** Commodity Channel Index. */
export function cci(candles: Candle[], period = 20): number[] {
  const n = candles.length;
  const out = new Array<number>(n).fill(NAN);
  const tp = typicalPrices(candles);
  const tpSma = sma(tp, period);
  for (let i = period - 1; i < n; i++) {
    let md = 0;
    for (let j = i - period + 1; j <= i; j++) md += Math.abs(tp[j] - tpSma[i]);
    md /= period;
    out[i] = md > 1e-12 ? (tp[i] - tpSma[i]) / (0.015 * md) : 0;
  }
  return out;
}

/** On-Balance Volume. */
export function obv(candles: Candle[]): number[] {
  const out = new Array<number>(candles.length).fill(NAN);
  let cum = 0;
  for (let i = 0; i < candles.length; i++) {
    if (i === 0) {
      out[i] = 0;
      continue;
    }
    const c = candles[i];
    const pc = candles[i - 1].close;
    if (c.close > pc) cum += c.volume;
    else if (c.close < pc) cum -= c.volume;
    out[i] = cum;
  }
  return out;
}

/** Rate of Change in percent. */
export function roc(closesArr: number[], period = 12): number[] {
  const out = new Array<number>(closesArr.length).fill(NAN);
  for (let i = period; i < closesArr.length; i++) {
    const prev = closesArr[i - period];
    out[i] = prev !== 0 ? ((closesArr[i] - prev) / prev) * 100 : NAN;
  }
  return out;
}

/** Momentum: close - close[n]. */
export function momentum(closesArr: number[], period = 10): number[] {
  const out = new Array<number>(closesArr.length).fill(NAN);
  for (let i = period; i < closesArr.length; i++) out[i] = closesArr[i] - closesArr[i - period];
  return out;
}

/**
 * Approximate volume delta for spot klines (no real bid/ask data):
 * distributes candle volume by body position within the range.
 * Explicitly an approximation — engine treats it as weak evidence only.
 */
export function volumeDeltaApprox(candles: Candle[]): number[] {
  const out = new Array<number>(candles.length).fill(NAN);
  let cum = 0;
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    const range = c.high - c.low;
    const pos = range > 1e-12 ? (c.close - c.open) / range : 0; // -1..1
    cum += c.volume * pos;
    out[i] = cum;
  }
  return out;
}

/** Rolling percentile rank (0-100) of the last value within a lookback window. */
export function percentileRank(values: number[], lookback = 100): number {
  const finite = values.filter(Number.isFinite);
  if (finite.length === 0) return 50;
  const window = finite.slice(-lookback);
  const last = window[window.length - 1];
  const below = window.filter((v) => v <= last).length;
  return (below / window.length) * 100;
}

/** ATR as a percent of price. */
export function atrPercent(atrArr: number[], closesArr: number[]): number[] {
  return atrArr.map((a, i) =>
    Number.isFinite(a) && closesArr[i] > 0 ? (a / closesArr[i]) * 100 : NAN,
  );
}
