/**
 * Contradiction engine — mandatory conflict detection.
 *
 * Scores conflicts between the proposed direction and market evidence.
 * A severe contradiction or accumulated penalty >= 40 blocks the trade
 * and forces NO_TRADE with explicit reasons.
 */
import type { IndicatorSnapshot } from './analysis.js';
import type { MtfReport } from './mtf.js';
import type { SRZone, StructureReport } from './structure.js';

export interface Contradiction {
  id: string;
  description: string;
  penalty: number;
  severe: boolean;
}

export interface ContradictionReport {
  contradictions: Contradiction[];
  totalPenalty: number;
  severe: boolean;
  blocksTrade: boolean;
}

export interface ContradictionContext {
  snap: IndicatorSnapshot;
  mtf: MtfReport;
  structure: StructureReport;
  zones: SRZone[];
}

const SEVERE_PENALTY_TOTAL = 40;

function nearest(zones: SRZone[], type: 'SUPPORT' | 'RESISTANCE'): SRZone | null {
  let best: SRZone | null = null;
  for (const z of zones) {
    if (z.type !== type) continue;
    if (!best || Math.abs(z.distance_pct) < Math.abs(best.distance_pct)) best = z;
  }
  return best;
}

export function detectContradictions(
  ctx: ContradictionContext,
  direction: 'LONG' | 'SHORT',
): ContradictionReport {
  const out: Contradiction[] = [];
  const { snap, mtf, structure, zones } = ctx;
  const price = snap.price;
  const atrV = snap.atr;
  const atrOk = Number.isFinite(atrV) && atrV > 0;
  const add = (id: string, description: string, penalty: number, severe = false) =>
    out.push({ id, description, penalty, severe });

  const ts = structure.trendScore;
  const long = direction === 'LONG';

  // 1. Trend vs momentum conflict.
  if (long && ts > 30 && snap.macdHist < 0) {
    add('trend_momentum_conflict', 'Bullish structure but bearish MACD momentum', 12);
  }
  if (!long && ts < -30 && snap.macdHist > 0) {
    add('trend_momentum_conflict', 'Bearish structure but bullish MACD momentum', 12);
  }

  // 2. Breakout without volume.
  if (structure.bos && structure.bosDirection === (long ? 'UP' : 'DOWN') && snap.volumeRatio < 0.8) {
    add('breakout_weak_volume', 'Break of structure lacks volume confirmation', 15);
  }

  // 3. Major S/R directly in the way.
  if (long) {
    const res = nearest(zones, 'RESISTANCE');
    if (res && atrOk) {
      const dAtr = ((res.price - price) / price) / (atrV / price);
      if (dAtr < 0.25 && res.strength >= 70) {
        add('resistance_ahead', `Major resistance ${res.strength}/100 strength only ${dAtr.toFixed(2)} ATR above entry`, 20, true);
      } else if (dAtr < 0.5) {
        add('resistance_ahead', `Resistance ${pct(res.distance_pct)}% above entry — limited room`, 15);
      }
    }
  } else {
    const sup = nearest(zones, 'SUPPORT');
    if (sup && atrOk) {
      const dAtr = ((price - sup.price) / price) / (atrV / price);
      if (dAtr < 0.25 && sup.strength >= 70) {
        add('support_below', `Major support ${sup.strength}/100 strength only ${dAtr.toFixed(2)} ATR below entry`, 20, true);
      } else if (dAtr < 0.5) {
        add('support_below', `Support ${pct(sup.distance_pct)}% below entry — limited room`, 15);
      }
    }
  }

  // 4. Overextended RSI against fresh entries.
  if (long && snap.rsi14 > 75) add('rsi_extended', `RSI ${snap.rsi14.toFixed(1)} overbought — chasing longs is risky`, 10);
  if (!long && snap.rsi14 < 25) add('rsi_extended', `RSI ${snap.rsi14.toFixed(1)} oversold — chasing shorts is risky`, 10);

  // 5. Extreme volatility.
  if (snap.bbWidthRank > 92) {
    add('extreme_volatility', 'Extreme volatility — entries unsafe without exceptional confirmation', 12);
  }

  // 6. MTF conflict.
  const opp = long ? 'BEARISH' : 'BULLISH';
  if (mtf.dominant === opp) {
    add('mtf_conflict', `Higher timeframes are ${opp.toLowerCase()} — counter-trend trade`, 14);
  }
  if (mtf.notes.some((n) => n.includes('HTF/LTF disagreement'))) {
    add('htf_ltf_disagreement', 'Higher/lower timeframe disagreement', 10);
  }

  // 7. CHoCH against the direction.
  if (structure.choch && structure.chochDirection === (long ? 'DOWN' : 'UP')) {
    add('choch_against', `Change of character ${structure.chochDirection === 'UP' ? 'bullish' : 'bearish'} against ${direction}`, 14);
  }

  // 8. Liquidity sweep implications (sweep of highs + rejection = bearish).
  if (long && structure.liquiditySweepUp) {
    add('sweep_against', 'Liquidity sweep above highs with rejection — bearish implication', 10);
  }
  if (!long && structure.liquiditySweepDown) {
    add('sweep_against', 'Liquidity sweep below lows with rejection — bullish implication', 10);
  }

  // 9. False breakout in the direction of the trade.
  if (long && structure.falseBreakoutUp) add('false_breakout', 'Recent false breakout above resistance', 12);
  if (!long && structure.falseBreakoutDown) add('false_breakdown', 'Recent false breakdown below support', 12);

  // 10. Chasing extended price.
  if (atrOk) {
    const ref = Number.isFinite(snap.ema20) ? snap.ema20 : snap.vwap;
    if (Number.isFinite(ref)) {
      const ext = long ? (price - ref) / atrV : (ref - price) / atrV;
      if (ext > 2) add('chasing', `Price extended ${ext.toFixed(1)} ATR from value — wait for pullback`, 10);
    }
  }

  // 11. Move without volume confirmation.
  if (snap.volumeRatio < 0.5) {
    add('weak_volume', 'Volume 50% below average — move lacks confirmation', 8);
  }

  const totalPenalty = out.reduce((s, c) => s + c.penalty, 0);
  const severe = out.some((c) => c.severe);
  return {
    contradictions: out,
    totalPenalty,
    severe,
    blocksTrade: severe || totalPenalty >= SEVERE_PENALTY_TOTAL,
  };
}

function pct(v: number): string {
  return `${v >= 0 ? '+' : ''}${v.toFixed(2)}`;
}
