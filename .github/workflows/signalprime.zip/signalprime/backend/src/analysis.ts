/**
 * Per-candle indicator snapshot: every indicator the engines need,
 * computed once per symbol/timeframe and shared by scoring, risk,
 * contradiction, and regime modules.
 */
import type { Candle } from './types.js';
import {
  adx, atr, atrPercent, bollinger, cci, closes, ema, lastFinite,
  macd, momentum, obv, percentileRank, roc, rsi, sma, stochRsi,
  volumeDeltaApprox, volumes, vwap,
} from './indicators.js';

export interface IndicatorSnapshot {
  price: number;
  atr: number;
  atrPct: number;
  ema20: number;
  ema50: number;
  ema100: number;
  ema200: number;
  rsi14: number;
  macdLine: number;
  macdSignal: number;
  macdHist: number;
  adx: number;
  plusDI: number;
  minusDI: number;
  vwap: number;
  bbUpper: number;
  bbLower: number;
  bbWidth: number;
  bbWidthRank: number;
  percentB: number;
  stochK: number;
  stochD: number;
  cci20: number;
  obvSlopePct: number;
  volumeSma20: number;
  volumeRatio: number; // current volume / volume SMA20
  roc12: number;
  momentum10: number;
  deltaApprox: number; // cumulative approx volume delta (directional)
}

export function computeSnapshot(candles: Candle[]): IndicatorSnapshot {
  const n = candles.length;
  const cl = closes(candles);
  const vol = volumes(candles);
  const price = cl[n - 1];

  const ema20 = lastFinite(ema(cl, 20));
  const ema50 = lastFinite(ema(cl, 50));
  const ema100 = lastFinite(ema(cl, 100));
  const ema200 = lastFinite(ema(cl, 200));
  const m = macd(cl);
  const adxR = adx(candles, 14);
  const atrArr = atr(candles, 14);
  const atrV = lastFinite(atrArr);
  const atrP = lastFinite(atrPercent(atrArr, cl));
  const bb = bollinger(cl, 20, 2);
  const bbWidth = lastFinite(bb.bandwidth);
  const st = stochRsi(cl);
  const obvArr = obv(candles);
  const volSma = lastFinite(sma(vol, 20));
  const delta = lastFinite(volumeDeltaApprox(candles));

  const f = obvArr.filter(Number.isFinite);
  const obvSlopePct = f.length > 21
    ? ((f[f.length - 1] - f[f.length - 21]) / Math.max(Math.abs(f[f.length - 21]), 1)) * 100
    : 0;

  return {
    price,
    atr: atrV,
    atrPct: atrP,
    ema20, ema50, ema100, ema200,
    rsi14: lastFinite(rsi(cl, 14)),
    macdLine: lastFinite(m.macdLine),
    macdSignal: lastFinite(m.signalLine),
    macdHist: lastFinite(m.histogram),
    adx: lastFinite(adxR.adx),
    plusDI: lastFinite(adxR.plusDI),
    minusDI: lastFinite(adxR.minusDI),
    vwap: lastFinite(vwap(candles)),
    bbUpper: lastFinite(bb.upper),
    bbLower: lastFinite(bb.lower),
    bbWidth,
    bbWidthRank: percentileRank(bb.bandwidth, 120),
    percentB: lastFinite(bb.percentB),
    stochK: lastFinite(st.k),
    stochD: lastFinite(st.d),
    cci20: lastFinite(cci(candles, 20)),
    obvSlopePct,
    volumeSma20: volSma,
    volumeRatio: Number.isFinite(volSma) && volSma > 0 ? vol[n - 1] / volSma : 1,
    roc12: lastFinite(roc(cl, 12)),
    momentum10: lastFinite(momentum(cl, 10)),
    deltaApprox: delta,
  };
}
