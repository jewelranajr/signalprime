/**
 * Signal scoring engine.
 *
 * Transparent 100-point scoring per direction:
 *   Trend 20 | MTF alignment 20 | Momentum 15 | Volume 10 |
 *   Market structure 10 | Support/Resistance 10 | Volatility 5 | Risk/Reward 10
 *
 * LONG and SHORT are scored independently with mirrored logic; the
 * direction gap decides whether a signal is actionable or NO_TRADE.
 */
import type { Candle, Direction, ScoreBreakdown } from './types.js';
import type { IndicatorSnapshot } from './analysis.js';
import type { MtfReport } from './mtf.js';
import type { SRZone, StructureReport } from './structure.js';

export interface ScoringContext {
  candles: Candle[];
  snap: IndicatorSnapshot;
  mtf: MtfReport;
  structure: StructureReport;
  zones: SRZone[];
}

export interface DirectionScores {
  long: number;
  short: number;
  longBreakdown: ScoreBreakdown;
  shortBreakdown: ScoreBreakdown;
  gap: number;
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}
const r1 = (v: number) => Math.round(v * 10) / 10;

function blankBreakdown(): ScoreBreakdown {
  return {
    trend: 0, mtf_alignment: 0, momentum: 0, volume: 0,
    market_structure: 0, support_resistance: 0, volatility: 0, risk_reward: 0, total: 0,
  };
}

/** Proxy RR estimate before exact entry/SL/TP exist (nearest S/R as guide). */
function proxyRR(ctx: ScoringContext, dir: 'LONG' | 'SHORT'): number {
  const price = ctx.snap.price;
  if (dir === 'LONG') {
    const sup = nearestZone(ctx.zones, 'SUPPORT');
    const res = nearestZone(ctx.zones, 'RESISTANCE');
    if (!sup || !res) return 0;
    const risk = price - sup.price;
    const reward = res.price - price;
    return risk > 0 ? reward / risk : 0;
  }
  const sup = nearestZone(ctx.zones, 'SUPPORT');
  const res = nearestZone(ctx.zones, 'RESISTANCE');
  if (!sup || !res) return 0;
  const risk = res.price - price;
  const reward = price - sup.price;
  return risk > 0 ? reward / risk : 0;
}

function nearestZone(zones: SRZone[], type: 'SUPPORT' | 'RESISTANCE'): SRZone | null {
  let best: SRZone | null = null;
  for (const z of zones) {
    if (z.type !== type) continue;
    if (!best || Math.abs(z.distance_pct) < Math.abs(best.distance_pct)) best = z;
  }
  return best;
}

function rrPoints(rr: number): number {
  if (rr >= 3) return 10;
  if (rr >= 2.5) return 8;
  if (rr >= 2) return 6;
  if (rr >= 1.5) return 3;
  return 0;
}

function volatilityPoints(snap: IndicatorSnapshot): number {
  const rank = snap.bbWidthRank;
  if (rank > 92) return 0;   // extreme — unsafe
  if (rank > 80) return 2;
  if (rank >= 30) return 5;  // normal
  if (rank >= 15) return 3;
  return 2;                  // too quiet — breakouts may fail
}

function volumePoints(snap: IndicatorSnapshot, dir: 'LONG' | 'SHORT'): number {
  const r = snap.volumeRatio;
  let pts = r >= 1.5 ? 10 : r >= 1.2 ? 7 : r >= 0.8 ? 4 : r >= 0.5 ? 2 : 0;
  // OBV confirms directional pressure.
  if (dir === 'LONG' && snap.obvSlopePct > 0.5) pts += 1;
  if (dir === 'SHORT' && snap.obvSlopePct < -0.5) pts += 1;
  // Approx delta agrees with direction.
  if (dir === 'LONG' && snap.deltaApprox > 0) pts += 1;
  if (dir === 'SHORT' && snap.deltaApprox < 0) pts += 1;
  return clamp(pts, 0, 10);
}

function scoreLong(ctx: ScoringContext): ScoreBreakdown {
  const b = blankBreakdown();
  const s = ctx.snap;
  const price = s.price;

  // 1. Trend (20)
  const bullStack = s.ema20 > s.ema50 && (Number.isFinite(s.ema200) ? s.ema50 > s.ema200 : true);
  if (bullStack && price > s.ema20) b.trend = 20;
  else if (s.ema20 > s.ema50 && price > s.ema50) b.trend = 14;
  else if (Number.isFinite(s.ema200) && price > s.ema200) b.trend = 8;
  else if (price > s.ema50) b.trend = 6;
  else b.trend = 0;
  if (Number.isFinite(s.adx) && s.adx > 25 && s.plusDI > s.minusDI) b.trend = Math.min(20, b.trend + 2);

  // 2. MTF alignment (20)
  b.mtf_alignment = ctx.mtf.dominant === 'BULLISH'
    ? (20 * ctx.mtf.alignmentScore) / 100
    : ctx.mtf.dominant === 'NEUTRAL' ? 6 : 0;

  // 3. Momentum (15)
  let mom = 0;
  if (s.rsi14 >= 55 && s.rsi14 <= 70) mom += 8;
  else if (s.rsi14 > 50 && s.rsi14 < 55) mom += 5;
  else if (s.rsi14 > 70 && s.rsi14 <= 78) mom += 4; // extended but bullish
  else if (s.rsi14 >= 45) mom += 2;
  if (s.macdHist > 0 && s.macdLine > s.macdSignal) mom += 7;
  else if (s.macdHist > 0) mom += 4;
  else if (s.macdLine > s.macdSignal) mom += 2;
  if (s.roc12 > 0) mom += 0; // already captured
  b.momentum = clamp(mom, 0, 15);

  // 4. Volume (10)
  b.volume = volumePoints(s, 'LONG');

  // 5. Market structure (10)
  let st = 0;
  const ts = ctx.structure.trendScore;
  if (ts > 50) st = 10;
  else if (ts > 25) st = 7;
  else if (ts > 0) st = 4;
  if (ctx.structure.bos && ctx.structure.bosDirection === 'UP') st += 2;
  if (ctx.structure.choch && ctx.structure.chochDirection === 'DOWN') st -= 6;
  if (ctx.structure.falseBreakoutUp) st -= 4;
  b.market_structure = clamp(st, 0, 10);

  // 6. Support/Resistance (10): room above, value below.
  const res = nearestZone(ctx.zones, 'RESISTANCE');
  const sup = nearestZone(ctx.zones, 'SUPPORT');
  let sr = 0;
  if (res && Number.isFinite(s.atr) && s.atr > 0) {
    const distAtr = ((res.price - price) / price / (s.atr / price));
    if (distAtr > 1.5) sr = 10;
    else if (distAtr > 1.0) sr = 7;
    else if (distAtr > 0.5) sr = 4;
    else sr = 0;
  } else if (res) {
    sr = Math.abs(res.distance_pct) > 1 ? 8 : 3;
  }
  if (sup && Number.isFinite(s.atr) && s.atr > 0) {
    const distAtr = ((price - sup.price) / price / (s.atr / price));
    if (distAtr < 1.0) sr = Math.min(10, sr + 2); // buying value near support
  }
  b.support_resistance = clamp(sr, 0, 10);

  // 7. Volatility (5)
  b.volatility = volatilityPoints(s);

  // 8. Risk/Reward (10)
  b.risk_reward = rrPoints(proxyRR(ctx, 'LONG'));

  b.total = r1(b.trend + b.mtf_alignment + b.momentum + b.volume +
    b.market_structure + b.support_resistance + b.volatility + b.risk_reward);
  for (const k of Object.keys(b) as (keyof ScoreBreakdown)[]) {
    if (k !== 'total') b[k] = r1(b[k]);
  }
  return b;
}

function scoreShort(ctx: ScoringContext): ScoreBreakdown {
  const b = blankBreakdown();
  const s = ctx.snap;
  const price = s.price;

  // 1. Trend (20) — mirrored
  const bearStack = s.ema20 < s.ema50 && (Number.isFinite(s.ema200) ? s.ema50 < s.ema200 : true);
  if (bearStack && price < s.ema20) b.trend = 20;
  else if (s.ema20 < s.ema50 && price < s.ema50) b.trend = 14;
  else if (Number.isFinite(s.ema200) && price < s.ema200) b.trend = 8;
  else if (price < s.ema50) b.trend = 6;
  else b.trend = 0;
  if (Number.isFinite(s.adx) && s.adx > 25 && s.minusDI > s.plusDI) b.trend = Math.min(20, b.trend + 2);

  // 2. MTF alignment (20)
  b.mtf_alignment = ctx.mtf.dominant === 'BEARISH'
    ? (20 * ctx.mtf.alignmentScore) / 100
    : ctx.mtf.dominant === 'NEUTRAL' ? 6 : 0;

  // 3. Momentum (15)
  let mom = 0;
  if (s.rsi14 <= 45 && s.rsi14 >= 30) mom += 8;
  else if (s.rsi14 < 50 && s.rsi14 > 45) mom += 5;
  else if (s.rsi14 < 30 && s.rsi14 >= 22) mom += 4;
  else if (s.rsi14 <= 55) mom += 2;
  if (s.macdHist < 0 && s.macdLine < s.macdSignal) mom += 7;
  else if (s.macdHist < 0) mom += 4;
  else if (s.macdLine < s.macdSignal) mom += 2;
  b.momentum = clamp(mom, 0, 15);

  // 4. Volume (10)
  b.volume = volumePoints(s, 'SHORT');

  // 5. Market structure (10)
  let st = 0;
  const ts = ctx.structure.trendScore;
  if (ts < -50) st = 10;
  else if (ts < -25) st = 7;
  else if (ts < 0) st = 4;
  if (ctx.structure.bos && ctx.structure.bosDirection === 'DOWN') st += 2;
  if (ctx.structure.choch && ctx.structure.chochDirection === 'UP') st -= 6;
  if (ctx.structure.falseBreakoutDown) st -= 4;
  b.market_structure = clamp(st, 0, 10);

  // 6. Support/Resistance (10): room below, no strong support directly under.
  const sup = nearestZone(ctx.zones, 'SUPPORT');
  let sr = 0;
  if (sup && Number.isFinite(s.atr) && s.atr > 0) {
    const distAtr = ((price - sup.price) / price / (s.atr / price));
    if (distAtr > 1.5) sr = 10;
    else if (distAtr > 1.0) sr = 7;
    else if (distAtr > 0.5) sr = 4;
    else sr = 0;
  } else if (sup) {
    sr = Math.abs(sup.distance_pct) > 1 ? 8 : 3;
  }
  const res = nearestZone(ctx.zones, 'RESISTANCE');
  if (res && Number.isFinite(s.atr) && s.atr > 0) {
    const distAtr = ((res.price - price) / price / (s.atr / price));
    if (distAtr < 1.0) sr = Math.min(10, sr + 2); // selling value near resistance
  }
  b.support_resistance = clamp(sr, 0, 10);

  // 7. Volatility (5)
  b.volatility = volatilityPoints(s);

  // 8. Risk/Reward (10)
  b.risk_reward = rrPoints(proxyRR(ctx, 'SHORT'));

  b.total = r1(b.trend + b.mtf_alignment + b.momentum + b.volume +
    b.market_structure + b.support_resistance + b.volatility + b.risk_reward);
  for (const k of Object.keys(b) as (keyof ScoreBreakdown)[]) {
    if (k !== 'total') b[k] = r1(b[k]);
  }
  return b;
}

export function scoreDirections(ctx: ScoringContext): DirectionScores {
  const longBreakdown = scoreLong(ctx);
  const shortBreakdown = scoreShort(ctx);
  const gap = r1(Math.abs(longBreakdown.total - shortBreakdown.total));
  return {
    long: longBreakdown.total,
    short: shortBreakdown.total,
    longBreakdown,
    shortBreakdown,
    gap,
  };
}

export type { Direction };
