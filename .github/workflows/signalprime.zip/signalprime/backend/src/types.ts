/**
 * SignalPrime — Master Signal Engine
 * Shared domain types. These types define the public API contract consumed by
 * the Android app. Field names are stable; additive changes only.
 */

export type Direction = 'LONG' | 'SHORT' | 'NO_TRADE';

export type SignalStatus =
  | 'WAITING'
  | 'ACTIVE'
  | 'TP1_HIT'
  | 'TP2_HIT'
  | 'TP3_HIT'
  | 'STOPPED'
  | 'INVALIDATED'
  | 'EXPIRED'
  | 'CLOSED';

export type SignalResult = 'WIN' | 'LOSS' | 'PENDING' | 'EXPIRED' | null;

export type MarketRegime =
  | 'STRONG_BULL'
  | 'BULL'
  | 'WEAK_BULL'
  | 'NEUTRAL'
  | 'RANGE'
  | 'WEAK_BEAR'
  | 'BEAR'
  | 'STRONG_BEAR'
  | 'HIGH_VOLATILITY'
  | 'CHOPPY'
  | 'ACCUMULATION'
  | 'DISTRIBUTION';

export type TimeframeBias = 'BULLISH' | 'BEARISH' | 'NEUTRAL';

export type EntryType = 'PULLBACK' | 'BREAKOUT_RETEST' | 'MARKET' | 'WAIT_FOR_PULLBACK';

/** Binance-style OHLCV candle, normalized. */
export interface Candle {
  openTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  closeTime: number;
}

export interface Ticker {
  symbol: string;
  price: number;
  price_change_24h: number;
  price_change_percent_24h: number;
  volume_24h: number;
  quote_volume_24h: number;
  high_24h: number;
  low_24h: number;
}

export interface EntryZone {
  low: number;
  high: number;
  preferred: number;
  type: EntryType;
}

export interface StopLoss {
  price: number;
  distance_percent: number;
  reason: string;
}

export interface TakeProfit {
  tp1: number;
  tp2: number;
  tp3: number;
}

export interface RiskReward {
  tp1: number;
  tp2: number;
  tp3: number;
}

export interface PositionPlan {
  risk_percent: number;
  risk_amount: number;
  quantity: number;
  leverage: number;
  account_balance: number;
}

export interface MtfSlice {
  timeframe: string;
  bias: TimeframeBias;
  /** -100 (strong bearish) .. +100 (strong bullish) */
  score: number;
  trend: string;
  notes: string[];
}

export interface ScoreBreakdown {
  trend: number;
  mtf_alignment: number;
  momentum: number;
  volume: number;
  market_structure: number;
  support_resistance: number;
  volatility: number;
  risk_reward: number;
  total: number;
}

/**
 * Master Signal — the single output of the engine.
 * For NO_TRADE signals, entry/stop_loss/take_profit/position may be null.
 */
export interface Signal {
  signal_id: string;
  symbol: string;
  direction: Direction;
  status: SignalStatus;
  long_score: number;
  short_score: number;
  direction_gap: number;
  long_breakdown: ScoreBreakdown | null;
  short_breakdown: ScoreBreakdown | null;
  /** 0-100 model confidence. An estimate, not a guarantee. */
  confidence: number;
  /** 0-100 heuristic probability estimate from the scoring model. Not calibrated. */
  probability_estimate: number;
  entry: EntryZone | null;
  stop_loss: StopLoss | null;
  take_profit: TakeProfit | null;
  risk_reward: RiskReward | null;
  position: PositionPlan | null;
  market_regime: MarketRegime;
  mtf: MtfSlice[];
  /** Human-readable "WHY LONG / WHY SHORT / WHY NO_TRADE" */
  reasons: string[];
  warnings: string[];
  /** Conditions that would invalidate the signal */
  invalidation: string[];
  contradictions: string[];
  created_at: string;
  expires_at: string;
}

export interface PersistedSignal extends Signal {
  result: SignalResult;
  pnl_pct: number | null;
  exit_price: number | null;
  updated_at: string;
}

export interface ScannerItem {
  symbol: string;
  price: number;
  change_24h_pct: number;
  volume_24h: number;
  direction: Direction;
  long_score: number;
  short_score: number;
  direction_gap: number;
  confidence: number;
  probability_estimate: number;
  market_regime: MarketRegime;
  entry_preferred: number | null;
  risk_reward_tp1: number | null;
  rank_score: number;
  updated_at: string;
}

export interface MarketOverview {
  btc: Ticker | null;
  eth: Ticker | null;
  bullish_pct: number;
  bearish_pct: number;
  total_scanned: number;
  active_signals: number;
  best_signal: Signal | null;
  best_rr_signal: Signal | null;
  market_regime: MarketRegime;
  updated_at: string;
}

export interface RegimeReport {
  symbol: string;
  regime: MarketRegime;
  /** -100 (extreme bear) .. +100 (extreme bull) */
  bias_score: number;
  components: Record<string, number>;
  notes: string[];
  updated_at: string;
}

export interface BacktestRequest {
  symbol: string;
  timeframe: string;
  start: string;
  end: string;
  initial_balance: number;
  risk_percent: number;
}

export interface BacktestTrade {
  opened_at: string;
  direction: Direction;
  entry: number;
  stop_loss: number;
  tp1: number;
  tp2: number;
  tp3: number;
  exit: number;
  exit_reason: 'TP1' | 'TP2' | 'TP3' | 'SL' | 'EXPIRED';
  pnl: number;
  pnl_pct: number;
  rr: number;
}

export interface BacktestResult {
  symbol: string;
  timeframe: string;
  total_trades: number;
  wins: number;
  losses: number;
  win_rate: number;
  net_pnl: number;
  net_pnl_pct: number;
  max_drawdown_pct: number;
  profit_factor: number;
  avg_rr: number;
  avg_win_pct: number;
  avg_loss_pct: number;
  trades: BacktestTrade[];
}

export interface EngineConfig {
  min_score: number;
  extreme_score: number;
  min_direction_gap: number;
  min_rr: number;
  min_confidence: number;
  min_data_candles: number;
  default_balance: number;
  default_risk_percent: number;
  max_risk_percent: number;
}

export interface ApiError {
  error: {
    code:
      | 'MARKET_DATA_UNAVAILABLE'
      | 'SYMBOL_NOT_FOUND'
      | 'INSUFFICIENT_DATA'
      | 'STALE_DATA'
      | 'INVALID_REQUEST'
      | 'RATE_LIMITED'
      | 'SERVER_ERROR';
    message: string;
  };
}

/** Server-side runtime settings (env-derived). */
export interface Settings {
  port: number;
  host: string;
  binanceHosts: string[];
  binanceTimeoutMs: number;
  minScore: number;
  extremeScore: number;
  minDirectionGap: number;
  minRr: number;
  minConfidence: number;
  minDataCandles: number;
  defaultBalance: number;
  defaultRiskPercent: number;
  maxRiskPercent: number;
  scannerTopSymbols: number;
  scannerMaxSymbols: number;
  scannerCacheTtlMs: number;
  corsOrigins: string;
  rateLimitMax: number;
  rateLimitWindowMs: number;
  apiKey: string;
  logLevel: string;
  dataDir: string;
}
