/**
 * Live signal monitor.
 *
 * Polls active (WAITING/ACTIVE) signals and advances their lifecycle:
 * WAITING → ACTIVE (entry zone touched) → TP1/TP2/TP3_HIT / STOPPED,
 * plus EXPIRED handling. Historical signals are never rewritten —
 * only status/result fields move forward, with an event log per transition.
 *
 * Limitation (documented): checks use ticker snapshots, so intrabar wick
 * extremes between polls can be missed. Poll frequently for live use.
 */
import type { Settings, SignalStatus } from './types.js';
import { BinanceClient } from './exchange.js';
import { SignalStore } from './database.js';

export class SignalMonitor {
  private timer: NodeJS.Timeout | null = null;

  constructor(
    private readonly exchange: BinanceClient,
    private readonly store: SignalStore,
    private readonly settings: Settings,
    private readonly log: (msg: string, data?: unknown) => void = () => {},
  ) {
    void this.settings;
  }

  start(intervalMs = 60_000): void {
    if (this.timer) return;
    this.log(`Signal monitor started (every ${intervalMs}ms)`);
    this.timer = setInterval(() => {
      this.tick().catch((err) => this.log('monitor tick failed', { err: String(err) }));
    }, intervalMs);
    this.tick().catch((err) => this.log('monitor tick failed', { err: String(err) }));
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  async tick(): Promise<void> {
    const active = this.store.listSignals({ status: ['WAITING', 'ACTIVE'], limit: 200 });
    if (active.length === 0) return;
    // Batch tickers by symbol to avoid N requests.
    const symbols = [...new Set(active.map((s) => s.symbol))];
    const prices = new Map<string, number>();
    await Promise.all(
      symbols.map(async (sym) => {
        try {
          const t = await this.exchange.getTicker(sym);
          prices.set(sym, t.price);
        } catch {
          // skip — try again next tick
        }
      }),
    );
    const now = new Date().toISOString();
    for (const sig of active) {
      const price = prices.get(sig.symbol);
      if (price === undefined) continue;
      const next = this.evaluate(sig, price, now);
      if (next) {
        this.store.updateSignal(sig.signal_id, next);
        this.store.addEvent(sig.signal_id, next.status, price, now);
        this.log(`Signal ${sig.signal_id}: ${sig.status} → ${next.status} @ ${price}`);
      }
    }
  }

  private evaluate(
    sig: ReturnType<SignalStore['listSignals']>[number],
    price: number,
    now: string,
  ): { status: SignalStatus; result: 'WIN' | 'LOSS' | 'PENDING' | 'EXPIRED' | null; pnl_pct: number | null; exit_price: number | null } | null {
    if (now > sig.expires_at && (sig.status === 'WAITING' || sig.status === 'ACTIVE')) {
      // If TPs were already hit, keep the win; otherwise expire.
      if (sig.status === 'ACTIVE' && sig.result === 'WIN') {
        return { status: 'EXPIRED', result: 'WIN', pnl_pct: sig.pnl_pct, exit_price: sig.exit_price };
      }
      return { status: 'EXPIRED', result: 'EXPIRED', pnl_pct: sig.pnl_pct, exit_price: sig.exit_price };
    }
    if (sig.direction === 'NO_TRADE' || !sig.entry || !sig.stop_loss || !sig.take_profit) return null;
    const long = sig.direction === 'LONG';
    const entry = sig.entry.preferred;

    if (sig.status === 'WAITING') {
      if (price >= sig.entry.low && price <= sig.entry.high) {
        return { status: 'ACTIVE', result: 'PENDING', pnl_pct: null, exit_price: null };
      }
      // Far beyond entry without touching zone → invalidate (missed).
      const missed = long ? price > sig.take_profit.tp1 : price < sig.take_profit.tp1;
      if (missed) {
        return { status: 'INVALIDATED', result: null, pnl_pct: null, exit_price: null };
      }
      return null;
    }

    // ACTIVE — check SL first (conservative), then TPs top-down.
    const sl = sig.stop_loss.price;
    const hitSL = long ? price <= sl : price >= sl;
    if (hitSL) {
      const pnl = long ? ((sl - entry) / entry) * 100 : ((entry - sl) / entry) * 100;
      return { status: 'STOPPED', result: 'LOSS', pnl_pct: r2(pnl), exit_price: sl };
    }
    const tpHit = long
      ? price >= sig.take_profit.tp3 ? 3 : price >= sig.take_profit.tp2 ? 2 : price >= sig.take_profit.tp1 ? 1 : 0
      : price <= sig.take_profit.tp3 ? 3 : price <= sig.take_profit.tp2 ? 2 : price <= sig.take_profit.tp1 ? 1 : 0;
    if (tpHit > 0) {
      const tpPrice = tpHit === 3 ? sig.take_profit.tp3 : tpHit === 2 ? sig.take_profit.tp2 : sig.take_profit.tp1;
      const pnl = long ? ((tpPrice - entry) / entry) * 100 : ((entry - tpPrice) / entry) * 100;
      const status: SignalStatus = tpHit === 3 ? 'TP3_HIT' : tpHit === 2 ? 'TP2_HIT' : 'TP1_HIT';
      return { status, result: 'WIN', pnl_pct: r2(pnl), exit_price: tpPrice };
    }
    return null;
  }
}

function r2(v: number): number {
  return Math.round(v * 100) / 100;
}
