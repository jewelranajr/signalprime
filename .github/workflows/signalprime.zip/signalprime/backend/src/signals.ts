/**
 * Master Signal Engine — final decision orchestrator.
 *
 * Pipeline: validate data → snapshot → structure → S/R → regime → MTF →
 * score LONG/SHORT → contradiction check → thresholds → entry/SL/TP/position
 * → confidence → LONG / SHORT / NO_TRADE.
 *
 * Quality > quantity: any doubt resolves to NO_TRADE with explicit reasons.
 */
import type {
  Candle, Direction, MarketRegime, Settings, Signal,
} from './types.js';
import { computeSnapshot, type IndicatorSnapshot } from './analysis.js';
import { analyzeStructure, detectSRZones, type StructureReport } from './structure.js';
import { detectRegime } from './regime.js';
import { analyzeMtf, type MtfInput, type MtfReport } from './mtf.js';
import { scoreDirections, type ScoringContext } from './scoring.js';
import { detectContradictions } from './contradiction.js';
import { assessVolatility, planTrade } from './risk.js';
import { INTERVAL_MS } from './exchange.js';

export interface SignalOptions {
  balance?: number;
  riskPercent?: number;
  primaryTimeframe?: string;
}

export interface EngineInput {
  symbol: string;
  /** Primary timeframe candles (must meet MIN_DATA_CANDLES). */
  primary: Candle[];
  primaryTimeframe: string;
  /** All timeframe candles for MTF (primary included). */
  mtfInputs: MtfInput[];
  settings: Settings;
  options?: SignalOptions;
}

function iso(ms: number): string {
  return new Date(ms).toISOString();
}

function baseNoTrade(
  symbol: string,
  timeframe: string,
  reasons: string[],
  partial: Partial<Signal> & { market_regime: MarketRegime; mtf: Signal['mtf'] },
): Signal {
  const now = Date.now();
  const ttl = Math.min((INTERVAL_MS[timeframe] ?? 3_600_000) * 8, 24 * 3_600_000);
  return {
    signal_id: `${symbol}-${timeframe}-${now}`,
    symbol,
    direction: 'NO_TRADE',
    status: 'CLOSED',
    long_score: partial.long_score ?? 0,
    short_score: partial.short_score ?? 0,
    direction_gap: partial.direction_gap ?? 0,
    long_breakdown: partial.long_breakdown ?? null,
    short_breakdown: partial.short_breakdown ?? null,
    confidence: 0,
    probability_estimate: 0,
    entry: null,
    stop_loss: null,
    take_profit: null,
    risk_reward: null,
    position: null,
    market_regime: partial.market_regime,
    mtf: partial.mtf,
    reasons,
    warnings: partial.warnings ?? [],
    invalidation: [],
    contradictions: partial.contradictions ?? [],
    created_at: iso(now),
    expires_at: iso(now + ttl),
  };
}

export function generateSignal(input: EngineInput): Signal {
  const { symbol, primary, primaryTimeframe, mtfInputs, settings, options } = input;
  const balance = options?.balance && options.balance > 0 ? options.balance : settings.defaultBalance;
  const riskPercent = Math.min(
    options?.riskPercent && options.riskPercent > 0 ? options.riskPercent : settings.defaultRiskPercent,
    settings.maxRiskPercent,
  );

  // Pre-compute shared context pieces (cheap enough to reuse for NO_TRADE).
  const mtf = analyzeMtf(mtfInputs);
  const regime = detectRegime(primary);

  // ---- 1. Data validation ----
  if (primary.length < settings.minDataCandles) {
    return baseNoTrade(symbol, primaryTimeframe,
      [`WHY NO_TRADE: insufficient data — ${primary.length} candles, need ${settings.minDataCandles}`],
      { market_regime: regime.regime, mtf: mtf.slices, long_score: 0, short_score: 0, direction_gap: 0 });
  }

  const snap: IndicatorSnapshot = computeSnapshot(primary);
  const structure: StructureReport = analyzeStructure(primary);
  const zones = detectSRZones(primary, 8);

  const ctx: ScoringContext = { candles: primary, snap, mtf, structure, zones };

  // ---- 2. Score both directions ----
  const scores = scoreDirections(ctx);
  const leading: 'LONG' | 'SHORT' = scores.long >= scores.short ? 'LONG' : 'SHORT';
  const leadingScore = leading === 'LONG' ? scores.long : scores.short;

  const contra = detectContradictions({ snap, mtf, structure, zones }, leading);
  const contraDesc = contra.contradictions.map(
    (c) => `⚠ ${c.description} (penalty ${c.penalty})`,
  );

  // ---- 3. NO_TRADE gates (ordered by diagnostic value) ----
  const gate = (reasons: string[]): Signal | null => {
    if (reasons.length === 0) return null;
    return baseNoTrade(symbol, primaryTimeframe,
      reasons.map((r) => `WHY NO_TRADE: ${r}`),
      {
        market_regime: regime.regime, mtf: mtf.slices,
        long_score: scores.long, short_score: scores.short, direction_gap: scores.gap,
        long_breakdown: scores.longBreakdown, short_breakdown: scores.shortBreakdown,
        warnings: regime.notes, contradictions: contraDesc,
      });
  };

  const blocked = gate([
    ...(contra.blocksTrade ? [`contradictions too severe (penalty ${contra.totalPenalty})`] : []),
  ]);
  if (blocked) return blocked;

  const lowScore = gate(
    leadingScore < settings.minScore
      ? [`${leading} score ${leadingScore} below minimum ${settings.minScore}`] : [],
  );
  if (lowScore) return lowScore;

  const smallGap = gate(
    scores.gap < settings.minDirectionGap
      ? [`direction gap ${scores.gap} below minimum ${settings.minDirectionGap} — no clear edge (LONG ${scores.long} vs SHORT ${scores.short})`] : [],
  );
  if (smallGap) return smallGap;

  // ---- 4. Build the trade plan ----
  const plan = planTrade({ snap, structure, zones }, leading, balance, riskPercent);
  if (plan.waitForPullback || !plan.entry || !plan.stopLoss || !plan.takeProfit || !plan.riskReward || !plan.position) {
    const noTrade = gate([
      ...(plan.waitForPullback ? ['price extended from ideal entry — wait for pullback'] : ['could not construct a valid entry/stop plan']),
      ...plan.warnings,
    ]);
    if (noTrade) return noTrade;
  }
  const entry = plan.entry!;
  const stopLoss = plan.stopLoss!;
  const takeProfit = plan.takeProfit!;
  const riskReward = plan.riskReward!;
  const position = plan.position!;

  const poorRR = gate(
    riskReward.tp1 < settings.minRr ? [`risk/reward ${riskReward.tp1.toFixed(2)} below minimum ${settings.minRr}`] : [],
  );
  if (poorRR) return poorRR;

  // ---- 5. Confidence (model estimate, honestly labeled) ----
  const volLevel = assessVolatility(snap);
  const confidence = computeConfidence({
    score: leadingScore,
    gap: scores.gap,
    mtfAlignment: mtf.alignmentScore,
    rr: riskReward.tp1,
    contraPenalty: contra.totalPenalty,
    volLevel,
    extreme: leadingScore >= settings.extremeScore,
  });

  const lowConf = gate(
    confidence < settings.minConfidence
      ? [`confidence ${confidence}% below minimum ${settings.minConfidence}%`] : [],
  );
  if (lowConf) return lowConf;

  // ---- 6. Assemble the directional signal ----
  const now = Date.now();
  const ttl = Math.min((INTERVAL_MS[primaryTimeframe] ?? 3_600_000) * 8, 24 * 3_600_000);
  const reasons = buildReasons(leading, ctx, scores, mtf, regime, riskReward, leadingScore >= settings.extremeScore);
  const warnings = [...plan.warnings, ...contraDesc, ...regime.notes.filter((n) => /volatility|overbought|oversold/i.test(n))];
  const invalidation = buildInvalidation(leading, stopLoss, primaryTimeframe);
  const probability = Math.max(1, Math.min(99, Math.round(confidence * 0.94)));

  const signal: Signal = {
    signal_id: `${symbol}-${primaryTimeframe}-${now}`,
    symbol,
    direction: leading as Direction,
    status: 'WAITING',
    long_score: scores.long,
    short_score: scores.short,
    direction_gap: scores.gap,
    long_breakdown: scores.longBreakdown,
    short_breakdown: scores.shortBreakdown,
    confidence,
    probability_estimate: probability,
    entry,
    stop_loss: stopLoss,
    take_profit: takeProfit,
    risk_reward: riskReward,
    position,
    market_regime: regime.regime,
    mtf: mtf.slices,
    reasons,
    warnings: [...new Set(warnings)],
    invalidation,
    contradictions: contraDesc,
    created_at: iso(now),
    expires_at: iso(now + ttl),
  };
  return signal;
}

function computeConfidence(p: {
  score: number; gap: number; mtfAlignment: number; rr: number;
  contraPenalty: number; volLevel: string; extreme: boolean;
}): number {
  // Weighted model estimate — NOT a calibrated statistical probability.
  let c = (p.score / 100) * 50;                    // up to 50
  c += Math.min(20, (p.gap / 40) * 20);            // up to 20
  c += (p.mtfAlignment / 100) * 15;                // up to 15
  c += p.rr >= 3 ? 10 : p.rr >= 2.5 ? 7 : 5;       // up to 10
  c -= Math.min(25, p.contraPenalty * 0.6);        // contradiction discount
  if (p.volLevel === 'EXTREME') c -= 12;
  else if (p.volLevel === 'HIGH') c -= 5;
  if (p.extreme) c += 3;
  return Math.max(0, Math.min(100, Math.round(c)));
}

function buildReasons(
  leading: 'LONG' | 'SHORT',
  ctx: ScoringContext,
  scores: ReturnType<typeof scoreDirections>,
  mtf: MtfReport,
  regime: ReturnType<typeof detectRegime>,
  rr: { tp1: number },
  extreme: boolean,
): string[] {
  const b = leading === 'LONG' ? scores.longBreakdown : scores.shortBreakdown;
  const dir = leading === 'LONG' ? 'LONG' : 'SHORT';
  const out = [
    `WHY ${dir}: score ${leading === 'LONG' ? scores.long : scores.short}/100 (gap ${scores.gap})`,
    ...(extreme ? ['EXTREME signal — score above extreme threshold'] : []),
    `Trend ${b.trend}/20 — ${ctx.snap.ema20 > ctx.snap.ema50 ? 'EMA20 above EMA50' : 'EMA20 below EMA50'}`,
    `MTF ${b.mtf_alignment}/20 — ${mtf.dominant} dominant (${mtf.alignmentScore}% agreement)`,
    `Momentum ${b.momentum}/15 — RSI ${ctx.snap.rsi14.toFixed(1)}, MACD hist ${ctx.snap.macdHist >= 0 ? '+' : ''}${ctx.snap.macdHist.toFixed(2)}`,
    `Volume ${b.volume}/10 — ${ctx.snap.volumeRatio.toFixed(2)}x average`,
    `Structure ${b.market_structure}/10 — ${ctx.structure.state}`,
    `S/R ${b.support_resistance}/10 — RR ${rr.tp1.toFixed(2)} at TP1`,
    `Regime: ${regime.regime}`,
  ];
  for (const n of ctx.structure.notes.slice(0, 3)) out.push(`Structure: ${n}`);
  return out;
}

function buildInvalidation(
  leading: 'LONG' | 'SHORT',
  stopLoss: { price: number },
  timeframe: string,
): string[] {
  const px = (v: number) => (v >= 1000 ? v.toFixed(1) : v >= 10 ? v.toFixed(2) : v.toFixed(4));
  return [
    `${leading === 'LONG' ? 'Close below' : 'Close above'} stop ${px(stopLoss.price)} invalidates the setup`,
    `Opposite-direction CHoCH on ${timeframe} invalidates the setup`,
    `Signal expires — re-evaluate after expiry`,
    `A major S/R flip at entry zone invalidates the setup`,
  ];
}
