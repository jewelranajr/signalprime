import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { computeSnapshot } from '../analysis.js';
import { scoreDirections } from '../scoring.js';
import { detectContradictions } from '../contradiction.js';
import { planTrade } from '../risk.js';
import { analyzeStructure, detectSRZones } from '../structure.js';
import { analyzeMtf } from '../mtf.js';
import { genCandles, testSettings } from './helpers.js';
import type { ScoringContext } from '../scoring.js';

function makeCtx(seed: number, drift: number): ScoringContext {
  const candles = genCandles(300, 100, drift, 0.004, seed);
  const snap = computeSnapshot(candles);
  const mtfInputs = [
    { timeframe: '1h', candles },
    { timeframe: '4h', candles: genCandles(300, 100, drift, 0.006, seed + 1) },
  ];
  return {
    candles,
    snap,
    mtf: analyzeMtf(mtfInputs),
    structure: analyzeStructure(candles),
    zones: detectSRZones(candles, 8),
  };
}

describe('scoring engine', () => {
  it('scores long higher than short in an uptrend', () => {
    const ctx = makeCtx(301, 0.004);
    const s = scoreDirections(ctx);
    assert.ok(s.long > s.short, `long=${s.long} short=${s.short}`);
    assert.equal(s.gap, Math.abs(s.long - s.short));
    assert.ok(s.long <= 100 && s.short <= 100);
    const total = Object.entries(s.longBreakdown)
      .filter(([k]) => k !== 'total')
      .reduce((a, [, v]) => a + (v as number), 0);
    assert.ok(Math.abs(total - s.longBreakdown.total) < 0.2);
  });

  it('scores short higher than long in a downtrend', () => {
    const ctx = makeCtx(311, -0.004);
    const s = scoreDirections(ctx);
    assert.ok(s.short > s.long, `short=${s.short} long=${s.long}`);
  });

  it('produces a small gap in choppy markets', () => {
    const ctx = makeCtx(321, 0);
    const s = scoreDirections(ctx);
    assert.ok(s.gap < 25, `gap=${s.gap}`);
  });
});

describe('contradiction engine', () => {
  it('penalizes long into overhead resistance', () => {
    const ctx = makeCtx(331, 0.002);
    // Strong resistance zone just above price, as the ONLY zone.
    const price = ctx.snap.price;
    const zones = [
      {
        price_low: price * 1.0002, price_high: price * 1.0008, price: price * 1.0005,
        type: 'RESISTANCE' as const, touches: 5, strength: 85, distance_pct: 0.05,
      },
    ];
    const r = detectContradictions({ snap: ctx.snap, mtf: ctx.mtf, structure: ctx.structure, zones }, 'LONG');
    assert.ok(r.contradictions.some((c) => c.id === 'resistance_ahead'), JSON.stringify(r.contradictions.map((c) => c.id)));
    assert.ok(r.blocksTrade, 'severe overhead resistance should block the trade');
  });

  it('does not block a clean trend', () => {
    const ctx = makeCtx(341, 0.004);
    const r = detectContradictions({ snap: ctx.snap, mtf: ctx.mtf, structure: ctx.structure, zones: ctx.zones }, 'LONG');
    assert.ok(!r.severe);
  });
});

describe('risk engine', () => {
  /** Trend that ends with a pullback into value (so a plan is valid). */
  function pullbackSetup(seed: number, dir: 1 | -1) {
    const candles = genCandles(300, 100, 0.003 * dir, 0.004, seed);
    // Ease the last 20 candles back toward EMA20 (two passes: scaling moves EMA too).
    for (let pass = 0; pass < 2; pass++) {
      const ref = computeSnapshot(candles).ema20;
      const lastClose = candles[candles.length - 1].close;
      const target = dir === 1 ? ref * 1.002 : ref * 0.998;
      const factor = target / lastClose;
      for (let i = candles.length - 20; i < candles.length; i++) {
        const t = (i - (candles.length - 20)) / 20;
        const f = 1 - (1 - factor) * t;
        const cd = candles[i];
        cd.open *= f; cd.high *= f; cd.low *= f; cd.close *= f;
      }
    }
    const snap = computeSnapshot(candles);
    const structure = analyzeStructure(candles);
    return { candles, snap, structure, zones: detectSRZones(candles, 8) };
  }

  it('builds a valid long plan with RR multiples 2.0/2.8/3.6', () => {
    const { snap, structure, zones } = pullbackSetup(351, 1);
    const plan = planTrade({ snap, structure, zones }, 'LONG', 10000, 1);
    assert.ok(plan.entry && plan.stopLoss && plan.takeProfit && plan.riskReward && plan.position);
    assert.equal(plan.riskReward.tp1, 2.0);
    assert.equal(plan.riskReward.tp2, 2.8);
    assert.equal(plan.riskReward.tp3, 3.6);
    assert.ok(plan.stopLoss.price < plan.entry.preferred);
    assert.ok(plan.takeProfit.tp1 > plan.entry.preferred);
    // Position sizing math: quantity * risk distance == risk amount.
    const riskDist = plan.entry.preferred - plan.stopLoss.price;
    assert.ok(Math.abs(plan.position.quantity * riskDist - plan.position.risk_amount) < 0.01);
    assert.equal(plan.position.risk_amount, 100);
    assert.ok(plan.position.leverage >= 1 && plan.position.leverage <= 10);
  });

  it('builds a valid short plan (mirror)', () => {
    const { snap, structure, zones } = pullbackSetup(361, -1);
    const plan = planTrade({ snap, structure, zones }, 'SHORT', 10000, 1);
    assert.ok(plan.entry && plan.stopLoss && plan.takeProfit);
    assert.ok(plan.stopLoss.price > plan.entry.preferred);
    assert.ok(plan.takeProfit.tp1 < plan.entry.preferred);
  });

  it('caps leverage in extreme volatility', () => {
    const candles = genCandles(300, 100, 0, 0.05, 371);
    const snap = computeSnapshot(candles);
    const structure = analyzeStructure(candles);
    const plan = planTrade({ snap, structure, zones: detectSRZones(candles, 8) }, 'LONG', 10000, 1);
    if (plan.position) {
      assert.ok(plan.position.leverage <= 5, `leverage=${plan.position.leverage}`);
    }
  });

  it('returns WAIT_FOR_PULLBACK when price is extended', () => {
    void testSettings;
    // Uptrend then a vertical spike on the last candles.
    const candles = genCandles(300, 100, 0.004, 0.003, 381);
    for (let i = 0; i < 5; i++) {
      const c = candles[candles.length - 1 - i];
      const spike = 1 + 0.06 * (5 - i);
      c.close *= spike; c.high *= spike;
    }
    const snap = computeSnapshot(candles);
    const structure = analyzeStructure(candles);
    const plan = planTrade({ snap, structure, zones: detectSRZones(candles, 8) }, 'LONG', 10000, 1);
    assert.ok(plan.waitForPullback || plan.entry === null || (plan.warnings.length > 0));
  });
});
