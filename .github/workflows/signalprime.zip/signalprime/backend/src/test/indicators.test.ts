import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  sma, ema, rsi, macd, atr, adx, vwap, bollinger, stochRsi, cci, obv,
  roc, momentum, lastFinite, typicalPrices,
} from '../indicators.js';
import type { Candle } from '../types.js';
import { genCandles, approx } from './helpers.js';

const c = (close: number, i = 0): Candle => ({
  openTime: i, open: close, high: close * 1.01, low: close * 0.99,
  close, volume: 100, closeTime: i + 1,
});

describe('indicators', () => {
  it('sma computes rolling mean', () => {
    const out = sma([1, 2, 3, 4, 5], 3);
    assert.ok(Number.isNaN(out[0]) && Number.isNaN(out[1]));
    assert.ok(approx(out[2], 2) && approx(out[4], 4));
  });

  it('ema of a constant series equals the constant', () => {
    const out = ema(new Array(50).fill(7), 20);
    assert.ok(approx(lastFinite(out), 7, 1e-9));
  });

  it('ema reacts faster than sma mid-transition on a step change', () => {
    const vals = [...new Array(50).fill(10), ...new Array(10).fill(20)];
    // A few bars after the step, EMA (less lag) is closer to the new level.
    const e = ema(vals, 10)[53];
    const s = sma(vals, 10)[53];
    assert.ok(e > s, `ema ${e} should exceed sma ${s} mid-transition`);
  });

  it('rsi is 100 for an all-up series and 0 for all-down', () => {
    const up = Array.from({ length: 30 }, (_, i) => 100 + i);
    const down = Array.from({ length: 30 }, (_, i) => 100 - i);
    assert.ok(approx(lastFinite(rsi(up)), 100, 1e-6));
    assert.ok(approx(lastFinite(rsi(down)), 0, 1e-6));
  });

  it('rsi stays within 0..100 on noisy data', () => {
    const candles = genCandles(200, 100, 0, 0.01, 7);
    const vals = rsi(candles.map((x) => x.close)).filter(Number.isFinite);
    assert.ok(vals.every((v) => v >= 0 && v <= 100));
    assert.ok(vals.length > 150);
  });

  it('macd histogram is positive in an accelerating uptrend', () => {
    const closesArr = Array.from({ length: 120 }, (_, i) => 100 + i * i * 0.01);
    const { histogram, macdLine, signalLine } = macd(closesArr);
    assert.ok(lastFinite(histogram) > 0, `hist=${lastFinite(histogram)}`);
    assert.ok(lastFinite(macdLine) > lastFinite(signalLine));
  });

  it('atr is ~0 for flat candles and positive for volatile ones', () => {
    const flat = Array.from({ length: 30 }, (_, i) => ({
      openTime: i, open: 100, high: 100, low: 100, close: 100, volume: 100, closeTime: i + 1,
    }));
    assert.ok(lastFinite(atr(flat)) < 1e-9);
    const noisy = genCandles(60, 100, 0, 0.02, 13);
    assert.ok(lastFinite(atr(noisy)) > 0);
  });

  it('adx is high in a strong trend, low in chop', () => {
    const trend = genCandles(120, 100, 0.006, 0.002, 17);
    const chop = genCandles(120, 100, 0, 0.001, 19);
    const adxTrend = lastFinite(adx(trend).adx);
    const adxChop = lastFinite(adx(chop).adx);
    assert.ok(adxTrend > adxChop, `trend adx ${adxTrend} should exceed chop adx ${adxChop}`);
  });

  it('vwap stays within candle extremes', () => {
    const candles = genCandles(100, 100, 0.001, 0.005, 23);
    const v = vwap(candles);
    const last = lastFinite(v);
    const lo = Math.min(...candles.map((x) => x.low));
    const hi = Math.max(...candles.map((x) => x.high));
    assert.ok(last >= lo && last <= hi);
  });

  it('bollinger bands contain most closes and bandwidth is positive', () => {
    const candles = genCandles(120, 100, 0, 0.004, 29);
    const closesArr = candles.map((x) => x.close);
    const bb = bollinger(closesArr);
    const u = lastFinite(bb.upper), m = lastFinite(bb.middle), l = lastFinite(bb.lower);
    assert.ok(u > m && m > l && lastFinite(bb.bandwidth) > 0);
    const inside = closesArr.filter((p, i) => p <= bb.upper[i] && p >= bb.lower[i]).length;
    assert.ok(inside / closesArr.length > 0.75);
  });

  it('stochastic rsi stays within 0..100', () => {
    const candles = genCandles(150, 100, 0.001, 0.008, 31);
    const { k, d } = stochRsi(candles.map((x) => x.close));
    for (const v of [...k.filter(Number.isFinite), ...d.filter(Number.isFinite)]) {
      assert.ok(v >= 0 && v <= 100);
    }
  });

  it('cci is finite and obv rises with up closes', () => {
    const candles = genCandles(120, 100, 0.003, 0.003, 37);
    assert.ok(Number.isFinite(lastFinite(cci(candles))));
    const o = obv(candles);
    assert.ok(lastFinite(o) > o[1]);
  });

  it('roc and momentum are positive in an uptrend', () => {
    const candles = genCandles(100, 100, 0.003, 0.002, 41);
    const closesArr = candles.map((x) => x.close);
    assert.ok(lastFinite(roc(closesArr)) > 0);
    assert.ok(lastFinite(momentum(closesArr)) > 0);
  });

  it('typicalPrices equals (h+l+c)/3', () => {
    const tp = typicalPrices([c(100, 0)]);
    assert.ok(approx(tp[0], (101 + 99 + 100) / 3));
  });
});
