import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { generateSignal } from '../signals.js';
import { genCandles, genRange, prng, testSettings } from './helpers.js';

/** Realistic steady trend: rising value line, oscillations, volume expansion on up moves. */
function realisticTrend(seed: number, dir: 1 | -1 = 1, n = 300) {
  const rand = prng(seed);
  const out: import('../types.js').Candle[] = [];
  let t = Date.now() - n * 3_600_000;
  let prevClose = 100;
  for (let i = 0; i < n; i++) {
    const trend = 100 * (1 + dir * 0.0006 * i);
    const osc = 0.008 * Math.sin(i / 6) + (rand() - 0.5) * 0.003;
    const c = trend * (1 + osc);
    const o = i === 0 ? c * (1 - dir * 0.001) : prevClose;
    const chg = (c - o) / o;
    const volume = 100 + 30000 * Math.max(0, dir * chg) + rand() * 60;
    out.push({
      openTime: t, open: o, high: Math.max(o, c) * 1.0008, low: Math.min(o, c) * 0.9992,
      close: c, volume, closeTime: t + 3_600_000 - 1,
    });
    prevClose = c;
    t += 3_600_000;
  }
  const last = out[out.length - 1];
  last.close = last.open * (1 + dir * 0.004);
  last.high = Math.max(last.open, last.close) * 1.0008;
  last.volume = 500;
  return out;
}

describe('master signal engine', () => {
  it('returns NO_TRADE with reasons on insufficient data', () => {
    const candles = genCandles(30, 100, 0.002, 0.003, 401);
    const settings = testSettings();
    const sig = generateSignal({
      symbol: 'BTCUSDT',
      primary: candles,
      primaryTimeframe: '1h',
      mtfInputs: [{ timeframe: '1h', candles }],
      settings,
    });
    assert.equal(sig.direction, 'NO_TRADE');
    assert.ok(sig.reasons.some((r) => /insufficient data/i.test(r)));
    assert.equal(sig.entry, null);
  });

  it('produces a LONG signal on a strong aligned uptrend (relaxed thresholds)', () => {
    const primary = realisticTrend(411, 1);
    const settings = testSettings({ minScore: 35, minDirectionGap: 3, minConfidence: 25, minRr: 1.2 });
    const sig = generateSignal({
      symbol: 'BTCUSDT',
      primary,
      primaryTimeframe: '1h',
      mtfInputs: [
        { timeframe: '1h', candles: primary },
        { timeframe: '4h', candles: realisticTrend(412, 1) },
        { timeframe: '1d', candles: realisticTrend(413, 1) },
      ],
      settings,
      options: { balance: 10000, riskPercent: 1 },
    });
    assert.equal(sig.direction, 'LONG');
    assert.ok(sig.long_score >= settings.minScore);
    assert.ok(sig.direction_gap >= settings.minDirectionGap);
    assert.ok(sig.entry && sig.stop_loss && sig.take_profit && sig.position);
    assert.ok(sig.risk_reward && sig.risk_reward.tp1 >= settings.minRr);
    assert.ok(sig.confidence >= settings.minConfidence);
    assert.ok(sig.reasons.length > 0 && sig.invalidation.length > 0);
    assert.ok(Date.parse(sig.expires_at) > Date.parse(sig.created_at));
  });

  it('returns NO_TRADE when direction gap is too small (strict gap)', () => {
    const primary = genRange(300, 100, 0.01, 421);
    const settings = testSettings({ minScore: 5, minDirectionGap: 60, minConfidence: 5, minRr: 1.0 });
    const sig = generateSignal({
      symbol: 'ETHUSDT',
      primary,
      primaryTimeframe: '1h',
      mtfInputs: [{ timeframe: '1h', candles: primary }],
      settings,
    });
    assert.equal(sig.direction, 'NO_TRADE');
    assert.ok(sig.reasons.some((r) => /direction gap/i.test(r)));
  });

  it('returns NO_TRADE in extreme volatility with strict settings', () => {
    const primary = genCandles(300, 100, 0.001, 0.06, 431);
    const settings = testSettings({ minScore: 30, minDirectionGap: 3, minConfidence: 20, minRr: 1.0 });
    const sig = generateSignal({
      symbol: 'SOLUSDT',
      primary,
      primaryTimeframe: '1h',
      mtfInputs: [{ timeframe: '1h', candles: primary }],
      settings,
    });
    // Either blocked by contradictions/volatility or low score — but must explain why.
    assert.equal(sig.direction, 'NO_TRADE');
    assert.ok(sig.reasons.length > 0);
  });

  it('respects custom risk percent capped at max', () => {
    const mk = (seed: number) => genCandles(300, 100, 0.004, 0.0025, seed);
    const primary = mk(441);
    const settings = testSettings({ minScore: 35, minDirectionGap: 3, minConfidence: 25, minRr: 1.2, maxRiskPercent: 2 });
    const sig = generateSignal({
      symbol: 'BTCUSDT',
      primary,
      primaryTimeframe: '1h',
      mtfInputs: [{ timeframe: '1h', candles: primary }],
      settings,
      options: { balance: 20000, riskPercent: 9 },
    });
    if (sig.direction !== 'NO_TRADE' && sig.position) {
      assert.equal(sig.position.risk_percent, 2);
      assert.equal(sig.position.risk_amount, 400);
    }
  });
});
