import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { buildServer, type ServerDeps } from '../server.js';
import { SignalStore } from '../database.js';
import { MarketDataError, type BinanceClient } from '../exchange.js';
import type { SignalMonitor } from '../monitor.js';
import type { SymbolScanner } from '../scanner.js';
import { testSettings } from './helpers.js';

function failingExchange(): BinanceClient {
  const boom = async (): Promise<never> => {
    throw new MarketDataError('MARKET_DATA_UNAVAILABLE', 'stub offline');
  };
  return {
    getTicker: boom, getCandles: boom, getCandlesBatch: async () => new Map(),
    getSpotUsdtSymbols: boom, getAllTickers: boom, getKlinesPage: boom,
  } as unknown as BinanceClient;
}

function stubScanner(): SymbolScanner {
  const boom = async (): Promise<never> => {
    throw new MarketDataError('MARKET_DATA_UNAVAILABLE', 'stub offline');
  };
  return {
    getUniverse: boom, scan: boom,
    getCachedSignals: () => [], getSignalFor: () => undefined,
  } as unknown as SymbolScanner;
}

function stubMonitor(): SignalMonitor {
  return { start() {}, stop() {}, tick: async () => {} } as unknown as SignalMonitor;
}

describe('REST API', () => {
  let dir: string;
  let store: SignalStore;
  let deps: ServerDeps;

  before(() => {
    dir = mkdtempSync(join(tmpdir(), 'signalprime-test-'));
    store = new SignalStore(dir);
    deps = {
      settings: testSettings(),
      exchange: failingExchange(),
      scanner: stubScanner(),
      store,
      monitor: stubMonitor(),
    };
  });

  after(() => {
    store.close();
    rmSync(dir, { recursive: true, force: true });
  });

  it('GET /health returns ok', async () => {
    const app = await buildServer(deps);
    const res = await app.inject({ method: 'GET', url: '/health' });
    assert.equal(res.statusCode, 200);
    assert.equal(res.json().status, 'ok');
    await app.close();
  });

  it('GET /config exposes public thresholds only', async () => {
    const app = await buildServer(deps);
    const res = await app.inject({ method: 'GET', url: '/config' });
    assert.equal(res.statusCode, 200);
    const body = res.json();
    assert.equal(body.min_score, 40);
    assert.ok(!('apiKey' in body) && !('api_key' in body));
    await app.close();
  });

  it('maps exchange failures to error codes (market stays resilient)', async () => {
    const app = await buildServer(deps);
    for (const url of ['/symbols', '/ticker/BTCUSDT', '/candles/BTCUSDT', '/signal/BTCUSDT', '/scanner', '/regime/BTCUSDT']) {
      const res = await app.inject({ method: 'GET', url });
      assert.equal(res.statusCode, 502, url);
      assert.equal(res.json().error.code, 'MARKET_DATA_UNAVAILABLE', url);
    }
    // /market degrades gracefully with nulls instead of failing.
    const market = await app.inject({ method: 'GET', url: '/market' });
    assert.equal(market.statusCode, 200);
    assert.equal(market.json().btc, null);
    await app.close();
  });

  it('GET /signals/:id returns 404 for unknown ids', async () => {
    const app = await buildServer(deps);
    const res = await app.inject({ method: 'GET', url: '/signals/nope' });
    assert.equal(res.statusCode, 404);
    await app.close();
  });

  it('GET /history returns stored signals with filters', async () => {
    const app = await buildServer(deps);
    const res = await app.inject({ method: 'GET', url: '/history?limit=10' });
    assert.equal(res.statusCode, 200);
    assert.ok(Array.isArray(res.json().signals));
    const bad = await app.inject({ method: 'GET', url: '/history?direction=SIDEWAYS' });
    assert.equal(bad.statusCode, 400);
    await app.close();
  });

  it('POST /backtest validates input', async () => {
    const app = await buildServer(deps);
    const bad = await app.inject({ method: 'POST', url: '/backtest', payload: { symbol: 'BTCUSDT' } });
    assert.equal(bad.statusCode, 400);
    const ok = await app.inject({
      method: 'POST', url: '/backtest',
      payload: { symbol: 'BTCUSDT', timeframe: '1h', start: '2024-01-01', end: '2024-02-01', initial_balance: 1000, risk_percent: 1 },
    });
    assert.equal(ok.statusCode, 502); // exchange stub offline
    assert.equal(ok.json().error.code, 'MARKET_DATA_UNAVAILABLE');
    await app.close();
  });

  it('persists and retrieves signals through the store', async () => {
    const app = await buildServer(deps);
    const fake = {
      signal_id: 'TEST-1h-1', symbol: 'TESTUSDT', direction: 'LONG', status: 'WAITING',
      long_score: 90, short_score: 40, direction_gap: 50,
      long_breakdown: null, short_breakdown: null, confidence: 88, probability_estimate: 82,
      entry: { low: 99, high: 101, preferred: 100, type: 'PULLBACK' },
      stop_loss: { price: 97, distance_percent: 3, reason: 'swing' },
      take_profit: { tp1: 106, tp2: 108.4, tp3: 110.8 },
      risk_reward: { tp1: 2, tp2: 2.8, tp3: 3.6 },
      position: { risk_percent: 1, risk_amount: 100, quantity: 33.33, leverage: 4, account_balance: 10000 },
      market_regime: 'BULL', mtf: [], reasons: ['test'], warnings: [], invalidation: [],
      contradictions: [], created_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 3600000).toISOString(),
    };
    store.saveSignal(fake as never);
    const res = await app.inject({ method: 'GET', url: '/signals/TEST-1h-1' });
    assert.equal(res.statusCode, 200);
    assert.equal(res.json().symbol, 'TESTUSDT');
    const hist = await app.inject({ method: 'GET', url: '/history?direction=LONG' });
    assert.ok(hist.json().signals.some((s: { signal_id: string }) => s.signal_id === 'TEST-1h-1'));
    await app.close();
  });

  it('enforces API key auth when configured', async () => {
    const keyed = { ...deps, settings: { ...deps.settings, apiKey: 'secret123' } };
    const app = await buildServer(keyed);
    const open = await app.inject({ method: 'GET', url: '/health' });
    assert.equal(open.statusCode, 200);
    const denied = await app.inject({ method: 'GET', url: '/config' });
    assert.equal(denied.statusCode, 401);
    const allowed = await app.inject({ method: 'GET', url: '/config', headers: { 'x-api-key': 'secret123' } });
    assert.equal(allowed.statusCode, 200);
    await app.close();
  });

  it('applies rate limiting', async () => {
    const limited = { ...deps, settings: { ...deps.settings, rateLimitMax: 3, rateLimitWindowMs: 60000 } };
    const app = await buildServer(limited);
    let limited_count = 0;
    for (let i = 0; i < 6; i++) {
      const res = await app.inject({ method: 'GET', url: '/health' });
      if (res.statusCode === 429) limited_count++;
    }
    assert.ok(limited_count > 0, 'expected some 429 responses');
    await app.close();
  });
});
