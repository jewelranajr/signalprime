import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { analyzeStructure, detectSRZones, findSwings } from '../structure.js';
import { detectRegime } from '../regime.js';
import { analyzeMtf } from '../mtf.js';
import { genCandles, genRange } from './helpers.js';

describe('market structure', () => {
  it('detects an uptrend with HH/HL sequence', () => {
    const candles = genCandles(250, 100, 0.004, 0.008, 101);
    const s = analyzeStructure(candles);
    assert.ok(['UPTREND', 'BREAKOUT', 'REVERSAL_UP'].includes(s.state), `state=${s.state}`);
    assert.ok(s.trendScore > 0, `trendScore=${s.trendScore}`);
    assert.ok(s.sequence.includes('HH') || s.sequence.includes('HL'));
  });

  it('detects a downtrend with LH/LL sequence', () => {
    const candles = genCandles(250, 100, -0.004, 0.008, 103);
    const s = analyzeStructure(candles);
    assert.ok(['DOWNTREND', 'BREAKDOWN', 'REVERSAL_DOWN'].includes(s.state), `state=${s.state}`);
    assert.ok(s.trendScore < 0);
  });

  it('finds swing points and builds S/R zones', () => {
    const candles = genCandles(250, 100, 0, 0.01, 107);
    const swings = findSwings(candles, 3);
    assert.ok(swings.length > 4, `swings=${swings.length}`);
    const zones = detectSRZones(candles, 8);
    assert.ok(zones.length > 0);
    assert.ok(zones.every((z) => z.strength >= 0 && z.strength <= 100));
    const price = candles[candles.length - 1].close;
    assert.ok(zones.every((z) => (z.type === 'SUPPORT') === (z.price < price)));
  });

  it('handles insufficient data gracefully', () => {
    const s = analyzeStructure(genCandles(10, 100, 0, 0.01, 109));
    assert.equal(s.state, 'RANGE');
    assert.deepEqual(detectSRZones(genCandles(10), 8), []);
  });
});

describe('regime engine', () => {
  it('classifies a strong uptrend as bullish', () => {
    const candles = genCandles(300, 100, 0.005, 0.003, 113);
    const r = detectRegime(candles);
    assert.ok(['STRONG_BULL', 'BULL'].includes(r.regime), `regime=${r.regime}`);
    assert.ok(r.bias_score > 30);
  });

  it('classifies a strong downtrend as bearish', () => {
    const candles = genCandles(300, 100, -0.005, 0.003, 127);
    const r = detectRegime(candles);
    assert.ok(['STRONG_BEAR', 'BEAR'].includes(r.regime), `regime=${r.regime}`);
    assert.ok(r.bias_score < -30);
  });

  it('classifies sideways chop as choppy/range/neutral', () => {
    const candles = genRange(300, 100, 0.006, 131);
    const r = detectRegime(candles);
    assert.ok(
      ['CHOPPY', 'RANGE', 'NEUTRAL', 'ACCUMULATION', 'DISTRIBUTION', 'WEAK_BULL', 'WEAK_BEAR'].includes(r.regime),
      `regime=${r.regime}`,
    );
    assert.ok(Math.abs(r.bias_score) < 35, `bias=${r.bias_score}`);
  });

  it('flags extreme volatility', () => {
    const candles = genCandles(300, 100, 0, 0.06, 137);
    const r = detectRegime(candles);
    assert.ok(r.components.bb_width_rank > 80, `bwRank=${r.components.bb_width_rank}`);
  });
});

describe('multi-timeframe analysis', () => {
  it('aligns bullish across timeframes in an uptrend', () => {
    const mk = (seed: number) => genCandles(250, 100, 0.003, 0.004, seed);
    const report = analyzeMtf([
      { timeframe: '5m', candles: mk(201) },
      { timeframe: '15m', candles: mk(202) },
      { timeframe: '1h', candles: mk(203) },
      { timeframe: '4h', candles: mk(204) },
      { timeframe: '1d', candles: mk(205) },
    ]);
    assert.equal(report.dominant, 'BULLISH');
    assert.ok(report.alignmentScore >= 60, `alignment=${report.alignmentScore}`);
    assert.equal(report.slices.length, 5);
  });

  it('flags HTF/LTF disagreement explicitly', () => {
    const report = analyzeMtf([
      { timeframe: '5m', candles: genCandles(250, 100, 0.004, 0.003, 211) },
      { timeframe: '15m', candles: genCandles(250, 100, 0.004, 0.003, 212) },
      { timeframe: '4h', candles: genCandles(250, 100, -0.004, 0.003, 213) },
      { timeframe: '1d', candles: genCandles(250, 100, -0.004, 0.003, 214) },
    ]);
    assert.ok(
      report.notes.some((n) => /HTF\/LTF disagreement/i.test(n)),
      JSON.stringify(report.notes),
    );
  });
});
