import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { runBacktest } from '../backtest.js';
import type { BinanceClient } from '../exchange.js';
import type { Candle } from '../types.js';
import { genCandles, testSettings } from './helpers.js';

/** Stub exchange serving deterministic synthetic history (no network). */
function stubExchange(candles: Candle[]): BinanceClient {
  return {
    getKlinesPage: async (_sym: string, _iv: string, startTime: number, limit: number) => {
      const page = candles.filter((c) => c.openTime >= startTime).slice(0, limit);
      return page;
    },
  } as unknown as BinanceClient;
}

describe('backtester', () => {
  it('runs walk-forward without look-ahead and returns sane stats', async () => {
    const candles = genCandles(900, 100, 0.0015, 0.006, 501).slice(-500);
    const exchange = stubExchange(candles);
    const settings = testSettings({ minScore: 30, minDirectionGap: 3, minConfidence: 20, minRr: 1.2 });
    const res = await runBacktest(
      {
        symbol: 'TESTUSDT',
        timeframe: '1h',
        start: new Date(candles[0].openTime).toISOString(),
        end: new Date(candles[candles.length - 1].openTime).toISOString(),
        initial_balance: 10000,
        risk_percent: 1,
      },
      exchange,
      settings,
    );
    assert.equal(res.symbol, 'TESTUSDT');
    assert.ok(res.total_trades >= 0);
    assert.equal(res.wins + res.losses <= res.total_trades, true);
    assert.ok(res.max_drawdown_pct >= 0 && res.max_drawdown_pct <= 100);
    assert.ok(res.profit_factor >= 0);
    // Every trade's exit must come from bars AFTER its entry bar (no look-ahead
    // is structural: simulation only walks forward from i+2).
    for (const t of res.trades) {
      assert.ok(['TP1', 'TP2', 'TP3', 'SL', 'EXPIRED'].includes(t.exit_reason));
      assert.ok(Number.isFinite(t.pnl));
    }
  });

  it('rejects invalid ranges and timeframes', async () => {
    const exchange = stubExchange([]);
    const settings = testSettings();
    await assert.rejects(
      () => runBacktest({ symbol: 'X', timeframe: '99x', start: '2024-01-01', end: '2024-02-01', initial_balance: 1000, risk_percent: 1 }, exchange, settings),
      /Unsupported timeframe/,
    );
    await assert.rejects(
      () => runBacktest({ symbol: 'X', timeframe: '1h', start: '2024-02-01', end: '2024-01-01', initial_balance: 1000, risk_percent: 1 }, exchange, settings),
      /Invalid start\/end/,
    );
  });

  it('handles symbols with no data', async () => {
    const exchange = stubExchange([]);
    const settings = testSettings();
    await assert.rejects(
      () => runBacktest({ symbol: 'NODATA', timeframe: '1h', start: '2024-01-01', end: '2024-06-01', initial_balance: 1000, risk_percent: 1 }, exchange, settings),
      /Only 0 candles/,
    );
  });
});
