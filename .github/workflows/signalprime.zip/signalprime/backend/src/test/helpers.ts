/** Deterministic synthetic market data for tests. */
import type { Candle, Settings } from '../types.js';
import { loadSettings } from '../config.js';

/** Mulberry32 PRNG — deterministic across runs. */
export function prng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Random-walk candles.
 * @param drift per-candle drift (e.g. 0.002 = +0.2% uptrend)
 * @param vol per-candle noise amplitude
 */
export function genCandles(
  n: number,
  start = 100,
  drift = 0,
  vol = 0.004,
  seed = 42,
  intervalMs = 3_600_000,
): Candle[] {
  const rand = prng(seed);
  const out: Candle[] = [];
  let price = start;
  let t = Date.now() - n * intervalMs;
  for (let i = 0; i < n; i++) {
    const o = price;
    const change = drift + (rand() - 0.5) * 2 * vol;
    const c = Math.max(o * (1 + change), 0.0001);
    const h = Math.max(o, c) * (1 + rand() * vol * 0.5);
    const l = Math.min(o, c) * (1 - rand() * vol * 0.5);
    const v = 100 + rand() * 900;
    out.push({ openTime: t, open: o, high: h, low: l, close: c, volume: v, closeTime: t + intervalMs - 1 });
    price = c;
    t += intervalMs;
  }
  return out;
}

/** Sideways oscillating series (mean-reverting chop) for regime tests. */
export function genRange(
  n: number,
  start = 100,
  amplitudePct = 0.01,
  seed = 5,
  intervalMs = 3_600_000,
): Candle[] {
  const rand = prng(seed);
  const out: Candle[] = [];
  let t = Date.now() - n * intervalMs;
  for (let i = 0; i < n; i++) {
    const base = start * (1 + amplitudePct * Math.sin(i / 4.5));
    const o = base * (1 + (rand() - 0.5) * 0.002);
    const c = base * (1 + (rand() - 0.5) * 0.002);
    const h = Math.max(o, c) * 1.001;
    const l = Math.min(o, c) * 0.999;
    out.push({ openTime: t, open: o, high: h, low: l, close: c, volume: 100 + rand() * 200, closeTime: t + intervalMs - 1 });
    t += intervalMs;
  }
  return out;
}

export function testSettings(overrides: Partial<Settings> = {}): Settings {
  return {
    ...loadSettings(),
    minScore: 40,
    minDirectionGap: 5,
    minConfidence: 30,
    minDataCandles: 60,
    ...overrides,
  };
}

export function approx(a: number, b: number, tol = 1e-6): boolean {
  return Math.abs(a - b) <= tol;
}
