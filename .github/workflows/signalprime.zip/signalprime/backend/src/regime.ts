/**
 * Market regime engine.
 *
 * Classifies the current market state into one of the 12 regimes.
 * Never invents data: every component is derived from real candles.
 */
import type { Candle, MarketRegime } from './types.js';
import {
  adx, atr, atrPercent, bollinger, closes, ema, lastFinite, obv,
  percentileRank, rsi, vwap,
} from './indicators.js';
import { analyzeStructure } from './structure.js';

export interface RegimeAnalysis {
  regime: MarketRegime;
  bias_score: number; // -100 .. +100
  components: Record<string, number>;
  notes: string[];
}

export function detectRegime(candles: Candle[]): RegimeAnalysis {
  const notes: string[] = [];
  const n = candles.length;
  const neutral: RegimeAnalysis = {
    regime: 'NEUTRAL', bias_score: 0, components: {}, notes: ['insufficient data for regime detection'],
  };
  if (n < 60) return neutral;

  const cl = closes(candles);
  const price = cl[n - 1];
  const ema20 = lastFinite(ema(cl, 20));
  const ema50 = lastFinite(ema(cl, 50));
  const ema200 = n >= 200 ? lastFinite(ema(cl, 200)) : NaN;
  const rsi14 = lastFinite(rsi(cl, 14));
  const adxR = adx(candles, 14);
  const adxV = lastFinite(adxR.adx);
  const plusDI = lastFinite(adxR.plusDI);
  const minusDI = lastFinite(adxR.minusDI);
  const vwapV = lastFinite(vwap(candles));
  const bb = bollinger(cl, 20, 2);
  const bwRank = percentileRank(bb.bandwidth, 120);
  const atrP = atrPercent(atr(candles, 14), cl);
  const atrRank = percentileRank(atrP, 120);
  const struct = analyzeStructure(candles);
  const obvArr = obv(candles);
  const obvSlope = obvSlopePct(obvArr, 20);

  // --- component scores (-100..100) ---
  // EMA alignment
  let emaScore = 0;
  if (Number.isFinite(ema20) && Number.isFinite(ema50)) {
    if (ema20 > ema50 && price > ema20) emaScore = 70;
    else if (ema20 < ema50 && price < ema20) emaScore = -70;
    else if (price > ema50) emaScore = 25;
    else if (price < ema50) emaScore = -25;
    if (Number.isFinite(ema200)) {
      if (price > ema200 && ema50 > ema200) emaScore += 30;
      else if (price < ema200 && ema50 < ema200) emaScore -= 30;
    }
  }
  // ADX trend strength with direction
  let adxScore = 0;
  if (Number.isFinite(adxV)) {
    const dir = plusDI > minusDI ? 1 : -1;
    const strength = Math.min(100, (adxV / 40) * 100);
    adxScore = dir * strength;
  }
  // VWAP position
  const vwapScore = Number.isFinite(vwapV) && price > 0
    ? Math.max(-100, Math.min(100, ((price - vwapV) / price) * 100 * 40))
    : 0;
  const structScore = struct.trendScore;

  const bias = clamp(
    emaScore * 0.3 + adxScore * 0.25 + vwapScore * 0.15 + structScore * 0.3,
    -100, 100,
  );

  const components: Record<string, number> = {
    ema_alignment: round(emaScore),
    adx_trend: round(adxScore),
    vwap_position: round(vwapScore),
    market_structure: round(structScore),
    adx_value: round(adxV),
    rsi_14: round(rsi14),
    bb_width_rank: round(bwRank),
    atr_rank: round(atrRank),
    obv_slope_pct: round(obvSlope),
  };

  const extremeVol = bwRank > 92 || atrRank > 95;
  const highVol = bwRank > 78 || atrRank > 80;
  const contractingVol = bwRank < 25;

  let regime: MarketRegime;
  if (extremeVol) {
    regime = 'HIGH_VOLATILITY';
    notes.push('Extreme volatility — position sizing must be reduced');
  } else if (Number.isFinite(adxV) && adxV < 15 && Math.abs(bias) < 25) {
    regime = 'CHOPPY';
    notes.push('No tradable trend — chop likely');
  } else if (Number.isFinite(adxV) && adxV < 20 && Math.abs(bias) < 20) {
    // Accumulation vs distribution vs plain range
    const nearLows = struct.state === 'CONSOLIDATION' || struct.state === 'RANGE';
    if (nearLows && obvSlope > 1 && contractingVol && bias > -10) {
      regime = 'ACCUMULATION';
      notes.push('Range contraction with rising OBV — possible accumulation');
    } else if (nearLows && obvSlope < -1 && contractingVol && bias < 10) {
      regime = 'DISTRIBUTION';
      notes.push('Range with falling OBV near highs — possible distribution');
    } else {
      regime = 'RANGE';
      notes.push('Range-bound market');
    }
  } else if (bias >= 60) { regime = 'STRONG_BULL'; notes.push('Strong bullish regime'); }
  else if (bias >= 30) { regime = 'BULL'; notes.push('Bullish regime'); }
  else if (bias >= 12) { regime = 'WEAK_BULL'; notes.push('Weak bullish regime'); }
  else if (bias <= -60) { regime = 'STRONG_BEAR'; notes.push('Strong bearish regime'); }
  else if (bias <= -30) { regime = 'BEAR'; notes.push('Bearish regime'); }
  else if (bias <= -12) { regime = 'WEAK_BEAR'; notes.push('Weak bearish regime'); }
  else { regime = 'NEUTRAL'; notes.push('Neutral — no edge'); }

  if (highVol && !extremeVol) notes.push('Volatility elevated — reduce leverage');
  if (Number.isFinite(rsi14)) {
    if (rsi14 > 70) notes.push('RSI overbought — chasing longs is risky');
    if (rsi14 < 30) notes.push('RSI oversold — chasing shorts is risky');
  }
  if (struct.bos) notes.push(`Structure: ${struct.notes.find((x) => x.startsWith('BOS')) ?? 'BOS'}`);
  if (struct.choch) notes.push(`Structure: ${struct.notes.find((x) => x.startsWith('CHoCH')) ?? 'CHoCH'}`);

  return { regime, bias_score: round(bias), components, notes };
}

function obvSlopePct(obvArr: number[], lookback: number): number {
  const f = obvArr.filter(Number.isFinite);
  if (f.length < lookback + 1) return 0;
  const a = f[f.length - 1 - lookback];
  const b = f[f.length - 1];
  const base = Math.abs(a) > 1e-12 ? Math.abs(a) : 1;
  return ((b - a) / base) * 100;
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}
function round(v: number): number {
  return Number.isFinite(v) ? Math.round(v * 100) / 100 : 0;
}
