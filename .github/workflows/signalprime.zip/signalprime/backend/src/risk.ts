/**
 * Risk engine: entry zones, dynamic stop-loss, take-profits,
 * risk/reward validation, and position sizing.
 *
 * Rules:
 * - SL is structural (swing invalidation) or ATR-based, never arbitrary.
 * - Minimum RR enforced by the caller (master signal engine).
 * - Position size derives from SL distance; confidence never inflates size.
 * - Leverage is capped by volatility regime.
 */
import type { EntryZone, PositionPlan, RiskReward, StopLoss, TakeProfit } from './types.js';
import type { IndicatorSnapshot } from './analysis.js';
import type { SRZone, StructureReport } from './structure.js';

export type VolatilityLevel = 'LOW' | 'NORMAL' | 'HIGH' | 'EXTREME';

export function assessVolatility(snap: IndicatorSnapshot): VolatilityLevel {
  const rank = snap.bbWidthRank;
  if (rank > 92) return 'EXTREME';
  if (rank > 78) return 'HIGH';
  if (rank < 20) return 'LOW';
  return 'NORMAL';
}

export interface RiskPlan {
  entry: EntryZone | null;
  stopLoss: StopLoss | null;
  takeProfit: TakeProfit | null;
  riskReward: RiskReward | null;
  position: PositionPlan | null;
  warnings: string[];
  waitForPullback: boolean;
}

export interface RiskContext {
  snap: IndicatorSnapshot;
  structure: StructureReport;
  zones: SRZone[];
}

const TP_MULTIPLES = [2.0, 2.8, 3.6];

export function planTrade(
  ctx: RiskContext,
  direction: 'LONG' | 'SHORT',
  balance: number,
  riskPercent: number,
): RiskPlan {
  const warnings: string[] = [];
  const { snap, structure, zones } = ctx;
  const price = snap.price;
  const atrV = snap.atr;
  if (!Number.isFinite(atrV) || atrV <= 0 || !(price > 0)) {
    return { entry: null, stopLoss: null, takeProfit: null, riskReward: null, position: null, warnings: ['Invalid ATR/price — cannot plan trade'], waitForPullback: false };
  }
  const long = direction === 'LONG';

  // ---------- ENTRY ----------
  let preferred: number;
  let entryType: EntryZone['type'] = 'PULLBACK';

  // Breakout-retest: BOS in our direction and price holding near the broken level.
  const brokenLevel = long
    ? structure.swingHighs[structure.swingHighs.length - 1]?.price
    : structure.swingLows[structure.swingLows.length - 1]?.price;
  const bosOurs = structure.bos && structure.bosDirection === (long ? 'UP' : 'DOWN');
  if (bosOurs && Number.isFinite(brokenLevel) && Math.abs(price - (brokenLevel as number)) < atrV * 0.6) {
    preferred = brokenLevel as number;
    entryType = 'BREAKOUT_RETEST';
  } else {
    // Pullback reference: nearest support/resistance zone on our side within 3 ATR,
    // else EMA20, else VWAP, else 0.5 ATR from price.
    const refZone = nearestZoneOnSide(zones, long ? 'SUPPORT' : 'RESISTANCE', price, atrV, 3);
    if (refZone) preferred = refZone.price;
    else if (Number.isFinite(snap.ema20) && (long ? snap.ema20 < price : snap.ema20 > price)) preferred = snap.ema20;
    else if (Number.isFinite(snap.vwap) && (long ? snap.vwap < price : snap.vwap > price)) preferred = snap.vwap;
    else preferred = long ? price - atrV * 0.5 : price + atrV * 0.5;
  }

  const extension = long ? (price - preferred) / atrV : (preferred - price) / atrV;
  if (extension > 1.5) {
    return {
      entry: null, stopLoss: null, takeProfit: null, riskReward: null, position: null,
      warnings: [`Price extended ${extension.toFixed(1)} ATR from ideal entry — wait for pullback`],
      waitForPullback: true,
    };
  }
  if (Math.abs(price - preferred) <= atrV * 0.3) {
    preferred = price;
    entryType = 'MARKET';
  }
  const entry: EntryZone = {
    low: round8(long ? preferred - atrV * 0.25 : preferred - atrV * 0.25),
    high: round8(preferred + atrV * 0.25),
    preferred: round8(preferred),
    type: entryType,
  };

  // ---------- STOP LOSS ----------
  const swings = long ? structure.swingLows : structure.swingHighs;
  // Most recent swing on our side beyond the entry (invalidation level).
  let invalidation: number | null = null;
  for (let i = swings.length - 1; i >= 0; i--) {
    const p = swings[i].price;
    if (long ? p < entry.preferred : p > entry.preferred) { invalidation = p; break; }
  }
  let slPrice: number;
  let slReason: string;
  const buffer = atrV * 0.25;
  if (invalidation !== null && Math.abs(entry.preferred - invalidation) <= atrV * 4) {
    slPrice = long ? invalidation - buffer : invalidation + buffer;
    slReason = `Below invalidation swing low ${fmt(invalidation)}` ;
    if (!long) slReason = `Above invalidation swing high ${fmt(invalidation)}`;
  } else {
    slPrice = long ? entry.preferred - atrV * 2.5 : entry.preferred + atrV * 2.5;
    slReason = 'ATR-based invalidation (no clean swing level within 4 ATR)';
  }
  const riskDist = Math.abs(entry.preferred - slPrice);
  if (riskDist <= 0) {
    return { entry: null, stopLoss: null, takeProfit: null, riskReward: null, position: null, warnings: ['Invalid stop distance'], waitForPullback: false };
  }
  const distancePct = (riskDist / entry.preferred) * 100;
  const stopLoss: StopLoss = { price: round8(slPrice), distance_percent: round2(distancePct), reason: slReason };
  if (distancePct > 4) warnings.push(`Wide stop (${distancePct.toFixed(2)}%) — consider smaller size or skip`);

  // ---------- TAKE PROFITS (pure RR multiples, never below min RR) ----------
  const tp: TakeProfit = {
    tp1: round8(long ? entry.preferred + TP_MULTIPLES[0] * riskDist : entry.preferred - TP_MULTIPLES[0] * riskDist),
    tp2: round8(long ? entry.preferred + TP_MULTIPLES[1] * riskDist : entry.preferred - TP_MULTIPLES[1] * riskDist),
    tp3: round8(long ? entry.preferred + TP_MULTIPLES[2] * riskDist : entry.preferred - TP_MULTIPLES[2] * riskDist),
  };
  const riskReward: RiskReward = { tp1: TP_MULTIPLES[0], tp2: TP_MULTIPLES[1], tp3: TP_MULTIPLES[2] };

  // Warn if opposing S/R sits between entry and TP1.
  const blocker = nearestZoneOnSide(zones, long ? 'RESISTANCE' : 'SUPPORT', price, atrV, 10);
  if (blocker) {
    const between = long ? blocker.price > entry.preferred && blocker.price < tp.tp1
      : blocker.price < entry.preferred && blocker.price > tp.tp1;
    if (between) warnings.push(`${long ? 'Resistance' : 'Support'} ${fmt(blocker.price)} sits between entry and TP1`);
  }

  // ---------- POSITION ----------
  const safeBalance = balance > 0 ? balance : 10000;
  const rp = Math.min(Math.max(riskPercent, 0.1), 10);
  const riskAmount = (safeBalance * rp) / 100;
  const quantity = riskAmount / riskDist;
  const notional = quantity * entry.preferred;
  const vol = assessVolatility(snap);
  const maxLev = vol === 'EXTREME' ? 3 : vol === 'HIGH' ? 5 : 10;
  const leverage = Math.min(Math.max(Math.ceil(notional / safeBalance), 1), maxLev);
  if (leverage >= 8) warnings.push(`High leverage (${leverage}x) — liquidation risk elevated`);
  if (vol === 'EXTREME') warnings.push('Extreme volatility — leverage capped at 3x');
  const position: PositionPlan = {
    risk_percent: round2(rp),
    risk_amount: round2(riskAmount),
    quantity: round8(quantity),
    leverage,
    account_balance: round2(safeBalance),
  };

  return { entry, stopLoss, takeProfit: tp, riskReward, position, warnings, waitForPullback: false };
}

function nearestZoneOnSide(
  zones: SRZone[],
  type: 'SUPPORT' | 'RESISTANCE',
  price: number,
  atrV: number,
  maxAtr: number,
): SRZone | null {
  let best: SRZone | null = null;
  for (const z of zones) {
    if (z.type !== type) continue;
    const distAtr = Math.abs(z.price - price) / atrV;
    if (distAtr > maxAtr) continue;
    const onSide = type === 'SUPPORT' ? z.price < price : z.price > price;
    if (!onSide) continue;
    if (!best || distAtr < Math.abs(best.price - price) / atrV) best = z;
  }
  return best;
}

function round8(v: number): number {
  return Math.round(v * 1e8) / 1e8;
}
function round2(v: number): number {
  return Math.round(v * 100) / 100;
}
function fmt(v: number): string {
  return v >= 1000 ? v.toFixed(1) : v >= 10 ? v.toFixed(2) : v.toFixed(4);
}
