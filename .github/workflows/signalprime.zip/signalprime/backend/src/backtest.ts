/**
 * Walk-forward backtesting module.
 *
 * For each historical bar (after warmup), the engine sees ONLY candles up to
 * that bar — future candles are never used for signal generation
 * (no look-ahead bias). Positions are simulated bar-by-bar with
 * conservative intrabar ordering (SL checked before TP).
 *
 * Results are estimates from historical simulation, not guarantees.
 */
import type {
  BacktestRequest, BacktestResult, BacktestTrade, Candle, Settings,
} from './types.js';
import { BinanceClient, INTERVAL_MS, MarketDataError } from './exchange.js';
import { generateSignal } from './signals.js';

const MAX_BARS_IN_TRADE = 200;
const MAX_RANGE_MS = 2 * 365 * 24 * 3_600_000; // 2 years

export async function runBacktest(
  req: BacktestRequest,
  exchange: BinanceClient,
  settings: Settings,
): Promise<BacktestResult> {
  const symbol = req.symbol.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  const timeframe = req.timeframe;
  if (!(timeframe in INTERVAL_MS)) {
    throw new MarketDataError('INVALID_REQUEST', `Unsupported timeframe: ${req.timeframe}`);
  }
  const start = Date.parse(req.start);
  const end = Date.parse(req.end);
  if (!Number.isFinite(start) || !Number.isFinite(end) || start >= end) {
    throw new MarketDataError('INVALID_REQUEST', 'Invalid start/end range');
  }
  if (end - start > MAX_RANGE_MS) {
    throw new MarketDataError('INVALID_REQUEST', 'Backtest range limited to 2 years');
  }
  const initialBalance = req.initial_balance > 0 ? req.initial_balance : settings.defaultBalance;
  const riskPercent = Math.min(Math.max(req.risk_percent > 0 ? req.risk_percent : settings.defaultRiskPercent, 0.1), settings.maxRiskPercent);

  const candles = await fetchRange(exchange, symbol, timeframe, start, end);
  const minNeeded = settings.minDataCandles + 50;
  if (candles.length < minNeeded) {
    throw new MarketDataError('INSUFFICIENT_DATA', `Only ${candles.length} candles available, need ${minNeeded}`);
  }

  const trades: BacktestTrade[] = [];
  const equityCurve: number[] = [initialBalance];
  let equity = initialBalance;
  let i = settings.minDataCandles;

  while (i < candles.length - 2) {
    // No look-ahead: engine sees candles[0..i] only.
    const slice = candles.slice(0, i + 1);
    let signal;
    try {
      signal = generateSignal({
        symbol,
        primary: slice,
        primaryTimeframe: timeframe,
        mtfInputs: [{ timeframe, candles: slice }],
        settings,
        options: { balance: equity, riskPercent },
      });
    } catch {
      i++;
      continue;
    }
    if (signal.direction === 'NO_TRADE' || !signal.entry || !signal.stop_loss) {
      i++;
      continue;
    }
    const long = signal.direction === 'LONG';
    const entry = candles[i + 1].open; // enter at next open
    const slDist = Math.abs(signal.entry.preferred - signal.stop_loss.price);
    if (!(slDist > 0) || !(entry > 0)) {
      i++;
      continue;
    }
    const sl = long ? entry - slDist : entry + slDist;
    const tps = [2.0, 2.8, 3.6].map((m) => (long ? entry + m * slDist : entry - m * slDist));
    const riskAmount = (equity * riskPercent) / 100;
    const riskPctDist = (slDist / entry) * 100;

    let exit = entry;
    let reason: BacktestTrade['exit_reason'] = 'EXPIRED';
    let j = i + 2;
    const maxJ = Math.min(i + MAX_BARS_IN_TRADE, candles.length - 1);
    for (; j <= maxJ; j++) {
      const c = candles[j];
      if (long) {
        if (c.low <= sl) { exit = sl; reason = 'SL'; break; }
        if (c.high >= tps[2]) { exit = tps[2]; reason = 'TP3'; break; }
        if (c.high >= tps[1]) { exit = tps[1]; reason = 'TP2'; break; }
        if (c.high >= tps[0]) { exit = tps[0]; reason = 'TP1'; break; }
      } else {
        if (c.high >= sl) { exit = sl; reason = 'SL'; break; }
        if (c.low <= tps[2]) { exit = tps[2]; reason = 'TP3'; break; }
        if (c.low <= tps[1]) { exit = tps[1]; reason = 'TP2'; break; }
        if (c.low <= tps[0]) { exit = tps[0]; reason = 'TP1'; break; }
      }
    }
    const pnlPct = long ? ((exit - entry) / entry) * 100 : ((entry - exit) / entry) * 100;
    const rMultiple = riskPctDist > 0 ? pnlPct / riskPctDist : 0;
    const tradePnl = riskAmount * rMultiple;
    equity += tradePnl;
    equity = Math.max(equity, 0.01);
    equityCurve.push(equity);
    trades.push({
      opened_at: new Date(candles[i + 1].openTime).toISOString(),
      direction: signal.direction,
      entry: round8(entry),
      stop_loss: round8(sl),
      tp1: round8(tps[0]),
      tp2: round8(tps[1]),
      tp3: round8(tps[2]),
      exit: round8(exit),
      exit_reason: reason,
      pnl: round2(tradePnl),
      pnl_pct: round2(pnlPct),
      rr: round2(rMultiple),
    });
    i = j + 1; // no overlapping positions
  }

  const wins = trades.filter((t) => t.pnl > 0);
  const losses = trades.filter((t) => t.pnl < 0);
  const grossWin = wins.reduce((s, t) => s + t.pnl, 0);
  const grossLoss = Math.abs(losses.reduce((s, t) => s + t.pnl, 0));
  let peak = equityCurve[0];
  let maxDd = 0;
  for (const e of equityCurve) {
    if (e > peak) peak = e;
    const dd = peak > 0 ? ((peak - e) / peak) * 100 : 0;
    if (dd > maxDd) maxDd = dd;
  }

  return {
    symbol,
    timeframe,
    total_trades: trades.length,
    wins: wins.length,
    losses: losses.length,
    win_rate: trades.length > 0 ? round2((wins.length / trades.length) * 100) : 0,
    net_pnl: round2(equity - initialBalance),
    net_pnl_pct: round2(((equity - initialBalance) / initialBalance) * 100),
    max_drawdown_pct: round2(maxDd),
    profit_factor: grossLoss > 0 ? round2(grossWin / grossLoss) : wins.length > 0 ? 99 : 0,
    avg_rr: trades.length > 0 ? round2(trades.reduce((s, t) => s + t.rr, 0) / trades.length) : 0,
    avg_win_pct: wins.length > 0 ? round2(wins.reduce((s, t) => s + t.pnl_pct, 0) / wins.length) : 0,
    avg_loss_pct: losses.length > 0 ? round2(losses.reduce((s, t) => s + t.pnl_pct, 0) / losses.length) : 0,
    trades,
  };
}

/** Paginated kline fetch across an arbitrary time range. */
async function fetchRange(
  exchange: BinanceClient,
  symbol: string,
  interval: string,
  start: number,
  end: number,
): Promise<Candle[]> {
  const out: Candle[] = [];
  const ivMs = INTERVAL_MS[interval];
  let cursor = start;
  let guard = 0;
  while (cursor < end && guard < 500) {
    guard++;
    let page: Candle[];
    try {
      page = await exchange.getKlinesPage(symbol, interval, cursor, 1000);
    } catch (err) {
      if (out.length > 0) break;
      throw err;
    }
    if (page.length === 0) break;
    for (const c of page) {
      if (c.openTime >= start && c.openTime < end) out.push(c);
    }
    const lastOpen = page[page.length - 1].openTime;
    if (lastOpen <= cursor) break;
    cursor = lastOpen + ivMs;
    if (page.length < 1000) break;
  }
  out.sort((a, b) => a.openTime - b.openTime);
  return out.filter((c, idx, arr) => idx === 0 || c.openTime !== arr[idx - 1].openTime);
}

function round2(v: number): number {
  return Math.round(v * 100) / 100;
}
function round8(v: number): number {
  return Math.round(v * 1e8) / 1e8;
}
