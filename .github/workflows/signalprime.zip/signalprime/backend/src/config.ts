import type { Settings } from './types.js';

function num(name: string, fallback: number): number {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return fallback;
  const v = Number(raw);
  return Number.isFinite(v) ? v : fallback;
}

function str(name: string, fallback: string): string {
  const raw = process.env[name];
  return raw === undefined || raw === '' ? fallback : raw;
}

export function loadSettings(): Settings {
  return {
    port: num('PORT', 3000),
    host: str('HOST', '0.0.0.0'),
    binanceHosts: str(
      'BINANCE_HOSTS',
      'https://api.binance.com,https://api1.binance.com,https://api2.binance.com,https://api3.binance.com,https://api4.binance.com,https://data-api.binance.vision',
    )
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean),
    binanceTimeoutMs: num('BINANCE_TIMEOUT_MS', 15000),
    minScore: num('MIN_SCORE', 85),
    extremeScore: num('EXTREME_SCORE', 92),
    minDirectionGap: num('MIN_DIRECTION_GAP', 10),
    minRr: num('MIN_RR', 2),
    minConfidence: num('MIN_CONFIDENCE', 75),
    minDataCandles: num('MIN_DATA_CANDLES', 220),
    defaultBalance: num('DEFAULT_BALANCE', 10000),
    defaultRiskPercent: num('DEFAULT_RISK_PERCENT', 1),
    maxRiskPercent: num('MAX_RISK_PERCENT', 2),
    scannerTopSymbols: num('SCANNER_TOP_SYMBOLS', 100),
    scannerMaxSymbols: num('SCANNER_MAX_SYMBOLS', 500),
    scannerCacheTtlMs: num('SCANNER_CACHE_TTL_MS', 120000),
    corsOrigins: str('CORS_ORIGINS', '*'),
    rateLimitMax: num('RATE_LIMIT_MAX', 300),
    rateLimitWindowMs: num('RATE_LIMIT_WINDOW_MS', 60000),
    apiKey: str('API_KEY', ''),
    logLevel: str('LOG_LEVEL', 'info'),
    dataDir: str('DATA_DIR', './data'),
  };
}

export function publicConfig(s: Settings) {
  return {
    min_score: s.minScore,
    extreme_score: s.extremeScore,
    min_direction_gap: s.minDirectionGap,
    min_rr: s.minRr,
    min_confidence: s.minConfidence,
    min_data_candles: s.minDataCandles,
    default_balance: s.defaultBalance,
    default_risk_percent: s.defaultRiskPercent,
    max_risk_percent: s.maxRiskPercent,
  };
}
