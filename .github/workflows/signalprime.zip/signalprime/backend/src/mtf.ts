/**
 * Multi-timeframe analysis.
 *
 * Scores each timeframe's directional bias (-100..100) from EMA alignment,
 * MACD, RSI, and market structure, then aggregates with higher-timeframe
 * weighting. Strong disagreement between timeframes reduces confidence
 * and can force NO_TRADE.
 */
import type { Candle, MtfSlice, TimeframeBias } from './types.js';
import { closes, ema, lastFinite, macd, rsi } from './indicators.js';
import { analyzeStructure } from './structure.js';

export interface MtfInput {
  timeframe: string;
  candles: Candle[];
}

export interface MtfReport {
  slices: MtfSlice[];
  /** 0-100: how strongly timeframes agree with the dominant direction */
  alignmentScore: number;
  dominant: TimeframeBias;
  bullishWeight: number;
  bearishWeight: number;
  notes: string[];
}

/** Higher timeframes dominate. Weights should sum to ~1 for the standard set. */
const TF_WEIGHTS: Record<string, number> = {
  '1d': 0.3,
  '4h': 0.25,
  '1h': 0.2,
  '15m': 0.15,
  '5m': 0.1,
  '30m': 0.12,
  '3m': 0.06,
  '1m': 0.05,
};

function weightFor(tf: string, count: number): number {
  return TF_WEIGHTS[tf] ?? 1 / Math.max(count, 1);
}

export function analyzeTimeframeSlice(timeframe: string, candles: Candle[]): MtfSlice {
  const n = candles.length;
  const notes: string[] = [];
  if (n < 60) {
    return { timeframe, bias: 'NEUTRAL', score: 0, trend: 'UNKNOWN', notes: ['insufficient candles'] };
  }
  const cl = closes(candles);
  const price = cl[n - 1];
  const ema20 = lastFinite(ema(cl, 20));
  const ema50 = lastFinite(ema(cl, 50));
  const ema200 = n >= 200 ? lastFinite(ema(cl, 200)) : NaN;
  const m = macd(cl);
  const hist = lastFinite(m.histogram);
  const macdLine = lastFinite(m.macdLine);
  const sigLine = lastFinite(m.signalLine);
  const rsiV = lastFinite(rsi(cl, 14));
  const struct = analyzeStructure(candles);

  let score = 0;
  // EMA alignment (35)
  if (Number.isFinite(ema20) && Number.isFinite(ema50)) {
    if (ema20 > ema50 && price > ema20) { score += 35; notes.push('EMA20>EMA50, price above'); }
    else if (ema20 < ema50 && price < ema20) { score -= 35; notes.push('EMA20<EMA50, price below'); }
    else if (price > ema50) { score += 12; }
    else { score -= 12; }
    if (Number.isFinite(ema200)) {
      if (price > ema200) score += 8; else score -= 8;
    }
  }
  // MACD (20)
  if (Number.isFinite(hist) && Number.isFinite(macdLine) && Number.isFinite(sigLine)) {
    if (macdLine > sigLine && hist > 0) { score += 20; notes.push('MACD bullish'); }
    else if (macdLine < sigLine && hist < 0) { score -= 20; notes.push('MACD bearish'); }
    else if (hist > 0) score += 6; else score -= 6;
  }
  // RSI (15)
  if (Number.isFinite(rsiV)) {
    if (rsiV > 55 && rsiV < 75) { score += 15; notes.push('RSI momentum healthy'); }
    else if (rsiV < 45 && rsiV > 25) { score -= 15; notes.push('RSI momentum weak'); }
    else if (rsiV >= 75) { score += 5; notes.push('RSI overbought — momentum extended'); }
    else if (rsiV <= 25) { score -= 5; notes.push('RSI oversold — momentum extended'); }
  }
  // Market structure (30)
  score += (struct.trendScore / 100) * 30;
  if (struct.bos) notes.push(`BOS ${struct.bosDirection}`);
  if (struct.choch) notes.push(`CHoCH ${struct.chochDirection}`);

  score = Math.max(-100, Math.min(100, Math.round(score)));
  const bias: TimeframeBias = score > 15 ? 'BULLISH' : score < -15 ? 'BEARISH' : 'NEUTRAL';
  const trend = struct.state;
  return { timeframe, bias, score, trend, notes };
}

export function analyzeMtf(inputs: MtfInput[]): MtfReport {
  const slices = inputs.map((i) => analyzeTimeframeSlice(i.timeframe, i.candles));
  const notes: string[] = [];
  if (slices.length === 0) {
    return { slices, alignmentScore: 0, dominant: 'NEUTRAL', bullishWeight: 0, bearishWeight: 0, notes: ['no timeframe data'] };
  }
  let bullW = 0, bearW = 0, totalW = 0;
  let weightedScore = 0;
  for (const s of slices) {
    const w = weightFor(s.timeframe, slices.length);
    totalW += w;
    weightedScore += s.score * w;
    if (s.bias === 'BULLISH') bullW += w;
    else if (s.bias === 'BEARISH') bearW += w;
  }
  const dominant: TimeframeBias = bullW > bearW && bullW / totalW >= 0.4 ? 'BULLISH'
    : bearW > bullW && bearW / totalW >= 0.4 ? 'BEARISH' : 'NEUTRAL';
  const agreeW = dominant === 'BULLISH' ? bullW : dominant === 'BEARISH' ? bearW : 0;
  const alignmentScore = totalW > 0 ? Math.round((agreeW / totalW) * 100) : 0;

  // Penalize strong HTF disagreement explicitly.
  const htf = slices.filter((s) => s.timeframe === '1d' || s.timeframe === '4h');
  const ltf = slices.filter((s) => s.timeframe === '5m' || s.timeframe === '15m');
  const htfBull = htf.some((s) => s.bias === 'BULLISH');
  const htfBear = htf.some((s) => s.bias === 'BEARISH');
  const ltfBull = ltf.some((s) => s.bias === 'BULLISH');
  const ltfBear = ltf.some((s) => s.bias === 'BEARISH');
  if ((htfBull && ltfBear && !ltfBull) || (htfBear && ltfBull && !ltfBear)) {
    notes.push('HTF/LTF disagreement — counter-trend lower timeframe');
  }
  if (dominant === 'NEUTRAL') notes.push('No dominant multi-timeframe direction');
  else notes.push(`MTF dominant: ${dominant} (${alignmentScore}% agreement)`);

  void weightedScore;
  return { slices, alignmentScore, dominant, bullishWeight: bullW, bearishWeight: bearW, notes };
}
