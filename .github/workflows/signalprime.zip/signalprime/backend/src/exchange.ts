/**
 * Binance public market data client.
 *
 * Uses ONLY public endpoints (no API keys). Tries configured hosts in order
 * and remembers the first working host. Includes in-memory candle caching,
 * request timeouts, concurrency limiting, and strict response validation.
 *
 * Never fabricates data: on failure callers receive typed errors and must
 * surface MARKET_DATA_UNAVAILABLE / STALE_DATA instead of guessing.
 */
import type { Candle, Settings, Ticker } from './types.js';

export class MarketDataError extends Error {
  readonly code:
    | 'MARKET_DATA_UNAVAILABLE'
    | 'STALE_DATA'
    | 'SYMBOL_NOT_FOUND'
    | 'INSUFFICIENT_DATA'
    | 'INVALID_REQUEST';
  constructor(code: MarketDataError['code'], message: string) {
    super(message);
    this.code = code;
  }
}

interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

/** Binance interval -> milliseconds */
export const INTERVAL_MS: Record<string, number> = {
  '1m': 60_000,
  '3m': 180_000,
  '5m': 300_000,
  '15m': 900_000,
  '30m': 1_800_000,
  '1h': 3_600_000,
  '2h': 7_200_000,
  '4h': 14_400_000,
  '6h': 21_600_000,
  '8h': 28_800_000,
  '12h': 43_200_000,
  '1d': 86_400_000,
  '1w': 604_800_000,
};

const LEVERAGED_TOKEN_RE = /(UP|DOWN|BULL|BEAR)USDT$/;

export class BinanceClient {
  private workingHost: string | null = null;
  private cache = new Map<string, CacheEntry<unknown>>();
  private inFlight = 0;
  private queue: Array<() => void> = [];
  private readonly maxConcurrency = 6;

  constructor(private readonly settings: Settings) {}

  // ---------- public API ----------

  /** Spot USDT symbols that are actively trading (leveraged tokens excluded). */
  async getSpotUsdtSymbols(): Promise<string[]> {
    const data = await this.request<unknown>('/api/v3/exchangeInfo');
    const symbols = extractSymbols(data);
    return symbols
      .filter((s) => s.status === 'TRADING' && s.isSpotTradingAllowed && s.quoteAsset === 'USDT')
      .map((s) => s.symbol)
      .filter((sym) => !LEVERAGED_TOKEN_RE.test(sym));
  }

  /** 24h tickers for all symbols (single request). */
  async getAllTickers(): Promise<Ticker[]> {
    const data = await this.request<unknown[]>('/api/v3/ticker/24hr');
    if (!Array.isArray(data)) throw new MarketDataError('MARKET_DATA_UNAVAILABLE', 'Malformed ticker response');
    const out: Ticker[] = [];
    for (const t of data) {
      const r = t as Record<string, string>;
      if (typeof r.symbol !== 'string' || !r.symbol.endsWith('USDT')) continue;
      out.push({
        symbol: r.symbol,
        price: num(r.lastPrice),
        price_change_24h: num(r.priceChange),
        price_change_percent_24h: num(r.priceChangePercent),
        volume_24h: num(r.volume),
        quote_volume_24h: num(r.quoteVolume),
        high_24h: num(r.highPrice),
        low_24h: num(r.lowPrice),
      });
    }
    return out;
  }

  async getTicker(symbol: string): Promise<Ticker> {
    const sym = normalizeSymbol(symbol);
    const data = await this.request<Record<string, string>>(
      `/api/v3/ticker/24hr?symbol=${encodeURIComponent(sym)}`,
    );
    if (!data || typeof data.symbol !== 'string') {
      throw new MarketDataError('SYMBOL_NOT_FOUND', `Symbol not found: ${sym}`);
    }
    return {
      symbol: data.symbol,
      price: num(data.lastPrice),
      price_change_24h: num(data.priceChange),
      price_change_percent_24h: num(data.priceChangePercent),
      volume_24h: num(data.volume),
      quote_volume_24h: num(data.quoteVolume),
      high_24h: num(data.highPrice),
      low_24h: num(data.lowPrice),
    };
  }

  /**
   * Fetch klines. Validates OHLC integrity, sorts by open time, dedupes.
   * Throws STALE_DATA when the latest candle is older than 2x the interval.
   */
  async getCandles(symbol: string, interval: string, limit = 300): Promise<Candle[]> {
    const sym = normalizeSymbol(symbol);
    const iv = interval in INTERVAL_MS ? interval : '1h';
    const lim = Math.min(Math.max(limit, 10), 1000);
    const key = `klines:${sym}:${iv}:${lim}`;
    const cached = this.getCache<Candle[]>(key);
    if (cached) return cached;

    const data = await this.request<unknown[][]>(
      `/api/v3/klines?symbol=${encodeURIComponent(sym)}&interval=${iv}&limit=${lim}`,
    );
    if (!Array.isArray(data) || data.length === 0) {
      throw new MarketDataError('SYMBOL_NOT_FOUND', `No candle data for ${sym}`);
    }
    const candles = data
      .map(parseKline)
      .filter((c): c is Candle => c !== null)
      .sort((a, b) => a.openTime - b.openTime);
    const deduped = candles.filter((c, i, arr) => i === 0 || c.openTime !== arr[i - 1].openTime);
    if (deduped.length === 0) {
      throw new MarketDataError('MARKET_DATA_UNAVAILABLE', `Malformed candle data for ${sym}`);
    }
    const lastClose = deduped[deduped.length - 1].closeTime;
    const ivMs = INTERVAL_MS[iv];
    if (Date.now() - lastClose > ivMs * 2 + 60_000) {
      throw new MarketDataError('STALE_DATA', `Candle data for ${sym} is stale`);
    }
    // Cache TTL scales with timeframe so fast TFs refresh quickly.
    const ttl = Math.min(Math.max(ivMs / 4, 10_000), 300_000);
    this.setCache(key, deduped, ttl);
    return deduped;
  }

  /** Raw paged klines with startTime (used by the backtester). No caching. */
  async getKlinesPage(
    symbol: string,
    interval: string,
    startTime: number,
    limit = 1000,
  ): Promise<Candle[]> {
    const sym = normalizeSymbol(symbol);
    const iv = interval in INTERVAL_MS ? interval : '1h';
    const lim = Math.min(Math.max(limit, 1), 1000);
    const data = await this.request<unknown[][]>(
      `/api/v3/klines?symbol=${encodeURIComponent(sym)}&interval=${iv}&limit=${lim}&startTime=${startTime}`,
    );
    if (!Array.isArray(data)) {
      throw new MarketDataError('MARKET_DATA_UNAVAILABLE', 'Malformed klines page');
    }
    return data
      .map(parseKline)
      .filter((c): c is Candle => c !== null)
      .sort((a, b) => a.openTime - b.openTime);
  }

  /** Batch klines with concurrency limiting. Failed symbols are skipped (never faked). */
  async getCandlesBatch(
    symbols: string[],
    interval: string,
    limit: number,
  ): Promise<Map<string, Candle[]>> {
    const out = new Map<string, Candle[]>();
    await Promise.all(
      symbols.map((sym) =>
        this.withSlot(async () => {
          try {
            out.set(sym, await this.getCandles(sym, interval, limit));
          } catch {
            // skip — caller treats missing data as unscannable, never fabricated
          }
        }),
      ),
    );
    return out;
  }

  // ---------- internals ----------

  private getCache<T>(key: string): T | null {
    const e = this.cache.get(key) as CacheEntry<T> | undefined;
    if (!e) return null;
    if (Date.now() > e.expiresAt) {
      this.cache.delete(key);
      return null;
    }
    return e.value;
  }

  private setCache<T>(key: string, value: T, ttlMs: number): void {
    if (this.cache.size > 2000) this.cache.clear();
    this.cache.set(key, { value, expiresAt: Date.now() + ttlMs });
  }

  private async withSlot<T>(fn: () => Promise<T>): Promise<T> {
    if (this.inFlight >= this.maxConcurrency) {
      await new Promise<void>((resolve) => this.queue.push(resolve));
    }
    this.inFlight++;
    try {
      return await fn();
    } finally {
      this.inFlight--;
      const next = this.queue.shift();
      if (next) next();
    }
  }

  private async request<T>(path: string): Promise<T> {
    const hosts = this.workingHost
      ? [this.workingHost, ...this.settings.binanceHosts.filter((h) => h !== this.workingHost)]
      : this.settings.binanceHosts;
    let lastErr: unknown = null;
    for (const host of hosts) {
      try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), this.settings.binanceTimeoutMs);
        try {
          const res = await fetch(`${host}${path}`, {
            signal: ctrl.signal,
            headers: { 'User-Agent': 'signalprime-pro/1.0', Accept: 'application/json' },
          });
          if (res.status === 451 || res.status === 403) {
            lastErr = new Error(`geo-blocked ${res.status}`);
            continue; // try next host
          }
          if (!res.ok) {
            if (res.status === 400 || res.status === 404) {
              const body = await res.text().catch(() => '');
              throw new MarketDataError(
                body.includes('Invalid symbol') ? 'SYMBOL_NOT_FOUND' : 'INVALID_REQUEST',
                `Binance error ${res.status}: ${body.slice(0, 200)}`,
              );
            }
            throw new Error(`HTTP ${res.status}`);
          }
          const json = (await res.json()) as T;
          this.workingHost = host;
          return json;
        } finally {
          clearTimeout(t);
        }
      } catch (err) {
        if (err instanceof MarketDataError) throw err;
        lastErr = err;
      }
    }
    throw new MarketDataError(
      'MARKET_DATA_UNAVAILABLE',
      `All Binance hosts unreachable: ${errMsg(lastErr)}`,
    );
  }
}

function normalizeSymbol(symbol: string): string {
  return symbol.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function num(v: unknown): number {
  const n = typeof v === 'string' ? Number(v) : typeof v === 'number' ? v : NaN;
  return Number.isFinite(n) ? n : 0;
}

function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

function parseKline(k: unknown[]): Candle | null {
  if (!Array.isArray(k) || k.length < 7) return null;
  const [ot, o, h, l, c, v, ct] = k;
  const open = num(o), high = num(h), low = num(l), close = num(c), volume = num(v);
  const openTime = num(ot), closeTime = num(ct);
  if (!(open > 0 && high > 0 && low > 0 && close > 0)) return null;
  if (!(high >= Math.max(open, close) && low <= Math.min(open, close))) return null;
  if (!(high >= low) || volume < 0 || !(openTime > 0)) return null;
  return { openTime, open, high, low, close, volume, closeTime };
}

interface ExchangeSymbolInfo {
  symbol: string;
  status: string;
  quoteAsset: string;
  isSpotTradingAllowed: boolean;
}

function extractSymbols(data: unknown): ExchangeSymbolInfo[] {
  if (typeof data !== 'object' || data === null) return [];
  const syms = (data as { symbols?: unknown }).symbols;
  if (!Array.isArray(syms)) return [];
  return syms
    .filter((s): s is Record<string, unknown> => typeof s === 'object' && s !== null)
    .map((s) => ({
      symbol: String(s.symbol ?? ''),
      status: String(s.status ?? ''),
      quoteAsset: String(s.quoteAsset ?? ''),
      isSpotTradingAllowed: s.isSpotTradingAllowed === true,
    }))
    .filter((s) => s.symbol.length > 0);
}
