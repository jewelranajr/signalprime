/**
 * SQLite persistence (node:sqlite — built into Node 22+, no native deps).
 *
 * Stores signal snapshots (immutable history), lifecycle events,
 * backtest results, and simple key/value settings.
 */
import { DatabaseSync, type SQLInputValue } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import type { PersistedSignal, Signal, SignalResult, SignalStatus } from './types.js';

export interface SignalFilter {
  direction?: string;
  result?: string;
  status?: string[];
  symbol?: string;
  limit?: number;
}

export class SignalStore {
  private db: DatabaseSync;

  constructor(dataDir: string) {
    mkdirSync(dataDir, { recursive: true });
    this.db = new DatabaseSync(join(dataDir, 'trading_bot.db'));
    this.migrate();
  }

  private migrate(): void {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS signals (
        signal_id TEXT PRIMARY KEY,
        symbol TEXT NOT NULL,
        direction TEXT NOT NULL,
        status TEXT NOT NULL,
        snapshot TEXT NOT NULL,
        result TEXT,
        pnl_pct REAL,
        exit_price REAL,
        created_at TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_signals_symbol ON signals(symbol);
      CREATE INDEX IF NOT EXISTS idx_signals_status ON signals(status);
      CREATE INDEX IF NOT EXISTS idx_signals_created ON signals(created_at);
      CREATE INDEX IF NOT EXISTS idx_signals_direction ON signals(direction);
      CREATE TABLE IF NOT EXISTS signal_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        signal_id TEXT NOT NULL,
        event TEXT NOT NULL,
        price REAL,
        at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_events_signal ON signal_events(signal_id);
      CREATE TABLE IF NOT EXISTS backtests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        symbol TEXT NOT NULL,
        timeframe TEXT NOT NULL,
        params TEXT NOT NULL,
        result TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS kv (
        k TEXT PRIMARY KEY,
        v TEXT NOT NULL
      );
    `);
  }

  saveSignal(signal: Signal): void {
    const now = new Date().toISOString();
    const stmt = this.db.prepare(`
      INSERT INTO signals (signal_id, symbol, direction, status, snapshot, result, pnl_pct, exit_price, created_at, expires_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(signal_id) DO NOTHING
    `);
    stmt.run(
      signal.signal_id, signal.symbol, signal.direction, signal.status,
      JSON.stringify(signal), null, null, null,
      signal.created_at, signal.expires_at, now,
    );
    this.addEvent(signal.signal_id, 'CREATED', signal.entry?.preferred ?? null, signal.created_at);
  }

  /** Recent directional signal for the same symbol+timeframe (dedupe). */
  recentSignal(symbol: string, timeframe: string, withinMs: number): PersistedSignal | null {
    const rows = this.db.prepare(`
      SELECT * FROM signals WHERE symbol = ? AND direction != 'NO_TRADE'
      ORDER BY created_at DESC LIMIT 20
    `).all(symbol) as Record<string, unknown>[];
    const cutoff = Date.now() - withinMs;
    for (const row of rows) {
      const snap = parseSnapshot(row);
      if (!snap) continue;
      if (snap.signal_id.includes(`-${timeframe}-`)) {
        const created = Date.parse(snap.created_at);
        if (Number.isFinite(created) && created >= cutoff) return toPersisted(row, snap);
      }
    }
    return null;
  }

  getSignal(id: string): PersistedSignal | null {
    const row = this.db.prepare(`SELECT * FROM signals WHERE signal_id = ?`).get(id) as
      | Record<string, unknown>
      | undefined;
    if (!row) return null;
    const snap = parseSnapshot(row);
    return snap ? toPersisted(row, snap) : null;
  }

  updateSignal(
    id: string,
    patch: { status: SignalStatus; result: SignalResult; pnl_pct: number | null; exit_price: number | null },
  ): void {
    this.db.prepare(`
      UPDATE signals SET status = ?, result = ?, pnl_pct = ?, exit_price = ?, updated_at = ?
      WHERE signal_id = ?
    `).run(patch.status, patch.result, patch.pnl_pct, patch.exit_price, new Date().toISOString(), id);
  }

  listSignals(filter: SignalFilter = {}): PersistedSignal[] {
    const conds: string[] = [];
    const params: SQLInputValue[] = [];
    if (filter.direction) { conds.push('direction = ?'); params.push(filter.direction); }
    if (filter.result) { conds.push('result = ?'); params.push(filter.result); }
    if (filter.symbol) { conds.push('symbol = ?'); params.push(filter.symbol); }
    if (filter.status && filter.status.length > 0) {
      conds.push(`status IN (${filter.status.map(() => '?').join(',')})`);
      params.push(...filter.status);
    }
    const where = conds.length > 0 ? `WHERE ${conds.join(' AND ')}` : '';
    const limit = Math.min(Math.max(filter.limit ?? 50, 1), 500);
    const rows = this.db.prepare(
      `SELECT * FROM signals ${where} ORDER BY created_at DESC LIMIT ${limit}`,
    ).all(...params) as Record<string, unknown>[];
    const out: PersistedSignal[] = [];
    for (const row of rows) {
      const snap = parseSnapshot(row);
      if (snap) out.push(toPersisted(row, snap));
    }
    return out;
  }

  countByStatus(statuses: string[]): number {
    if (statuses.length === 0) return 0;
    const row = this.db.prepare(
      `SELECT COUNT(*) AS c FROM signals WHERE status IN (${statuses.map(() => '?').join(',')})`,
    ).get(...statuses) as { c: number };
    return row.c;
  }

  addEvent(signalId: string, event: string, price: number | null, at: string): void {
    this.db.prepare(`INSERT INTO signal_events (signal_id, event, price, at) VALUES (?, ?, ?, ?)`)
      .run(signalId, event, price, at);
  }

  getEvents(signalId: string): Array<{ event: string; price: number | null; at: string }> {
    return this.db.prepare(`SELECT event, price, at FROM signal_events WHERE signal_id = ? ORDER BY at ASC`)
      .all(signalId) as Array<{ event: string; price: number | null; at: string }>;
  }

  saveBacktest(symbol: string, timeframe: string, params: unknown, result: unknown): number {
    const r = this.db.prepare(
      `INSERT INTO backtests (symbol, timeframe, params, result, created_at) VALUES (?, ?, ?, ?, ?)`,
    ).run(symbol, timeframe, JSON.stringify(params), JSON.stringify(result), new Date().toISOString());
    return Number(r.lastInsertRowid);
  }

  getKv(k: string): string | null {
    const row = this.db.prepare(`SELECT v FROM kv WHERE k = ?`).get(k) as { v: string } | undefined;
    return row?.v ?? null;
  }

  setKv(k: string, v: string): void {
    this.db.prepare(`INSERT INTO kv (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v`).run(k, v);
  }

  close(): void {
    this.db.close();
  }
}

function parseSnapshot(row: Record<string, unknown>): Signal | null {
  try {
    const s = JSON.parse(String(row.snapshot)) as Signal;
    if (!s || typeof s.signal_id !== 'string') return null;
    return s;
  } catch {
    return null;
  }
}

function toPersisted(row: Record<string, unknown>, snap: Signal): PersistedSignal {
  return {
    ...snap,
    status: String(row.status) as SignalStatus,
    result: (row.result as SignalResult) ?? null,
    pnl_pct: row.pnl_pct === null ? null : Number(row.pnl_pct),
    exit_price: row.exit_price === null ? null : Number(row.exit_price),
    updated_at: String(row.updated_at),
  };
}
