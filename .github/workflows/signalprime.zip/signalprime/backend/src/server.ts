/**
 * SignalPrime REST API (Fastify).
 *
 * Routes:
 *   GET  /health            service + data-source status
 *   GET  /config            public engine thresholds
 *   GET  /symbols           tradeable USDT spot symbols
 *   GET  /ticker/:symbol    24h ticker
 *   GET  /candles/:symbol   OHLCV candles (?interval, ?limit)
 *   GET  /signal/:symbol    master signal (?timeframe, ?balance, ?risk_percent)
 *   GET  /signals           top ranked signals (?limit)
 *   GET  /signals/:id       stored signal by id
 *   GET  /scanner           ranked scan (?limit)
 *   GET  /market            dashboard overview
 *   GET  /regime/:symbol    market regime report
 *   GET  /history           signal history (?direction, ?result, ?limit)
 *   POST /backtest          walk-forward backtest
 *
 * Security: CORS, rate limiting, zod input validation, optional API-key
 * auth (x-api-key), security headers, no secrets in responses or logs.
 */
import Fastify, { type FastifyInstance } from 'fastify';
import cors from '@fastify/cors';
import rateLimit from '@fastify/rate-limit';
import { z } from 'zod';
import type { ApiError, MarketRegime, Settings, Signal } from './types.js';
import { publicConfig } from './config.js';
import { BinanceClient, INTERVAL_MS, MarketDataError } from './exchange.js';
import { SymbolScanner } from './scanner.js';
import { SignalStore } from './database.js';
import { SignalMonitor } from './monitor.js';
import { generateSignal } from './signals.js';
import { detectRegime } from './regime.js';

export interface ServerDeps {
  settings: Settings;
  exchange: BinanceClient;
  scanner: SymbolScanner;
  store: SignalStore;
  monitor: SignalMonitor;
}

const VERSION = '1.0.0';
const MTF_SET = ['5m', '15m', '1h', '4h', '1d'];

const symbolParam = z.object({ symbol: z.string().min(1).max(20) });
const candlesQuery = z.object({
  interval: z.string().default('1h'),
  limit: z.coerce.number().int().min(10).max(1000).default(300),
});
const signalQuery = z.object({
  timeframe: z.string().default('1h'),
  balance: z.coerce.number().positive().max(1_000_000_000).optional(),
  risk_percent: z.coerce.number().positive().max(10).optional(),
});
const limitQuery = z.object({ limit: z.coerce.number().int().min(1).max(500).default(50) });
const historyQuery = z.object({
  direction: z.enum(['LONG', 'SHORT', 'NO_TRADE']).optional(),
  result: z.enum(['WIN', 'LOSS', 'PENDING', 'EXPIRED']).optional(),
  status: z.string().optional(),
  symbol: z.string().max(20).optional(),
  limit: z.coerce.number().int().min(1).max(500).default(50),
});
const backtestBody = z.object({
  symbol: z.string().min(1).max(20),
  timeframe: z.string().min(1).max(5),
  start: z.string().min(1),
  end: z.string().min(1),
  initial_balance: z.number().positive().max(1_000_000_000).default(10000),
  risk_percent: z.number().positive().max(10).default(1),
});

function errBody(err: unknown): { status: number; body: ApiError } {
  if (err instanceof MarketDataError) {
    const status = err.code === 'SYMBOL_NOT_FOUND' ? 404
      : err.code === 'INVALID_REQUEST' ? 400 : 502;
    return { status, body: { error: { code: err.code, message: err.message } } };
  }
  if (err instanceof z.ZodError) {
    return { status: 400, body: { error: { code: 'INVALID_REQUEST', message: err.message } } };
  }
  // Respect HTTP status carried by Fastify/plugin errors (e.g. 429 rate limit).
  const statusCode = (err as { statusCode?: unknown })?.statusCode;
  if (typeof statusCode === 'number' && statusCode >= 400 && statusCode < 600) {
    const code = statusCode === 429 ? 'RATE_LIMITED' : 'SERVER_ERROR';
    const msg = err instanceof Error ? err.message : String(err);
    return { status: statusCode, body: { error: { code, message: msg.slice(0, 300) } } };
  }
  const msg = err instanceof Error ? err.message : String(err);
  return { status: 500, body: { error: { code: 'SERVER_ERROR', message: msg.slice(0, 300) } } };
}

export async function buildServer(deps: ServerDeps): Promise<FastifyInstance> {
  const { settings, exchange, scanner, store } = deps;
  const app = Fastify({ logger: { level: settings.logLevel } });

  await app.register(cors, {
    origin: settings.corsOrigins === '*' ? true : settings.corsOrigins.split(',').map((s) => s.trim()),
  });
  await app.register(rateLimit, {
    max: settings.rateLimitMax,
    timeWindow: settings.rateLimitWindowMs,
  });

  // Security headers.
  app.addHook('onSend', async (_req, reply) => {
    reply.header('X-Content-Type-Options', 'nosniff');
    reply.header('X-Frame-Options', 'DENY');
    reply.header('Referrer-Policy', 'no-referrer');
  });

  // Optional API-key auth (everything except /health).
  app.addHook('onRequest', async (req, reply) => {
    if (!settings.apiKey) return;
    if (req.url === '/health' || req.url.startsWith('/health?')) return;
    if (req.headers['x-api-key'] !== settings.apiKey) {
      reply.code(401).send({ error: { code: 'INVALID_REQUEST', message: 'Missing or invalid x-api-key' } });
    }
  });

  app.setErrorHandler((err, _req, reply) => {
    const { status, body } = errBody(err);
    reply.code(status).send(body);
  });

  const startedAt = Date.now();

  app.get('/health', async () => ({
    status: 'ok',
    version: VERSION,
    data_source: 'binance',
    uptime_seconds: Math.floor((Date.now() - startedAt) / 1000),
    time: new Date().toISOString(),
  }));

  app.get('/config', async () => publicConfig(settings));

  app.get('/symbols', async () => {
    const { symbols } = await scanner.getUniverse();
    return { symbols };
  });

  app.get('/ticker/:symbol', async (req) => {
    const { symbol } = symbolParam.parse(req.params);
    return exchange.getTicker(symbol);
  });

  app.get('/candles/:symbol', async (req) => {
    const { symbol } = symbolParam.parse(req.params);
    const q = candlesQuery.parse(req.query);
    const interval = q.interval in INTERVAL_MS ? q.interval : '1h';
    const candles = await exchange.getCandles(symbol, interval, q.limit);
    return { symbol: symbol.toUpperCase(), interval, candles };
  });

  app.get('/signal/:symbol', async (req) => {
    const { symbol } = symbolParam.parse(req.params);
    const q = signalQuery.parse(req.query);
    const timeframe = q.timeframe in INTERVAL_MS ? q.timeframe : '1h';
    const sym = symbol.toUpperCase();

    const primary = await exchange.getCandles(sym, timeframe, 400);
    // MTF: fetch companion timeframes (best effort — missing TFs are skipped, never faked).
    const mtfInputs = [{ timeframe, candles: primary }];
    await Promise.all(
      MTF_SET.filter((tf) => tf !== timeframe).map(async (tf) => {
        try {
          const c = await exchange.getCandles(sym, tf, 300);
          if (c.length >= 60) mtfInputs.push({ timeframe: tf, candles: c });
        } catch { /* skip */ }
      }),
    );
    const signal = generateSignal({
      symbol: sym,
      primary,
      primaryTimeframe: timeframe,
      mtfInputs,
      settings,
      options: { balance: q.balance, riskPercent: q.risk_percent },
    });
    if (signal.direction !== 'NO_TRADE') {
      // Dedupe: don't store an identical fresh signal twice.
      const recent = store.recentSignal(sym, timeframe, 30 * 60_000);
      if (!recent || recent.direction !== signal.direction) {
        store.saveSignal(signal);
      }
    }
    return signal;
  });

  app.get('/signals', async (req) => {
    const q = limitQuery.parse(req.query);
    const limit = Math.min(q.limit, 50);
    await scanner.scan(50);
    const signals = scanner.getCachedSignals(limit);
    // Persist fresh directional signals (deduped).
    for (const s of signals) {
      if (s.direction === 'NO_TRADE') continue;
      const recent = store.recentSignal(s.symbol, '1h', 30 * 60_000);
      if (!recent || recent.direction !== s.direction) store.saveSignal(s);
    }
    return { signals };
  });

  app.get('/signals/:id', async (req, reply) => {
    const id = (req.params as { id: string }).id;
    const sig = store.getSignal(id);
    if (!sig) {
      reply.code(404).send({ error: { code: 'INVALID_REQUEST', message: 'Signal not found' } });
      return;
    }
    return sig;
  });

  app.get('/scanner', async (req) => {
    const q = limitQuery.parse(req.query);
    return scanner.scan(q.limit);
  });

  app.get('/market', async () => {
    const [scanRes, btcT, ethT] = await Promise.all([
      scanner.scan(50).catch(() => null),
      exchange.getTicker('BTCUSDT').catch(() => null),
      exchange.getTicker('ETHUSDT').catch(() => null),
    ]);
    const results = scanRes?.results ?? [];
    const longs = results.filter((r) => r.direction === 'LONG').length;
    const shorts = results.filter((r) => r.direction === 'SHORT').length;
    const voted = longs + shorts;
    const signals = scanner.getCachedSignals(50);
    const dirSignals = signals.filter((s) => s.direction !== 'NO_TRADE');
    const best = [...dirSignals].sort((a, b) => b.confidence - a.confidence)[0] ?? null;
    const bestRr = dirSignals
      .filter((s) => Math.max(s.long_score, s.short_score) >= settings.minScore && s.risk_reward)
      .sort((a, b) => (b.risk_reward?.tp1 ?? 0) - (a.risk_reward?.tp1 ?? 0))[0] ?? null;
    let regime: MarketRegime = 'NEUTRAL';
    try {
      const btcCandles = await exchange.getCandles('BTCUSDT', '4h', 300);
      regime = detectRegime(btcCandles).regime;
    } catch { /* keep NEUTRAL */ }
    return {
      btc: btcT,
      eth: ethT,
      bullish_pct: voted > 0 ? Math.round((longs / voted) * 1000) / 10 : 0,
      bearish_pct: voted > 0 ? Math.round((shorts / voted) * 1000) / 10 : 0,
      total_scanned: scanRes?.total_scanned ?? 0,
      active_signals: store.countByStatus(['WAITING', 'ACTIVE']),
      best_signal: best,
      best_rr_signal: bestRr,
      market_regime: regime,
      updated_at: new Date().toISOString(),
    };
  });

  app.get('/regime/:symbol', async (req) => {
    const { symbol } = symbolParam.parse(req.params);
    const sym = symbol.toUpperCase();
    const candles = await exchange.getCandles(sym, '1h', 300);
    const r = detectRegime(candles);
    return {
      symbol: sym,
      regime: r.regime,
      bias_score: r.bias_score,
      components: r.components,
      notes: r.notes,
      updated_at: new Date().toISOString(),
    };
  });

  app.get('/history', async (req) => {
    const q = historyQuery.parse(req.query);
    const signals = store.listSignals({
      direction: q.direction,
      result: q.result,
      status: q.status ? q.status.split(',').map((s) => s.trim().toUpperCase()) : undefined,
      symbol: q.symbol?.toUpperCase(),
      limit: q.limit,
    });
    return { signals };
  });

  app.post('/backtest', async (req) => {
    const body = backtestBody.parse(req.body);
    const { runBacktest } = await import('./backtest.js');
    const result = await runBacktest(
      {
        symbol: body.symbol,
        timeframe: body.timeframe,
        start: body.start,
        end: body.end,
        initial_balance: body.initial_balance,
        risk_percent: body.risk_percent,
      },
      exchange,
      settings,
    );
    store.saveBacktest(body.symbol.toUpperCase(), body.timeframe, body, result);
    return result;
  });

  return app;
}

export type { Signal };
