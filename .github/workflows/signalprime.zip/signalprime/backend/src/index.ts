/**
 * SignalPrime backend entrypoint.
 * Wires config → exchange → scanner → store → monitor → HTTP server.
 */
import { loadSettings } from './config.js';
import { BinanceClient } from './exchange.js';
import { SymbolScanner } from './scanner.js';
import { SignalStore } from './database.js';
import { SignalMonitor } from './monitor.js';
import { buildServer } from './server.js';

async function main(): Promise<void> {
  const settings = loadSettings();
  const store = new SignalStore(settings.dataDir);
  const exchange = new BinanceClient(settings);
  const scanner = new SymbolScanner(exchange, settings);
  const monitor = new SignalMonitor(exchange, store, settings, (msg, data) => {
    console.log(`[monitor] ${msg}`, data ?? '');
  });

  const app = await buildServer({ settings, exchange, scanner, store, monitor });

  const shutdown = async () => {
    console.log('Shutting down...');
    monitor.stop();
    await app.close();
    store.close();
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  monitor.start(60_000);
  await app.listen({ port: settings.port, host: settings.host });
  console.log(`SignalPrime backend listening on http://${settings.host}:${settings.port}`);
}

main().catch((err) => {
  console.error('Fatal startup error:', err);
  process.exit(1);
});
