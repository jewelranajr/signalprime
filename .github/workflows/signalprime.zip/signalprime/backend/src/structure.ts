/**
 * Market structure & support/resistance engine.
 *
 * Detects swing points (fractals), HH/HL/LH/LL sequences, trend state,
 * BOS (break of structure), CHoCH (change of character), liquidity sweeps,
 * false breakouts, and clustered support/resistance zones.
 */
import type { Candle } from './types.js';
import { atr, lastFinite } from './indicators.js';

export interface SwingPoint {
  index: number;
  price: number;
  type: 'HIGH' | 'LOW';
  time: number;
  volume: number;
}

export type StructureState =
  | 'UPTREND'
  | 'DOWNTREND'
  | 'RANGE'
  | 'BREAKOUT'
  | 'BREAKDOWN'
  | 'REVERSAL_UP'
  | 'REVERSAL_DOWN'
  | 'CONSOLIDATION';

export interface StructureReport {
  state: StructureState;
  trendScore: number; // -100 (strong down) .. +100 (strong up)
  swingHighs: SwingPoint[];
  swingLows: SwingPoint[];
  sequence: string[]; // e.g. ['HH','HL','HH','HL']
  bos: boolean;
  bosDirection: 'UP' | 'DOWN' | null;
  choch: boolean;
  chochDirection: 'UP' | 'DOWN' | null;
  liquiditySweepUp: boolean;
  liquiditySweepDown: boolean;
  falseBreakoutUp: boolean;
  falseBreakoutDown: boolean;
  notes: string[];
}

export interface SRZone {
  price_low: number;
  price_high: number;
  price: number; // midpoint
  type: 'SUPPORT' | 'RESISTANCE';
  touches: number;
  strength: number; // 0-100
  distance_pct: number; // signed distance from current price
}

/**
 * Fractal swing detection: a swing high is the highest high in [i-order, i+order].
 */
export function findSwings(candles: Candle[], order = 3): SwingPoint[] {
  const swings: SwingPoint[] = [];
  const n = candles.length;
  for (let i = order; i < n - order; i++) {
    const c = candles[i];
    let isHigh = true, isLow = true;
    for (let j = 1; j <= order; j++) {
      if (candles[i - j].high > c.high || candles[i + j].high > c.high) isHigh = false;
      if (candles[i - j].low < c.low || candles[i + j].low < c.low) isLow = false;
      if (!isHigh && !isLow) break;
    }
    if (isHigh) {
      swings.push({ index: i, price: c.high, type: 'HIGH', time: c.openTime, volume: c.volume });
    } else if (isLow) {
      swings.push({ index: i, price: c.low, type: 'LOW', time: c.openTime, volume: c.volume });
    }
  }
  return swings;
}

export function analyzeStructure(candles: Candle[]): StructureReport {
  const notes: string[] = [];
  const n = candles.length;
  const empty: StructureReport = {
    state: 'RANGE', trendScore: 0, swingHighs: [], swingLows: [], sequence: [],
    bos: false, bosDirection: null, choch: false, chochDirection: null,
    liquiditySweepUp: false, liquiditySweepDown: false,
    falseBreakoutUp: false, falseBreakoutDown: false, notes: ['insufficient structure data'],
  };
  if (n < 30) return empty;

  const atrArr = atr(candles, 14);
  const atrV = lastFinite(atrArr);
  const price = candles[n - 1].close;
  // Fractal order fallback: smooth trends may yield no order-3 swings.
  let swings = findSwings(candles, 3);
  if (swings.length < 6) swings = findSwings(candles, 2);
  if (swings.length < 6) swings = findSwings(candles, 1);
  const swingHighs = swings.filter((s) => s.type === 'HIGH').slice(-8);
  const swingLows = swings.filter((s) => s.type === 'LOW').slice(-8);

  // HH/HL/LH/LL sequence from consecutive swings of the same type.
  const seq: string[] = [];
  for (let i = 1; i < swingHighs.length; i++) {
    seq.push(swingHighs[i].price > swingHighs[i - 1].price ? 'HH' : 'LH');
  }
  const lowSeq: string[] = [];
  for (let i = 1; i < swingLows.length; i++) {
    lowSeq.push(swingLows[i].price > swingLows[i - 1].price ? 'HL' : 'LL');
  }
  const sequence = [...seq.slice(-3), ...lowSeq.slice(-3)];

  // NOTE: require at least 2 comparisons — [].every() is vacuously true.
  // Majority of the last 3 comparisons decides (robust to one noisy swing).
  const maj = (arr: string[], v: string) => arr.slice(-3).filter((s) => s === v).length >= 2;
  const hasSeq = seq.length >= 2 && lowSeq.length >= 2;
  const upSeq = hasSeq && maj(seq, 'HH') && maj(lowSeq, 'HL');
  const downSeq = hasSeq && maj(seq, 'LH') && maj(lowSeq, 'LL');

  let trendScore = 0;
  if (upSeq) trendScore += 60;
  if (downSeq) trendScore -= 60;
  // Price position vs recent swing range.
  const recentHighs = swingHighs.slice(-3).map((s) => s.price);
  const recentLows = swingLows.slice(-3).map((s) => s.price);
  if (recentHighs.length && recentLows.length) {
    const hi = Math.max(...recentHighs), lo = Math.min(...recentLows);
    const pos = hi > lo ? (price - lo) / (hi - lo) : 0.5;
    trendScore += (pos - 0.5) * 40;
  }

  // BOS / CHoCH: check whether closes after each of the last two swing
  // points violated them in the trend / counter-trend direction.
  let bos = false, bosDirection: 'UP' | 'DOWN' | null = null;
  let choch = false, chochDirection: 'UP' | 'DOWN' | null = null;
  const lastHigh = swingHighs[swingHighs.length - 1];
  const lastLow = swingLows[swingLows.length - 1];
  const closesAfter = (idx: number) => candles.slice(idx + 1).map((c) => c.close);
  if (lastHigh) {
    const after = closesAfter(lastHigh.index);
    if (after.some((cl) => cl > lastHigh.price)) {
      if (upSeq || trendScore > 20) { bos = true; bosDirection = 'UP'; }
      else if (downSeq || trendScore < -20) { choch = true; chochDirection = 'UP'; }
      else { bos = true; bosDirection = 'UP'; }
    }
  }
  if (lastLow) {
    const after = closesAfter(lastLow.index);
    if (after.some((cl) => cl < lastLow.price)) {
      if (downSeq || trendScore < -20) { bos = true; bosDirection = 'DOWN'; }
      else if (upSeq || trendScore > 20) { choch = true; chochDirection = 'DOWN'; }
      else { bos = true; bosDirection = 'DOWN'; }
    }
  }

  // Liquidity sweeps & false breakouts on the most recent candles.
  let liquiditySweepUp = false, liquiditySweepDown = false;
  let falseBreakoutUp = false, falseBreakoutDown = false;
  const tol = Number.isFinite(atrV) ? atrV * 0.15 : price * 0.001;
  const tail = candles.slice(-12);
  if (lastHigh) {
    for (const c of tail) {
      if (c.high > lastHigh.price + tol && c.close < lastHigh.price) {
        liquiditySweepUp = true;
        if (c.close < lastHigh.price - tol) falseBreakoutUp = true;
      }
    }
  }
  if (lastLow) {
    for (const c of tail) {
      if (c.low < lastLow.price - tol && c.close > lastLow.price) {
        liquiditySweepDown = true;
        if (c.close > lastLow.price + tol) falseBreakoutDown = true;
      }
    }
  }

  // Determine state.
  let state: StructureState = 'RANGE';
  if (choch && chochDirection === 'UP') state = 'REVERSAL_UP';
  else if (choch && chochDirection === 'DOWN') state = 'REVERSAL_DOWN';
  else if (bos && bosDirection === 'UP' && upSeq) state = 'BREAKOUT';
  else if (bos && bosDirection === 'DOWN' && downSeq) state = 'BREAKDOWN';
  else if (upSeq) state = 'UPTREND';
  else if (downSeq) state = 'DOWNTREND';
  else {
    // Range vs consolidation: range of last 50 candles vs ATR.
    const window = candles.slice(-50);
    const wh = Math.max(...window.map((c) => c.high));
    const wl = Math.min(...window.map((c) => c.low));
    const rangeAtrs = Number.isFinite(atrV) && atrV > 0 ? (wh - wl) / atrV : 10;
    state = rangeAtrs < 6 ? 'CONSOLIDATION' : 'RANGE';
  }

  if (bos) notes.push(`BOS ${bosDirection === 'UP' ? 'bullish' : 'bearish'} — structure broken`);
  if (choch) notes.push(`CHoCH ${chochDirection === 'UP' ? 'bullish' : 'bearish'} — character change`);
  if (liquiditySweepUp) notes.push('Liquidity sweep above highs (sell-side liquidity taken)');
  if (liquiditySweepDown) notes.push('Liquidity sweep below lows (buy-side liquidity taken)');
  if (falseBreakoutUp) notes.push('False breakout above resistance');
  if (falseBreakoutDown) notes.push('False breakdown below support');
  if (upSeq) notes.push('Bullish structure: HH + HL sequence');
  if (downSeq) notes.push('Bearish structure: LH + LL sequence');

  return {
    state, trendScore: clamp(trendScore, -100, 100),
    swingHighs, swingLows, sequence,
    bos, bosDirection, choch, chochDirection,
    liquiditySweepUp, liquiditySweepDown,
    falseBreakoutUp, falseBreakoutDown, notes,
  };
}

/**
 * Cluster swing points into support/resistance zones.
 * Strength rewards touches, volume at the level, and recency.
 */
export function detectSRZones(candles: Candle[], maxZones = 8): SRZone[] {
  const n = candles.length;
  if (n < 30) return [];
  const price = candles[n - 1].close;
  const atrV = lastFinite(atr(candles, 14));
  const tolerance = Number.isFinite(atrV) && atrV > 0 ? atrV * 0.5 : price * 0.002;
  let swings = findSwings(candles, 3);
  if (swings.length < 6) swings = findSwings(candles, 2);
  if (swings.length < 6) swings = findSwings(candles, 1);
  if (swings.length === 0) return [];

  // Sort swing prices, cluster within tolerance.
  const pts = [...swings].sort((a, b) => a.price - b.price);
  const clusters: SwingPoint[][] = [];
  for (const p of pts) {
    const last = clusters[clusters.length - 1];
    if (last && Math.abs(p.price - avgPrice(last)) <= tolerance) last.push(p);
    else clusters.push([p]);
  }

  const avgVol = candles.reduce((s, c) => s + c.volume, 0) / n;
  const zones: SRZone[] = clusters.map((cluster) => {
    const mid = avgPrice(cluster);
    const lo = Math.min(...cluster.map((s) => s.price));
    const hi = Math.max(...cluster.map((s) => s.price));
    const touches = cluster.length;
    const volAt = cluster.reduce((s, x) => s + x.volume, 0) / Math.max(touches, 1);
    const recency = cluster.some((s) => n - 1 - s.index < 30) ? 15 : 0;
    const strength = Math.min(100, touches * 18 + (volAt > avgVol * 1.5 ? 15 : volAt > avgVol ? 8 : 0) + recency);
    return {
      price_low: lo,
      price_high: hi,
      price: mid,
      type: mid < price ? 'SUPPORT' : 'RESISTANCE',
      touches,
      strength: Math.round(strength),
      distance_pct: ((mid - price) / price) * 100,
    };
  });

  // Keep strongest zones, nearest first within each type.
  zones.sort((a, b) => b.strength - a.strength);
  const picked = zones.slice(0, maxZones * 2);
  picked.sort((a, b) => Math.abs(a.distance_pct) - Math.abs(b.distance_pct));
  const supports = picked.filter((z) => z.type === 'SUPPORT').slice(0, Math.ceil(maxZones / 2));
  const resistances = picked.filter((z) => z.type === 'RESISTANCE').slice(0, Math.ceil(maxZones / 2));
  return [...supports, ...resistances].sort((a, b) => b.price - a.price);
}

function avgPrice(pts: SwingPoint[]): number {
  return pts.reduce((s, p) => s + p.price, 0) / pts.length;
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}
