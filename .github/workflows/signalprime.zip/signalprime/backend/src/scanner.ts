/**
 * Coin scanner: ranks Binance USDT markets by signal quality.
 *
 * Scans 1–500+ symbols, filters by liquidity, runs the full Master Signal
 * engine per symbol, and ranks by:
 *   Final Rank = Score + Confidence + MTF Alignment + Liquidity Quality
 *              + Risk/Reward Quality − Contradiction Penalty − Volatility Penalty
 */
import type { Settings, ScannerItem, Signal, Ticker } from './types.js';
import { BinanceClient } from './exchange.js';
import { generateSignal } from './signals.js';
import type { MtfInput } from './mtf.js';
import { detectContradictions } from './contradiction.js';
import { computeSnapshot } from './analysis.js';
import { analyzeStructure, detectSRZones } from './structure.js';
import { analyzeMtf } from './mtf.js';

export interface ScanResult {
  scanned_at: string;
  total_scanned: number;
  results: ScannerItem[];
}

const MIN_QUOTE_VOLUME = 1_000_000; // USDT per 24h — liquidity filter
const UNIVERSE_TTL_MS = 3_600_000;

/** Stablecoin / pegged-asset pairs carry no directional edge — exclude them. */
const STABLECOIN_BASES = new Set([
  'USDC', 'FDUSD', 'TUSD', 'DAI', 'USDP', 'USD1', 'AEUR', 'XUSD',
  'BFUSD', 'USDD', 'FRAX', 'LUSD', 'GUSD', 'PYUSD', 'EUR', 'EURI',
]);

export class SymbolScanner {
  private universe: { symbols: string[]; tickers: Map<string, Ticker>; at: number } | null = null;
  private scanCache: { result: ScanResult; signals: Map<string, Signal>; at: number } | null = null;

  constructor(
    private readonly exchange: BinanceClient,
    private readonly settings: Settings,
  ) {}

  async getUniverse(): Promise<{ symbols: string[]; tickers: Map<string, Ticker> }> {
    if (this.universe && Date.now() - this.universe.at < UNIVERSE_TTL_MS) {
      return { symbols: this.universe.symbols, tickers: this.universe.tickers };
    }
    const [symbols, tickers] = await Promise.all([
      this.exchange.getSpotUsdtSymbols(),
      this.exchange.getAllTickers(),
    ]);
    const allowed = new Set(symbols);
    const liquid = tickers
      .filter((t) => allowed.has(t.symbol) && t.quote_volume_24h >= MIN_QUOTE_VOLUME)
      .filter((t) => !STABLECOIN_BASES.has(t.symbol.replace(/USDT$/, '')))
      .sort((a, b) => b.quote_volume_24h - a.quote_volume_24h);
    const map = new Map<string, Ticker>();
    for (const t of liquid) map.set(t.symbol, t);
    this.universe = { symbols: liquid.map((t) => t.symbol), tickers: map, at: Date.now() };
    return { symbols: this.universe.symbols, tickers: map };
  }

  async scan(limit?: number): Promise<ScanResult> {
    const now = Date.now();
    if (this.scanCache && now - this.scanCache.at < this.settings.scannerCacheTtlMs) {
      const cached = this.scanCache.result;
      return { ...cached, results: cached.results.slice(0, limit ?? cached.results.length) };
    }
    const { symbols, tickers } = await this.getUniverse();
    const top = Math.min(limit ?? this.settings.scannerTopSymbols, this.settings.scannerMaxSymbols);
    const targets = symbols.slice(0, top);

    const [h1, h4] = await Promise.all([
      this.exchange.getCandlesBatch(targets, '1h', 300),
      this.exchange.getCandlesBatch(targets, '4h', 300),
    ]);

    const results: ScannerItem[] = [];
    const signals = new Map<string, Signal>();
    for (const symbol of targets) {
      const c1h = h1.get(symbol);
      const c4h = h4.get(symbol);
      if (!c1h || c1h.length < this.settings.minDataCandles) continue;
      try {
        const mtfInputs: MtfInput[] = [{ timeframe: '1h', candles: c1h }];
        if (c4h && c4h.length >= 60) mtfInputs.push({ timeframe: '4h', candles: c4h });
        const signal = generateSignal({
          symbol,
          primary: c1h,
          primaryTimeframe: '1h',
          mtfInputs,
          settings: this.settings,
        });

        // Ranking components.
        const snap = computeSnapshot(c1h);
        const structure = analyzeStructure(c1h);
        const zones = detectSRZones(c1h, 8);
        const mtf = analyzeMtf(mtfInputs);
        const leadScore = Math.max(signal.long_score, signal.short_score);
        const leadDir = signal.direction === 'NO_TRADE'
          ? (signal.long_score >= signal.short_score ? 'LONG' : 'SHORT')
          : signal.direction;
        const contra = detectContradictions({ snap, mtf, structure, zones }, leadDir);
        const ticker = tickers.get(symbol);
        const liqQ = ticker ? Math.min(10, Math.max(0, Math.log10(ticker.quote_volume_24h) - 5)) : 0;
        const rrQ = signal.risk_reward ? (signal.risk_reward.tp1 >= 3 ? 10 : signal.risk_reward.tp1 >= 2 ? 6 : 2) : 0;
        const volP = snap.bbWidthRank > 80 ? 8 : snap.bbWidthRank > 60 ? 4 : 0;
        const rankScore = leadScore
          + signal.confidence * 0.5
          + mtf.alignmentScore * 0.3
          + liqQ
          + rrQ
          - contra.totalPenalty * 0.5
          - volP;

        signals.set(symbol, signal);
        results.push({
          symbol,
          price: ticker?.price ?? snap.price,
          change_24h_pct: ticker?.price_change_percent_24h ?? 0,
          volume_24h: ticker?.volume_24h ?? 0,
          direction: signal.direction,
          long_score: signal.long_score,
          short_score: signal.short_score,
          direction_gap: signal.direction_gap,
          confidence: signal.confidence,
          probability_estimate: signal.probability_estimate,
          market_regime: signal.market_regime,
          entry_preferred: signal.entry?.preferred ?? null,
          risk_reward_tp1: signal.risk_reward?.tp1 ?? null,
          rank_score: Math.round(rankScore * 100) / 100,
          updated_at: signal.created_at,
        });
      } catch {
        // Never let one bad symbol kill the scan.
      }
    }
    results.sort((a, b) => b.rank_score - a.rank_score);
    const result: ScanResult = {
      scanned_at: new Date(now).toISOString(),
      total_scanned: results.length,
      results,
    };
    this.scanCache = { result, signals, at: now };
    return result;
  }

  /** Full Signal objects from the latest scan, ordered by rank. */
  getCachedSignals(limit = 20): Signal[] {
    const cache = this.scanCache;
    if (!cache) return [];
    return cache.result.results
      .slice(0, limit)
      .map((r) => cache.signals.get(r.symbol))
      .filter((s): s is Signal => s !== undefined);
  }

  getSignalFor(symbol: string): Signal | undefined {
    return this.scanCache?.signals.get(symbol);
  }

  invalidateScanCache(): void {
    this.scanCache = null;
  }
}
