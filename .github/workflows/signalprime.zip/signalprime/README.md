# SignalPrime — Master Signal

A production-ready crypto market-intelligence platform that generates only
high-quality **LONG** / **SHORT** / **NO_TRADE** signals. Multi-layer analysis
(multi-timeframe, technicals, market structure, regime, volume, volatility,
liquidity, S/R) with a mandatory contradiction engine and full risk management
(entry zones, structural stop-loss, TP1–3, position sizing).

**Quality > quantity.** When conditions are unclear, the engine outputs
`NO_TRADE` with explicit reasons. It never forces a trade, never fabricates
data, and never promises profit.

## Repository layout

```
signalprime-pro/
  backend/     Node.js + TypeScript + Fastify Master Signal Engine (see backend/README.md)
  android/     Kotlin + Jetpack Compose trading terminal (see android/README.md)
  .github/     CI workflows (backend build/test, Android build)
```

## Quick start

**Backend**

```bash
cd backend
cp .env.example .env
npm install
npm run build
npm start          # http://localhost:3000
npm test           # 50 unit/API/integration tests
```

**Android** (requires Android Studio / SDK, JDK 17)

```bash
cd android
./gradlew assembleDebug
```

Point the app at your backend: Settings → API base URL
(emulator default `http://10.0.2.2:3000`).

## How it works

```
Android app → Secure REST API → Master Signal Engine → Binance public data
                                        ↓
  MTF analysis → indicators → structure → regime → scoring → contradictions
                                        ↓
              risk engine (entry/SL/TP/position) → LONG | SHORT | NO_TRADE
```

All thresholds are env-configurable (`MIN_SCORE=85`, `MIN_DIRECTION_GAP=10`,
`MIN_RR=2`, `MIN_CONFIDENCE=75`, …). See `backend/.env.example`.

## Security

- Only Binance **public** endpoints are used. No API keys, no secrets in the repo.
- Android app holds no credentials — only a configurable base URL.
- Optional backend API-key auth via `API_KEY` (`x-api-key` header).

## Disclaimer

This is an analytical tool, not financial advice. Signals are model estimates,
not guarantees. Backtests are historical simulations. Never trade capital you
cannot afford to lose.

## License

MIT — see [LICENSE](LICENSE).
